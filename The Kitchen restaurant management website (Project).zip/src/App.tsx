import { useState, useCallback, useEffect, useRef } from "react";
import logoSrc from "./imports/The_Kitchen-removebg-preview_-_Edited__1_.png";
import Loader from "./components/Loader";
import { menuItems, type MenuItem } from "./data/menuData";
import Home from "./pages/Home";
import Menu from "./pages/Menu";
import Order from "./pages/Order";
import Checkout from "./pages/Checkout";
import Tracking from "./pages/Tracking";
import Reservation from "./pages/Reservation";
import About from "./pages/About";
import Reviews from "./pages/Reviews";
import Gallery from "./pages/Gallery";
import Contact from "./pages/Contact";
import Auth from "./pages/Auth";
import CustomerDashboard from "./pages/CustomerDashboard";
import AdminDashboard from "./pages/AdminDashboard";

type Page =
  | "home" | "menu" | "order" | "checkout" | "tracking"
  | "reservation" | "about" | "reviews" | "gallery" | "contact"
  | "auth" | "dashboard" | "admin";

interface CartItem extends MenuItem {
  quantity: number;
}

const NAV_LINKS: { key: Page; label: string }[] = [
  { key: "menu", label: "Menu" },
  { key: "reservation", label: "Reserve" },
  { key: "gallery", label: "Gallery" },
  { key: "about", label: "About" },
  { key: "reviews", label: "Reviews" },
  { key: "contact", label: "Contact" },
];

export default function App() {
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState<Page>("home");
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [pageKey, setPageKey] = useState(0);
  const [cartBump, setCartBump] = useState(false);
  const mainRef = useRef<HTMLElement>(null);

  const handleLoaderDone = useCallback(() => setLoading(false), []);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const navigate = (p: string) => {
    setPage(p as Page);
    setPageKey((k) => k + 1);
    setMobileOpen(false);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const addToCart = (item: MenuItem) => {
    setCart((prev) => {
      const existing = prev.find((c) => c.id === item.id);
      if (existing) return prev.map((c) => c.id === item.id ? { ...c, quantity: c.quantity + 1 } : c);
      return [...prev, { ...item, quantity: 1 }];
    });
    setCartBump(true);
    setTimeout(() => setCartBump(false), 350);
  };

  const updateQty = (id: string, qty: number) => {
    if (qty === 0) setCart((prev) => prev.filter((c) => c.id !== id));
    else setCart((prev) => prev.map((c) => c.id === id ? { ...c, quantity: qty } : c));
  };

  const removeFromCart = (id: string) => setCart((prev) => prev.filter((c) => c.id !== id));
  const placeOrder = () => setCart([]);

  const totalItems = cart.reduce((s, i) => s + i.quantity, 0);

  return (
    <div style={{ background: "#0D0D0D", minHeight: "100vh", color: "#F5F5F5" }}>
      {loading && <Loader onDone={handleLoaderDone} />}

      {/* Navigation */}
      <nav
        className="fixed top-0 left-0 right-0 z-50 transition-all duration-300"
        style={{
          background: scrolled ? "rgba(10,10,10,0.97)" : "rgba(13,13,13,0.85)",
          backdropFilter: "blur(20px)",
          WebkitBackdropFilter: "blur(20px)",
          borderBottom: scrolled ? "1px solid rgba(212,175,55,0.18)" : "1px solid rgba(212,175,55,0.06)",
          boxShadow: scrolled ? "0 4px 32px rgba(0,0,0,0.6)" : "none",
        }}
      >
        <div className="max-w-7xl mx-auto px-5 flex items-center justify-between" style={{ height: scrolled ? "60px" : "70px", transition: "height 0.3s ease" }}>
          {/* Logo */}
          <button onClick={() => navigate("home")} className="flex items-center gap-2 shrink-0 group">
            <img
              src={logoSrc}
              alt="The Kitchen Malta"
              fetchPriority="high"
              decoding="async"
              className="object-contain transition-all duration-300"
              style={{
                height: scrolled ? "44px" : "54px",
                width: "auto",
                filter: "brightness(0) invert(1) sepia(1) saturate(3) hue-rotate(3deg) brightness(0.88)",
                imageRendering: "crisp-edges",
              }}
            />
          </button>

          {/* Desktop nav */}
          <div className="hidden md:flex items-center gap-7">
            {NAV_LINKS.map((link) => (
              <button
                key={link.key}
                onClick={() => navigate(link.key)}
                className={`nav-link ${page === link.key ? "active" : ""}`}
              >
                {link.label}
              </button>
            ))}
          </div>

          {/* Right actions */}
          <div className="flex items-center gap-3">
            <span className="hidden lg:flex halal-badge">
              <span style={{ color: "#5EC45E" }}>✓</span> 100% Halal
            </span>

            {/* Cart */}
            <button
              onClick={() => navigate("order")}
              className="relative flex items-center gap-2 px-3 py-1.5 rounded-full transition-all duration-200"
              style={{
                background: "rgba(212,175,55,0.08)",
                border: "1px solid rgba(212,175,55,0.18)",
                transform: cartBump ? "scale(1.12)" : "scale(1)",
                transition: "transform 0.3s cubic-bezier(0.34,1.56,0.64,1), background 0.2s, box-shadow 0.2s",
                boxShadow: cartBump ? "0 0 18px rgba(212,175,55,0.35)" : "none",
              }}
            >
              <svg className="w-4 h-4" fill="none" stroke="#D4AF37" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z" />
              </svg>
              {totalItems > 0 && (
                <span
                  className="text-xs font-mono font-bold animate-scale-in"
                  style={{ color: "#D4AF37" }}
                >
                  {totalItems}
                </span>
              )}
            </button>

            {/* Auth */}
            {isLoggedIn ? (
              <div className="flex items-center gap-2">
                <button
                  onClick={() => navigate("dashboard")}
                  className="w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold transition-all hover:scale-105"
                  style={{ background: "linear-gradient(135deg, #D4AF37, #E8C96B)", color: "#0D0D0D", boxShadow: "0 2px 12px rgba(212,175,55,0.3)" }}
                >
                  J
                </button>
                <button
                  onClick={() => navigate("admin")}
                  className="hidden md:block text-xs px-3 py-1.5 rounded-full transition-all hover:opacity-80"
                  style={{ background: "rgba(179,58,58,0.12)", color: "#E07070", border: "1px solid rgba(179,58,58,0.25)" }}
                >
                  Admin
                </button>
              </div>
            ) : (
              <button
                onClick={() => navigate("auth")}
                className="btn-gold px-4 py-1.5 rounded-full text-xs font-semibold hidden md:block"
              >
                Sign In
              </button>
            )}

            {/* Mobile hamburger */}
            <button
              onClick={() => setMobileOpen(!mobileOpen)}
              className="md:hidden flex flex-col gap-1.5 p-2 rounded-lg transition-all"
              style={{ background: mobileOpen ? "rgba(212,175,55,0.1)" : "transparent" }}
              aria-label="Toggle menu"
            >
              <span className="w-5 h-0.5 block transition-all duration-300 origin-center" style={{ background: "#D0D0D0", transform: mobileOpen ? "rotate(45deg) translate(2.5px, 6px)" : "none" }} />
              <span className="w-5 h-0.5 block transition-all duration-300" style={{ background: "#D0D0D0", opacity: mobileOpen ? 0 : 1, transform: mobileOpen ? "scaleX(0)" : "none" }} />
              <span className="w-5 h-0.5 block transition-all duration-300 origin-center" style={{ background: "#D0D0D0", transform: mobileOpen ? "rotate(-45deg) translate(2.5px, -6px)" : "none" }} />
            </button>
          </div>
        </div>

        {/* Mobile menu */}
        <div
          className="md:hidden overflow-hidden transition-all duration-300"
          style={{
            maxHeight: mobileOpen ? "420px" : "0",
            borderTop: mobileOpen ? "1px solid rgba(212,175,55,0.1)" : "none",
            background: "rgba(10,10,10,0.98)",
          }}
        >
          <div className="px-5 py-5 space-y-1">
            {NAV_LINKS.map((link, i) => (
              <button
                key={link.key}
                onClick={() => navigate(link.key)}
                className="flex items-center justify-between w-full text-left px-3 py-3 rounded-xl text-sm font-medium transition-all"
                style={{
                  color: page === link.key ? "#D4AF37" : "#A0A0A0",
                  background: page === link.key ? "rgba(212,175,55,0.08)" : "transparent",
                  animationDelay: `${i * 0.04}s`,
                }}
              >
                {link.label}
                {page === link.key && <span style={{ color: "#D4AF37", fontSize: "12px" }}>●</span>}
              </button>
            ))}
            <div className="pt-2 border-t" style={{ borderColor: "#2A2A2A" }}>
              <div className="flex items-center gap-2 px-3 py-2">
                <span className="halal-badge">✓ 100% Halal</span>
              </div>
              {isLoggedIn ? (
                <>
                  <button onClick={() => navigate("dashboard")} className="w-full text-left px-3 py-3 text-sm rounded-xl transition-all" style={{ color: "#D4AF37" }}>My Account</button>
                  <button onClick={() => navigate("admin")} className="w-full text-left px-3 py-3 text-sm rounded-xl transition-all" style={{ color: "#E07070" }}>Admin Panel</button>
                </>
              ) : (
                <button onClick={() => navigate("auth")} className="btn-gold w-full py-3 rounded-xl text-sm font-semibold mt-1">Sign In</button>
              )}
            </div>
          </div>
        </div>
      </nav>

      {/* Pages with transition */}
      <main ref={mainRef} key={pageKey} className="page-enter">
        {page === "home" && <Home onNavigate={navigate} onAddToCart={addToCart} />}
        {page === "menu" && (
          <Menu
            onAddToCart={addToCart}
            cartItems={cart.map((c) => ({ id: c.id, quantity: c.quantity }))}
          />
        )}
        {page === "order" && (
          <Order
            cartItems={cart}
            onUpdateQty={updateQty}
            onRemove={removeFromCart}
            onNavigate={navigate}
            onAddToCart={addToCart}
          />
        )}
        {page === "checkout" && <Checkout cartItems={cart} onNavigate={navigate} onPlaceOrder={placeOrder} />}
        {page === "tracking" && <Tracking />}
        {page === "reservation" && <Reservation />}
        {page === "about" && <About />}
        {page === "reviews" && <Reviews />}
        {page === "gallery" && <Gallery />}
        {page === "contact" && <Contact />}
        {page === "auth" && <Auth onLogin={() => setIsLoggedIn(true)} onNavigate={navigate} />}
        {page === "dashboard" && <CustomerDashboard onNavigate={navigate} />}
        {page === "admin" && <AdminDashboard />}
      </main>

      {/* Footer */}
      {page !== "admin" && (
        <footer style={{ background: "#080808", borderTop: "1px solid rgba(212,175,55,0.1)" }}>
          {/* Top accent line */}
          <div className="gold-divider" />

          <div className="max-w-7xl mx-auto px-6 py-16">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-10 mb-12">
              {/* Brand */}
              <div className="md:col-span-1">
                <img
                  src={logoSrc}
                  alt="The Kitchen Malta"
                  loading="lazy"
                  decoding="async"
                  className="object-contain mb-5"
                  style={{ height: "60px", width: "auto", filter: "brightness(0) invert(1) sepia(1) saturate(3) hue-rotate(3deg) brightness(0.7)" }}
                />
                <p className="text-sm leading-relaxed mb-5" style={{ color: "#4A4A4A" }}>
                  100% Halal fine dining in Malta — premium burgers, artisan pizzas, and slow-smoked BBQ. Made With Passion. Est. 2019.
                </p>
                <span className="halal-badge mb-5 inline-flex">
                  <span>✓</span> 100% Halal Certified
                </span>
                <div className="flex gap-2.5 mt-4">
                  {[
                    { label: "IG", full: "Instagram" },
                    { label: "TK", full: "TikTok" },
                    { label: "FB", full: "Facebook" },
                  ].map((s) => (
                    <button
                      key={s.full}
                      title={s.full}
                      className="w-9 h-9 rounded-full flex items-center justify-center text-xs font-mono font-semibold transition-all"
                      style={{ border: "1px solid #2E2E2E", color: "#4A4A4A" }}
                      onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.borderColor = "#D4AF37"; (e.currentTarget as HTMLElement).style.color = "#D4AF37"; (e.currentTarget as HTMLElement).style.boxShadow = "0 0 12px rgba(212,175,55,0.2)"; }}
                      onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.borderColor = "#2E2E2E"; (e.currentTarget as HTMLElement).style.color = "#4A4A4A"; (e.currentTarget as HTMLElement).style.boxShadow = "none"; }}
                    >
                      {s.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Quick links */}
              <div>
                <h4 className="text-xs font-semibold uppercase tracking-widest mb-5" style={{ color: "#D4AF37" }}>Quick Links</h4>
                <ul className="space-y-2.5">
                  {[
                    { label: "Menu", page: "menu" as Page },
                    { label: "Reservations", page: "reservation" as Page },
                    { label: "Order Online", page: "order" as Page },
                    { label: "Gallery", page: "gallery" as Page },
                    { label: "About Us", page: "about" as Page },
                    { label: "Contact", page: "contact" as Page },
                  ].map((l) => (
                    <li key={l.label}>
                      <button
                        onClick={() => navigate(l.page)}
                        className="text-sm transition-all flex items-center gap-2 group"
                        style={{ color: "#4A4A4A" }}
                        onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.color = "#D4AF37"; (e.currentTarget as HTMLElement).style.paddingLeft = "4px"; }}
                        onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.color = "#4A4A4A"; (e.currentTarget as HTMLElement).style.paddingLeft = "0"; }}
                      >
                        {l.label}
                      </button>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Hours */}
              <div>
                <h4 className="text-xs font-semibold uppercase tracking-widest mb-5" style={{ color: "#D4AF37" }}>Opening Hours</h4>
                <ul className="space-y-3">
                  {[
                    { day: "Mon – Thu", time: "12:00 PM – 10:30 PM" },
                    { day: "Fri – Sat", time: "12:00 PM – 11:30 PM" },
                    { day: "Sunday", time: "12:00 PM – 10:00 PM" },
                  ].map((h) => (
                    <li key={h.day} className="flex justify-between text-sm gap-3">
                      <span style={{ color: "#4A4A4A" }}>{h.day}</span>
                      <span style={{ color: "#7A7A7A" }}>{h.time}</span>
                    </li>
                  ))}
                  <li className="pt-2 text-xs font-mono" style={{ color: "#3A3A3A", borderTop: "1px solid #1E1E1E" }}>
                    +356 99119100
                  </li>
                </ul>
              </div>

              {/* Newsletter */}
              <div>
                <h4 className="text-xs font-semibold uppercase tracking-widest mb-5" style={{ color: "#D4AF37" }}>Stay Updated</h4>
                <p className="text-sm mb-4 leading-relaxed" style={{ color: "#4A4A4A" }}>
                  New dishes, exclusive offers and events — straight to your inbox.
                </p>
                <div className="flex gap-2">
                  <input
                    type="email"
                    placeholder="your@email.com"
                    style={{ paddingTop: "9px", paddingBottom: "9px", fontSize: "13px" }}
                  />
                  <button className="btn-gold px-4 py-2 rounded-lg text-xs font-bold shrink-0">
                    →
                  </button>
                </div>
                <p className="text-xs mt-2.5" style={{ color: "#2E2E2E" }}>No spam. Unsubscribe anytime.</p>
              </div>
            </div>

            <div className="gold-divider mb-8" />

            <div className="flex flex-wrap items-center justify-between gap-4 text-xs" style={{ color: "#2E2E2E" }}>
              <span>© 2026 The Kitchen Malta. All rights reserved.</span>
              <div className="flex gap-6">
                <span className="cursor-pointer transition-colors" onMouseEnter={(e) => (e.currentTarget.style.color = "#D4AF37")} onMouseLeave={(e) => (e.currentTarget.style.color = "#2E2E2E")}>Privacy Policy</span>
                <span className="cursor-pointer transition-colors" onMouseEnter={(e) => (e.currentTarget.style.color = "#D4AF37")} onMouseLeave={(e) => (e.currentTarget.style.color = "#2E2E2E")}>Terms of Service</span>
              </div>
              <span className="font-mono">Malta · Made With Passion ✦</span>
            </div>
          </div>
        </footer>
      )}
    </div>
  );
}
