import type { Lang } from "../context/LangContext";

const translations: Record<string, { en: string; bn: string }> = {
  // Hero
  heroTagline: { en: "Chittagong, Bangladesh · Est. 2019", bn: "চট্টগ্রাম, বাংলাদেশ · প্রতিষ্ঠিত ২০১৯" },
  heroSubtitle: {
    en: "Authentic Bangladeshi cuisine from the heart of Chittagong — Mezban, Shorshe Ilish, Kacchi Biryani, and the flavours that have defined a city for generations.",
    bn: "চট্টগ্রামের হৃদয় থেকে খাঁটি বাংলাদেশি রান্না — মেজবান, সরষে ইলিশ, কাচ্চি বিরিয়ানি এবং প্রজন্মের স্বাদ।",
  },
  exploreMenu: { en: "Explore Menu", bn: "মেনু দেখুন" },
  reserveTable: { en: "Reserve a Table", bn: "টেবিল বুক করুন" },

  // Stats bar
  stat1V: { en: "7+", bn: "৭+" },
  stat1L: { en: "Years of Excellence", bn: "বছরের অভিজ্ঞতা" },
  stat2V: { en: "45+", bn: "৪৫+" },
  stat2L: { en: "Bangladeshi Dishes", bn: "বাংলাদেশি ডিশ" },
  stat3V: { en: "4.9★", bn: "৪.৯★" },
  stat3L: { en: "Average Rating", bn: "গড় রেটিং" },
  stat4V: { en: "50,000+", bn: "৫০,০০০+" },
  stat4L: { en: "Happy Guests", bn: "সন্তুষ্ট অতিথি" },
  reviewsBadge: { en: "50,000+ Reviews", bn: "৫০,০০০+ রিভিউ" },

  // Featured dishes
  signatureSection: { en: "— Signature Selection —", bn: "— সিগনেচার সিলেকশন —" },
  featuredDishes: { en: "Featured Dishes", bn: "বিশেষ ডিশ" },
  featuredSubtitle: { en: "Our most loved Chittagong classics — ordered by hundreds daily", bn: "চট্টগ্রামের সবচেয়ে প্রিয় ক্লাসিক — প্রতিদিন শত শত অর্ডার" },
  viewFullMenu: { en: "View Full Menu →", bn: "সম্পূর্ণ মেনু →" },

  // Philosophy section
  ourPhilosophy: { en: "— Our Philosophy —", bn: "— আমাদের দর্শন —" },
  philosophyH1: { en: "The Taste of Chittagong,", bn: "চট্টগ্রামের স্বাদ," },
  philosophyH2: { en: "Under One Roof.", bn: "এক ছাদের নিচে।" },
  ourStory: { en: "Our Story →", bn: "আমাদের গল্প →" },

  // Loyalty / rewards
  loyaltyTag: { en: "— Kitchen Rewards —", bn: "— কিচেন রিওয়ার্ডস —" },
  loyaltyTitle: { en: "Dine More. Earn More.", bn: "বেশি খান। বেশি উপার্জন করুন।" },
  loyaltyDesc: {
    en: "Every order earns Kitchen Points redeemable for free dishes, exclusive tasting experiences, and priority reservations.",
    bn: "প্রতিটি অর্ডারে Kitchen Points অর্জন করুন — বিনামূল্যে ডিশ, এক্সক্লুসিভ ট্যাস্টিং এবং অগ্রাধিকার রিজার্ভেশনের জন্য ব্যবহার করুন।",
  },
  tier1Pts: { en: "1 Point", bn: "১ পয়েন্ট" },
  tier1Per: { en: "per ৳10 spent", bn: "প্রতি ৳১০ তে" },
  tier2Pts: { en: "500 Points", bn: "৫০০ পয়েন্ট" },
  tier2Per: { en: "Free Starter", bn: "বিনামূল্যে স্টার্টার" },
  tier3Pts: { en: "2000 Points", bn: "২০০০ পয়েন্ট" },
  tier3Per: { en: "Chef's Special", bn: "শেফের বিশেষ ডিশ" },
  joinRewards: { en: "Join Kitchen Rewards →", bn: "Kitchen Rewards-এ যোগ দিন →" },

  // Dish card
  spicyTag: { en: "🌶 Spicy", bn: "🌶 ঝাল" },
  addToCart: { en: "Add to Cart", bn: "কার্টে যোগ করুন" },

  // Order page
  orderTagline: { en: "— Your Order —", bn: "— আপনার অর্ডার —" },
  deliveryMode: { en: "🛵 Delivery", bn: "🛵 ডেলিভারি" },
  pickupMode: { en: "🏃 Pickup", bn: "🏃 পিকআপ" },
  cartEmpty: { en: "Your Cart is Empty", bn: "আপনার কার্ট খালি" },
  cartEmptyDesc: { en: "Add dishes from the menu to get started", bn: "মেনু থেকে ডিশ যোগ করুন" },
  browseMenu: { en: "Browse Menu →", bn: "মেনু দেখুন →" },
  youMightLike: { en: "You Might Also Like", bn: "আপনার পছন্দ হতে পারে" },
  totalLabel: { en: "Total", bn: "মোট" },
  estDeliveryLabel: { en: "Estimated Time", bn: "আনুমানিক সময়" },
  estDeliveryTime: { en: "30–45 minutes", bn: "৩০–৪৫ মিনিট" },

  // Checkout steps
  checkoutTagline: { en: "— Almost There —", bn: "— প্রায় হয়ে গেছে —" },
  step1: { en: "Delivery Info", bn: "ডেলিভারি তথ্য" },
  step2: { en: "Payment", bn: "পেমেন্ট" },
  step3: { en: "Confirm", bn: "নিশ্চিত করুন" },

  // Checkout — step 1 form
  deliveryInfoTitle: { en: "Delivery Information", bn: "ডেলিভারি তথ্য" },
  labelFullName: { en: "Full Name *", bn: "পূর্ণ নাম *" },
  placeholderName: { en: "Your name", bn: "আপনার নাম" },
  labelMobile: { en: "Mobile Number *", bn: "মোবাইল নম্বর *" },
  labelEmail: { en: "Email", bn: "ইমেইল" },
  labelAddress: { en: "Full Address *", bn: "সম্পূর্ণ ঠিকানা *" },
  placeholderAddress: { en: "House no., road, area", bn: "বাড়ি নং, রোড, এলাকা" },
  labelArea: { en: "Area", bn: "এলাকা" },
  placeholderArea: { en: "Select area", bn: "এলাকা বেছে নিন" },
  labelCity: { en: "City", bn: "শহর" },
  labelSpecialInstructions: { en: "Special Instructions", bn: "বিশেষ নির্দেশনা" },
  placeholderInstructions: { en: "Allergies, special requests or delivery notes…", bn: "অ্যালার্জি, বিশেষ অনুরোধ বা ডেলিভারি নোট…" },
  proceedPayment: { en: "Proceed to Payment →", bn: "পেমেন্টে যান →" },

  // Checkout — step 2 payment
  paymentMethodTitle: { en: "Payment Method", bn: "পেমেন্ট পদ্ধতি" },
  creditCardLabel: { en: "Credit Card", bn: "ক্রেডিট কার্ড" },
  cashOnDeliveryLabel: { en: "Cash on Delivery", bn: "ক্যাশ অন ডেলিভারি" },
  bkashInstruction: { en: "Send to:", bn: "নম্বরে পাঠান:" },
  bkashRef: { en: "Reference: Write your name", bn: "Reference: আপনার নাম লিখুন" },
  cashNote: { en: "Please have", bn: "ডেলিভারি ম্যান আসার সময়" },
  cashNote2: { en: "ready when the delivery arrives.", bn: "প্রস্তুত রাখুন।" },
  reviewOrderBtn: { en: "Review Order →", bn: "Review করুন →" },

  // Checkout — step 3 confirm
  confirmOrderTitle: { en: "Confirm Order", bn: "অর্ডার নিশ্চিত করুন" },
  deliveryAddressLabel: { en: "Delivery Address", bn: "ডেলিভারি ঠিকানা" },
  paymentLabel: { en: "Payment", bn: "পেমেন্ট" },
  placeOrderBtn: { en: "Place Order", bn: "অর্ডার দিন" },

  // Order summary labels shared by Order + Checkout
  subtotalLabel: { en: "Subtotal", bn: "সাবটোটাল" },
  deliveryChargeLabel: { en: "Delivery charge", bn: "ডেলিভারি চার্জ" },
  pickupFreeLabel: { en: "Pickup (free)", bn: "পিকআপ (বিনামূল্যে)" },

  // Checkout success
  orderPlacedTitle: { en: "Order Placed!", bn: "অর্ডার সম্পন্ন!" },
  thankYouPrefix: { en: "Thank you,", bn: "ধন্যবাদ," },
  orderReceivedMsg: { en: "Your order", bn: "আপনার অর্ডার" },
  orderReceivedSuffix: { en: "has been received.", bn: "গ্রহণ করা হয়েছে।" },
  guestFallback: { en: "dear guest", bn: "প্রিয় অতিথি" },
  estDeliverySuccess: { en: "Estimated delivery: 35–45 minutes", bn: "আনুমানিক ডেলিভারি: ৩৫–৪৫ মিনিট" },
  trackOrder: { en: "Track Order", bn: "অর্ডার ট্র্যাক করুন" },
  homeBtn: { en: "Home", bn: "হোম" },
};

export function t(lang: Lang, key: string): string {
  return translations[key]?.[lang] ?? translations[key]?.en ?? key;
}
