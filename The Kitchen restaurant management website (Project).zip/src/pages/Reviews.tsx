import { useState, useEffect, useRef } from "react";
import { reviews } from "../data/menuData";

function useScrollReveal() {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!ref.current) return;
    const el = ref.current;
    const obs = new IntersectionObserver(
      (entries) => entries.forEach((e) => { if (e.isIntersecting) { e.target.classList.add("revealed"); obs.unobserve(e.target); } }),
      { threshold: 0.1, rootMargin: "0px 0px -40px 0px" }
    );
    const t = setTimeout(() => el.querySelectorAll(".reveal, .reveal-left, .reveal-right").forEach((i) => obs.observe(i)), 60);
    return () => { clearTimeout(t); obs.disconnect(); };
  }, []);
  return ref;
}

function Stars({ rating, interactive = false, onChange }: { rating: number; interactive?: boolean; onChange?: (r: number) => void }) {
  const [hovered, setHovered] = useState(0);
  return (
    <div className="flex items-center gap-1">
      {[1, 2, 3, 4, 5].map((s) => (
        <button
          key={s}
          type={interactive ? "button" : undefined}
          className="transition-all"
          style={{ background: "none", border: "none", padding: "2px", cursor: interactive ? "pointer" : "default" }}
          onMouseEnter={() => interactive && setHovered(s)}
          onMouseLeave={() => interactive && setHovered(0)}
          onClick={() => interactive && onChange?.(s)}
        >
          <svg
            className={interactive ? "w-6 h-6" : "w-5 h-5"}
            fill="currentColor"
            viewBox="0 0 20 20"
            style={{
              color: s <= (interactive ? (hovered || rating) : rating) ? "#D4AF37" : "#242424",
              transition: "color 0.15s ease, transform 0.15s ease",
              transform: interactive && s <= (hovered || rating) ? "scale(1.15)" : "scale(1)",
            }}
          >
            <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
          </svg>
        </button>
      ))}
    </div>
  );
}

export default function Reviews() {
  const [filterRating, setFilterRating] = useState(0);
  const [showForm, setShowForm] = useState(false);
  const [newReview, setNewReview] = useState({ name: "", rating: 0, dish: "", text: "" });
  const [allReviews, setAllReviews] = useState(reviews);
  const [submitted, setSubmitted] = useState(false);
  const revealRef = useScrollReveal();

  const avgRating = allReviews.reduce((s, r) => s + r.rating, 0) / allReviews.length;
  const ratingDist = [5, 4, 3, 2, 1].map((n) => ({
    star: n,
    count: allReviews.filter((r) => r.rating === n).length,
    pct: (allReviews.filter((r) => r.rating === n).length / allReviews.length) * 100,
  }));

  const filtered = filterRating > 0 ? allReviews.filter((r) => r.rating === filterRating) : allReviews;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newReview.text || !newReview.rating) return;
    setAllReviews([
      {
        id: `r${Date.now()}`,
        name: newReview.name || "Anonymous Guest",
        avatar: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=80&h=80&fit=crop&auto=format",
        rating: newReview.rating,
        date: new Date().toLocaleDateString("en-GB", { year: "numeric", month: "long", day: "numeric" }),
        text: newReview.text,
        dish: newReview.dish,
        verified: false,
      },
      ...allReviews,
    ]);
    setSubmitted(true);
    setShowForm(false);
    setNewReview({ name: "", rating: 0, dish: "", text: "" });
    setTimeout(() => setSubmitted(false), 5000);
  };

  return (
    <div className="min-h-screen" style={{ background: "#0A0A0A" }} ref={revealRef}>
      {/* Header */}
      <div className="pt-28 pb-14 px-6 text-center" style={{ background: "linear-gradient(to bottom, #0D0D0D, #0A0A0A)" }}>
        <p className="text-xs tracking-widest uppercase mb-3 font-mono animate-fade-in" style={{ color: "#D4AF37" }}>— Guest Voices —</p>
        <h1 className="font-display font-bold mb-4 animate-fade-in" style={{ color: "#F5F5F5", fontSize: "clamp(2.5rem, 7vw, 4.5rem)", animationDelay: "0.1s" }}>
          Reviews & Ratings
        </h1>
        <p className="text-base max-w-md mx-auto animate-fade-in" style={{ color: "#6A6A6A", animationDelay: "0.15s" }}>
          Real guests, real experiences. See why Malta loves The Kitchen.
        </p>
      </div>

      <div className="max-w-5xl mx-auto px-6 pb-24">
        {/* Rating overview */}
        <div className="rounded-2xl p-8 mb-8 reveal" style={{ background: "#111111", border: "1px solid rgba(255,255,255,0.05)" }}>
          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div className="text-center">
              <div className="font-display font-black mb-2 gold-gradient" style={{ fontSize: "clamp(4rem, 10vw, 6rem)", lineHeight: 1 }}>
                {avgRating.toFixed(1)}
              </div>
              <Stars rating={Math.round(avgRating)} />
              <p className="text-sm mt-3 font-mono" style={{ color: "#5A5A5A" }}>Based on {allReviews.length} verified reviews</p>
            </div>
            <div className="space-y-2.5">
              {ratingDist.map((d) => (
                <button
                  key={d.star}
                  onClick={() => setFilterRating(filterRating === d.star ? 0 : d.star)}
                  className="w-full flex items-center gap-3 text-sm transition-all rounded-lg px-2 py-1.5"
                  style={{
                    opacity: filterRating && filterRating !== d.star ? 0.35 : 1,
                    background: filterRating === d.star ? "rgba(212,175,55,0.06)" : "transparent",
                  }}
                >
                  <span className="w-4 text-right shrink-0 font-mono text-xs" style={{ color: "#5A5A5A" }}>{d.star}</span>
                  <svg className="w-3.5 h-3.5 shrink-0 star-filled" fill="currentColor" viewBox="0 0 20 20">
                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                  </svg>
                  <div className="flex-1 rounded-full overflow-hidden" style={{ height: "6px", background: "#1E1E1E" }}>
                    <div
                      className="h-full rounded-full transition-all duration-700"
                      style={{ width: `${d.pct}%`, background: "linear-gradient(90deg, #B8912A, #D4AF37, #F0D060)" }}
                    />
                  </div>
                  <span className="w-5 text-xs shrink-0 font-mono text-right" style={{ color: "#5A5A5A" }}>{d.count}</span>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Actions bar */}
        <div className="flex items-center justify-between mb-6 flex-wrap gap-4">
          <div>
            {filterRating > 0 ? (
              <button
                onClick={() => setFilterRating(0)}
                className="text-sm flex items-center gap-2 transition-all"
                style={{ color: "#D4AF37" }}
              >
                ← Show all ({allReviews.length} reviews)
              </button>
            ) : (
              <p className="text-sm font-mono" style={{ color: "#5A5A5A" }}>
                <span style={{ color: "#D4AF37" }}>{filtered.length}</span> reviews
              </p>
            )}
          </div>
          <button
            onClick={() => setShowForm(!showForm)}
            className={showForm ? "btn-outline-gold px-5 py-2.5 rounded-full text-sm font-semibold" : "btn-gold px-5 py-2.5 rounded-full text-sm font-semibold"}
          >
            {showForm ? "× Cancel" : "✍ Write a Review"}
          </button>
        </div>

        {/* Success toast */}
        {submitted && (
          <div className="rounded-xl p-4 mb-6 flex gap-3 items-center animate-slide-down" style={{ background: "rgba(94,196,94,0.08)", border: "1px solid rgba(94,196,94,0.25)" }}>
            <span style={{ color: "#5EC45E", fontSize: "18px" }}>✓</span>
            <span className="text-sm" style={{ color: "#5EC45E" }}>Your review is live — thank you for sharing your experience!</span>
          </div>
        )}

        {/* Review form */}
        {showForm && (
          <div className="rounded-2xl p-7 mb-8 animate-slide-down" style={{ background: "#111111", border: "1px solid rgba(212,175,55,0.2)" }}>
            <h3 className="font-display text-xl font-semibold mb-6" style={{ color: "#F5F5F5" }}>Share Your Experience</h3>
            <form onSubmit={handleSubmit} className="space-y-5">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium mb-2" style={{ color: "#6A6A6A" }}>Your Name</label>
                  <input value={newReview.name} onChange={(e) => setNewReview({ ...newReview, name: e.target.value })} placeholder="Anonymous" />
                </div>
                <div>
                  <label className="block text-xs font-medium mb-2" style={{ color: "#6A6A6A" }}>Dish Ordered</label>
                  <input value={newReview.dish} onChange={(e) => setNewReview({ ...newReview, dish: e.target.value })} placeholder="e.g. Truffle Deluxe Burger" />
                </div>
              </div>
              <div>
                <label className="block text-xs font-medium mb-3" style={{ color: "#6A6A6A" }}>Your Rating *</label>
                <Stars rating={newReview.rating} interactive onChange={(r) => setNewReview({ ...newReview, rating: r })} />
              </div>
              <div>
                <label className="block text-xs font-medium mb-2" style={{ color: "#6A6A6A" }}>Your Review *</label>
                <textarea
                  required
                  rows={4}
                  value={newReview.text}
                  onChange={(e) => setNewReview({ ...newReview, text: e.target.value })}
                  placeholder="Share what made your experience memorable…"
                  style={{ resize: "none" }}
                />
              </div>
              <button type="submit" className="btn-gold px-7 py-3 rounded-xl text-sm font-semibold uppercase tracking-wide">
                Submit Review
              </button>
            </form>
          </div>
        )}

        {/* Reviews list */}
        <div className="space-y-4">
          {filtered.map((review, i) => (
            <div
              key={review.id}
              className={`card-hover rounded-2xl p-6 reveal stagger-${Math.min((i % 3) + 1, 6)}`}
              style={{ background: "#111111", border: "1px solid rgba(255,255,255,0.05)" }}
            >
              <div className="flex items-start gap-4">
                <img
                  src={review.avatar}
                  alt={review.name}
                  loading="lazy"
                  decoding="async"
                  className="w-11 h-11 rounded-full object-cover shrink-0"
                  width={44}
                  height={44}
                />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap mb-1">
                    <span className="font-semibold text-sm" style={{ color: "#F5F5F5" }}>{review.name}</span>
                    {review.verified && (
                      <span className="text-xs px-2 py-0.5 rounded-full font-mono" style={{ background: "rgba(212,175,55,0.08)", color: "#D4AF37", border: "1px solid rgba(212,175,55,0.18)" }}>
                        ✓ Verified
                      </span>
                    )}
                  </div>
                  <div className="flex items-center gap-3">
                    <Stars rating={review.rating} />
                    <span className="text-xs font-mono" style={{ color: "#3A3A3A" }}>{review.date}</span>
                  </div>
                  {review.dish && (
                    <p className="text-xs mt-1.5 font-mono" style={{ color: "#5A5A5A" }}>
                      Ordered: <span style={{ color: "#D4AF37" }}>{review.dish}</span>
                    </p>
                  )}
                  <p className="text-sm leading-relaxed mt-3 font-display italic" style={{ color: "#C0C0C0" }}>
                    "{review.text}"
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {filtered.length === 0 && (
          <div className="text-center py-20 animate-fade-in">
            <div className="text-4xl mb-4">⭐</div>
            <p className="text-sm" style={{ color: "#5A5A5A" }}>No reviews at this rating yet.</p>
          </div>
        )}
      </div>
    </div>
  );
}
