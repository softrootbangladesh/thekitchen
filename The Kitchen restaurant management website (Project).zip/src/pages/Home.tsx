import { useState, useEffect, useCallback, useRef, memo } from "react";
import { menuItems } from "../data/menuData";

interface HomeProps {
  onNavigate: (page: string) => void;
  onAddToCart: (item: (typeof menuItems)[0]) => void;
}

const HERO_SLIDES = [
  {
    image: "https://images.unsplash.com/photo-1414235077428-338989a2e8c0?w=1600&h=900&fit=crop&auto=format&q=85",
    alt: "The Kitchen Malta fine dining ambience",
    label: "Fine Dining",
  },
  {
    image: "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=1600&h=900&fit=crop&auto=format&q=85",
    alt: "Premium burger at The Kitchen Malta",
    label: "Premium Burgers",
  },
  {
    image: "https://images.unsplash.com/photo-1544025162-d76538780aa1?w=1600&h=900&fit=crop&auto=format&q=85",
    alt: "Texas Brisket — 24h smoked",
    label: "Smokehouse Collection",
  },
  {
    image: "https://images.unsplash.com/photo-1574071318508-1cdbab80d002?w=1600&h=900&fit=crop&auto=format&q=85",
    alt: "Artisan pizza at The Kitchen Malta",
    label: "Artisan Pizzas",
  },
];

const TYPEWRITER_PHRASES = [
  "Made With Passion.",
  "100% Halal. 100% Delicious.",
  "Burgers, Pizzas & Smokehouse.",
  "Malta's Finest Kitchen.",
];

const STATS = [
  { value: "100%", label: "Halal Certified", icon: "✓" },
  { value: "4.9★", label: "Guest Rating", icon: "⭐" },
  { value: "30 min", label: "Avg Delivery", icon: "🛵" },
  { value: "Est. 2019", label: "Years of Passion", icon: "🔥" },
];

const CATEGORIES = [
  { key: "burgers", label: "Burgers", icon: "🍔", desc: "Handcrafted & Juicy" },
  { key: "pizzas", label: "Pizzas", icon: "🍕", desc: "Stone-fired Perfection" },
  { key: "wraps", label: "Wraps", icon: "🌯", desc: "Fresh & Flavourful" },
  { key: "sides", label: "Sides", icon: "🍟", desc: "Perfect Companions" },
  { key: "smokehouse", label: "Smokehouse", icon: "🔥", desc: "24h Slow-smoked" },
];

function useTypewriter(phrases: string[], speed = 72, pauseMs = 2400) {
  const [displayed, setDisplayed] = useState("");
  const [phraseIdx, setPhraseIdx] = useState(0);
  const [charIdx, setCharIdx] = useState(0);
  const [deleting, setDeleting] = useState(false);

  useEffect(() => {
    const current = phrases[phraseIdx] ?? "";
    let timer: ReturnType<typeof setTimeout>;
    if (!deleting && charIdx < current.length) {
      timer = setTimeout(() => setCharIdx((c) => c + 1), speed);
    } else if (!deleting && charIdx === current.length) {
      timer = setTimeout(() => setDeleting(true), pauseMs);
    } else if (deleting && charIdx > 0) {
      timer = setTimeout(() => setCharIdx((c) => c - 1), speed / 2);
    } else if (deleting && charIdx === 0) {
      setDeleting(false);
      setPhraseIdx((i) => (i + 1) % phrases.length);
    }
    return () => clearTimeout(timer);
  }, [charIdx, deleting, phraseIdx, phrases, speed, pauseMs]);

  useEffect(() => {
    setDisplayed((phrases[phraseIdx] ?? "").slice(0, charIdx));
  }, [charIdx, phraseIdx, phrases]);

  return displayed;
}

function useScrollReveal() {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!ref.current) return;
    const el = ref.current;
    const obs = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) {
            e.target.classList.add("revealed");
            obs.unobserve(e.target);
          }
        });
      },
      { threshold: 0.1, rootMargin: "0px 0px -40px 0px" }
    );
    // Observe all reveal elements in the whole page, not just one section
    const observe = () => {
      el.querySelectorAll(".reveal, .reveal-left, .reveal-right").forEach((item) => obs.observe(item));
    };
    observe();
    // Re-observe on a short delay in case DOM isn't fully painted
    const t = setTimeout(observe, 100);
    return () => { clearTimeout(t); obs.disconnect(); };
  }, []);
  return ref;
}

function StarRating({ rating }: { rating: number }) {
  return (
    <div className="flex items-center gap-0.5">
      {[1, 2, 3, 4, 5].map((s) => (
        <svg key={s} className={`w-3.5 h-3.5 ${s <= Math.round(rating) ? "star-filled" : "star-empty"}`} fill="currentColor" viewBox="0 0 20 20">
          <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
        </svg>
      ))}
      <span className="text-xs ml-1.5 font-mono" style={{ color: "#6A6A6A" }}>{rating}</span>
    </div>
  );
}

const DishCard = memo(function DishCard({ dish, onAddToCart }: { dish: typeof menuItems[0]; onAddToCart: (item: typeof menuItems[0]) => void }) {
  const [added, setAdded] = useState(false);

  const handleAdd = () => {
    onAddToCart(dish);
    setAdded(true);
    setTimeout(() => setAdded(false), 1200);
  };

  return (
    <div className="card-hover rounded-2xl overflow-hidden flex flex-col" style={{ background: "#141414", border: "1px solid rgba(255,255,255,0.05)" }}>
      <div className="relative img-zoom-wrap" style={{ height: "210px", background: "#1A1A1A" }}>
        <img
          src={dish.image}
          alt={dish.name}
          loading="lazy"
          decoding="async"
          className="w-full h-full object-cover"
          width={400}
          height={210}
        />
        <div className="absolute inset-0" style={{ background: "linear-gradient(to top, rgba(10,10,10,0.85) 0%, rgba(10,10,10,0.1) 60%)" }} />
        <div className="absolute top-3 left-3 flex gap-1.5 flex-wrap">
          <span className={`text-xs px-2.5 py-1 rounded-full font-medium font-mono ${dish.diet === "veg" || dish.diet === "vegan" ? "tag-veg" : "tag-nonveg"}`}>
            {dish.diet === "veg" ? "🌱 Veg" : dish.diet === "vegan" ? "🌱 Vegan" : "● Halal"}
          </span>
          {dish.spicy && <span className="text-xs px-2.5 py-1 rounded-full tag-spicy font-mono">🌶</span>}
        </div>
        {dish.tags?.[0] && (
          <div className="absolute top-3 right-3">
            <span className="text-xs px-2.5 py-1 rounded-full font-semibold font-mono" style={{ background: "rgba(212,175,55,0.2)", color: "#D4AF37", border: "1px solid rgba(212,175,55,0.35)" }}>
              {dish.tags[0]}
            </span>
          </div>
        )}
        <div className="absolute bottom-3 right-3">
          <span className="font-mono font-bold text-lg" style={{ color: "#D4AF37", textShadow: "0 2px 8px rgba(0,0,0,0.8)" }}>€{dish.price.toFixed(2)}</span>
        </div>
      </div>
      <div className="p-4 flex flex-col flex-1">
        <div className="mb-1">
          <h3 className="font-display font-semibold leading-tight" style={{ color: "#F5F5F5", fontSize: "15px" }}>{dish.name}</h3>
          {dish.nameAr && <p className="text-xs mt-0.5 font-mono" style={{ color: "#5A5A5A", direction: "rtl" }}>{dish.nameAr}</p>}
        </div>
        <StarRating rating={dish.rating} />
        <p className="text-xs mt-2 leading-relaxed flex-1 line-clamp-2" style={{ color: "#7A7A7A" }}>{dish.description}</p>
        <button
          onClick={handleAdd}
          className="w-full mt-4 py-2.5 rounded-xl text-xs font-semibold uppercase tracking-wider transition-all duration-300"
          style={{
            background: added ? "rgba(94,196,94,0.15)" : "linear-gradient(135deg, #D4AF37, #E8C96B)",
            color: added ? "#5EC45E" : "#0D0D0D",
            border: added ? "1px solid rgba(94,196,94,0.3)" : "none",
            boxShadow: added ? "0 0 16px rgba(94,196,94,0.2)" : "0 4px 16px rgba(212,175,55,0.25)",
          }}
        >
          {added ? "✓ Added!" : "Add to Cart"}
        </button>
      </div>
    </div>
  );
});

const featuredDishes = menuItems.filter((i) => i.popular && !i.soldOut).slice(0, 4);

export default function Home({ onNavigate, onAddToCart }: HomeProps) {
  const [slideIdx, setSlideIdx] = useState(0);
  const [transitioning, setTransitioning] = useState(false);
  const typewriterText = useTypewriter(TYPEWRITER_PHRASES);
  const revealRef = useScrollReveal();

  const changeSlide = useCallback((idx: number) => {
    setTransitioning(true);
    setTimeout(() => {
      setSlideIdx(idx);
      setTransitioning(false);
    }, 200);
  }, []);

  const nextSlide = useCallback(() => {
    setSlideIdx((i) => {
      const next = (i + 1) % HERO_SLIDES.length;
      changeSlide(next);
      return i;
    });
  }, [changeSlide]);

  const prevSlide = useCallback(() => {
    setSlideIdx((i) => {
      const prev = (i - 1 + HERO_SLIDES.length) % HERO_SLIDES.length;
      changeSlide(prev);
      return i;
    });
  }, [changeSlide]);

  useEffect(() => {
    const timer = setInterval(() => {
      setSlideIdx((i) => (i + 1) % HERO_SLIDES.length);
    }, 5500);
    return () => clearInterval(timer);
  }, []);

  return (
    <div ref={revealRef}>
      {/* ── HERO ─────────────────────────────────────────────────── */}
      <section className="relative overflow-hidden" style={{ height: "100vh", minHeight: "640px" }}>
        {HERO_SLIDES.map((slide, i) => (
          <div
            key={slide.image}
            className="absolute inset-0"
            style={{
              opacity: i === slideIdx ? 1 : 0,
              zIndex: i === slideIdx ? 1 : 0,
              transition: "opacity 1.2s ease",
            }}
          >
            <img
              src={slide.image}
              alt={slide.alt}
              fetchPriority={i === 0 ? "high" : "low"}
              loading={i === 0 ? "eager" : "lazy"}
              decoding="async"
              className="w-full h-full object-cover"
              width={1600}
              height={900}
            />
          </div>
        ))}

        {/* Overlays */}
        <div className="hero-overlay absolute inset-0" style={{ zIndex: 2 }} />
        <div className="absolute inset-0" style={{ zIndex: 2, background: "radial-gradient(ellipse at 60% 50%, transparent 30%, rgba(13,13,13,0.7) 100%)" }} />

        {/* Slide label */}
        <div className="absolute bottom-28 left-8 md:left-16" style={{ zIndex: 4 }}>
          <span className="text-xs font-mono tracking-widest uppercase" style={{ color: "rgba(212,175,55,0.6)" }}>
            {String(slideIdx + 1).padStart(2, "0")} / {String(HERO_SLIDES.length).padStart(2, "0")} — {HERO_SLIDES[slideIdx].label}
          </span>
        </div>

        {/* Hero content */}
        <div className="relative flex flex-col items-center justify-center h-full text-center px-6" style={{ zIndex: 3 }}>
          <div className="animate-fade-in" style={{ animationDelay: "0.1s" }}>
            <div className="flex items-center justify-center gap-4 mb-7 flex-wrap">
              <div className="flex items-center gap-2 text-xs font-mono tracking-widest uppercase" style={{ color: "rgba(212,175,55,0.75)" }}>
                <span style={{ width: "24px", height: "1px", background: "rgba(212,175,55,0.5)", display: "inline-block" }} />
                Malta · Est. 2019
                <span style={{ width: "24px", height: "1px", background: "rgba(212,175,55,0.5)", display: "inline-block" }} />
              </div>
              <span className="halal-badge">✓ 100% Halal</span>
            </div>
          </div>

          <h1
            className="font-display font-black leading-none mb-7 animate-fade-in"
            style={{ color: "#F5F5F5", fontSize: "clamp(3rem, 9vw, 6.5rem)", animationDelay: "0.2s" }}
          >
            <span className="gold-gradient-animated italic block">The Kitchen</span>
            <span className="block mt-1 relative" style={{ fontSize: "clamp(1.4rem, 4vw, 3rem)", color: "#E8E8E8", fontWeight: 700 }}>
              {typewriterText}
              <span
                className="inline-block w-[3px] ml-1 animate-pulse"
                style={{ height: "0.8em", background: "#D4AF37", verticalAlign: "middle", borderRadius: "1px" }}
              />
            </span>
          </h1>

          <p
            className="text-base md:text-lg mb-10 max-w-xl mx-auto leading-relaxed animate-fade-in"
            style={{ color: "rgba(200,200,200,0.85)", animationDelay: "0.3s" }}
          >
            Premium burgers, artisan pizzas, and 24-hour smoked BBQ — all 100% Halal, crafted with the finest ingredients.
          </p>

          <div className="flex flex-wrap items-center justify-center gap-4 animate-fade-in" style={{ animationDelay: "0.4s" }}>
            <button
              onClick={() => onNavigate("menu")}
              className="btn-gold px-9 py-4 rounded-full text-sm font-semibold tracking-wider uppercase"
            >
              Explore Menu
            </button>
            <button
              onClick={() => onNavigate("order")}
              className="btn-outline-gold px-9 py-4 rounded-full text-sm font-semibold tracking-wider uppercase"
            >
              Order Now
            </button>
          </div>
        </div>

        {/* Slide controls */}
        <div className="absolute bottom-16 left-1/2 -translate-x-1/2 flex gap-2" style={{ zIndex: 4 }}>
          {HERO_SLIDES.map((_, i) => (
            <button
              key={i}
              onClick={() => setSlideIdx(i)}
              className="transition-all duration-400"
              style={{
                width: i === slideIdx ? "32px" : "8px",
                height: "4px",
                borderRadius: "2px",
                background: i === slideIdx ? "#D4AF37" : "rgba(212,175,55,0.25)",
              }}
            />
          ))}
        </div>

        <button
          onClick={prevSlide}
          className="absolute left-4 md:left-6 top-1/2 -translate-y-1/2 w-11 h-11 rounded-full flex items-center justify-center transition-all"
          style={{ zIndex: 4, background: "rgba(13,13,13,0.5)", border: "1px solid rgba(212,175,55,0.25)", color: "#D4AF37", backdropFilter: "blur(8px)" }}
          onMouseEnter={(e) => (e.currentTarget.style.background = "rgba(212,175,55,0.15)")}
          onMouseLeave={(e) => (e.currentTarget.style.background = "rgba(13,13,13,0.5)")}
          aria-label="Previous slide"
        >
          <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" /></svg>
        </button>
        <button
          onClick={nextSlide}
          className="absolute right-4 md:right-6 top-1/2 -translate-y-1/2 w-11 h-11 rounded-full flex items-center justify-center transition-all"
          style={{ zIndex: 4, background: "rgba(13,13,13,0.5)", border: "1px solid rgba(212,175,55,0.25)", color: "#D4AF37", backdropFilter: "blur(8px)" }}
          onMouseEnter={(e) => (e.currentTarget.style.background = "rgba(212,175,55,0.15)")}
          onMouseLeave={(e) => (e.currentTarget.style.background = "rgba(13,13,13,0.5)")}
          aria-label="Next slide"
        >
          <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" /></svg>
        </button>

        {/* Scroll cue */}
        <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex flex-col items-center gap-1.5" style={{ zIndex: 4, opacity: 0.4 }}>
          <span className="text-xs font-mono tracking-widest" style={{ color: "#D4AF37", fontSize: "9px" }}>SCROLL</span>
          <div className="w-px h-8" style={{ background: "linear-gradient(to bottom, #D4AF37, transparent)" }} />
        </div>
      </section>

      {/* ── STATS BAR ──────────────────────────────────────────────── */}
      <section style={{ background: "#111111", borderTop: "1px solid rgba(255,255,255,0.04)", borderBottom: "1px solid rgba(255,255,255,0.04)" }}>
        <div className="max-w-5xl mx-auto px-6 py-10 grid grid-cols-2 md:grid-cols-4 gap-0">
          {STATS.map((stat, i) => (
            <div
              key={stat.label}
              className="text-center px-4 py-2"
              style={{ borderRight: i < STATS.length - 1 ? "1px solid rgba(255,255,255,0.05)" : "none" }}
            >
              <div className="text-2xl mb-2">{stat.icon}</div>
              <div className="font-display text-2xl font-bold mb-1 gold-gradient">{stat.value}</div>
              <div className="text-xs font-mono tracking-widest uppercase" style={{ color: "#4A4A4A" }}>{stat.label}</div>
            </div>
          ))}
        </div>
      </section>

      {/* ── BROWSE CATEGORIES ─────────────────────────────────────── */}
      <section className="py-20 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12 reveal">
            <p className="text-xs tracking-widest uppercase mb-3 font-mono" style={{ color: "#D4AF37" }}>— Explore —</p>
            <h2 className="font-display text-4xl font-bold" style={{ color: "#F5F5F5" }}>Browse by Category</h2>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
            {CATEGORIES.map((cat, i) => (
              <button
                key={cat.key}
                onClick={() => onNavigate("menu")}
                className={`reveal card-hover rounded-2xl p-5 text-center flex flex-col items-center gap-3 stagger-${i + 1}`}
                style={{ background: "#141414", border: "1px solid rgba(255,255,255,0.05)" }}
                onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.borderColor = "rgba(212,175,55,0.3)"; }}
                onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.borderColor = "rgba(255,255,255,0.05)"; }}
              >
                <span className="text-4xl">{cat.icon}</span>
                <div>
                  <div className="font-display font-semibold text-sm" style={{ color: "#F5F5F5" }}>{cat.label}</div>
                  <div className="text-xs mt-0.5 font-mono" style={{ color: "#5A5A5A" }}>{cat.desc}</div>
                </div>
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* ── FEATURED DISHES ───────────────────────────────────────── */}
      <section className="py-20 px-6" style={{ background: "#0A0A0A" }}>
        <div className="max-w-6xl mx-auto">
          <div className="flex items-end justify-between mb-12">
            <div className="reveal-left">
              <p className="text-xs tracking-widest uppercase mb-3 font-mono" style={{ color: "#D4AF37" }}>— Our Bestsellers —</p>
              <h2 className="font-display text-5xl font-bold" style={{ color: "#F5F5F5" }}>Featured Dishes</h2>
              <p className="mt-2 text-sm" style={{ color: "#6A6A6A" }}>Hand-picked favourites from our kitchen</p>
            </div>
            <button onClick={() => onNavigate("menu")} className="btn-outline-gold px-5 py-2.5 rounded-full text-xs font-semibold tracking-wide uppercase hidden md:block reveal-right">
              View All →
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {featuredDishes.map((dish, i) => (
              <div key={dish.id} className={`reveal stagger-${i + 1}`}>
                <DishCard dish={dish} onAddToCart={onAddToCart} />
              </div>
            ))}
          </div>

          <div className="text-center mt-10 md:hidden">
            <button onClick={() => onNavigate("menu")} className="btn-outline-gold px-7 py-3 rounded-full text-sm font-semibold tracking-wide uppercase">
              View Full Menu →
            </button>
          </div>
        </div>
      </section>

      {/* ── OUR PROMISE ───────────────────────────────────────────── */}
      <section className="py-24 px-6" style={{ background: "#0D0D0D" }}>
        <div className="max-w-6xl mx-auto grid md:grid-cols-2 gap-16 items-center">
          <div className="reveal-left order-2 md:order-1">
            <p className="text-xs tracking-widest uppercase mb-4 font-mono" style={{ color: "#D4AF37" }}>— Our Promise —</p>
            <h2 className="font-display text-5xl font-bold leading-tight mb-6" style={{ color: "#F5F5F5" }}>
              Fresh Ingredients.<br />
              <em style={{ color: "#D4AF37" }}>Made With Passion.</em>
            </h2>
            <p className="text-base leading-relaxed mb-4" style={{ color: "#7A7A7A" }}>
              At The Kitchen Malta, every dish is crafted with the finest ingredients and cooked with genuine care. Our beef is 100% Halal, our produce is sourced fresh daily, and our smokehouse runs 24 hours to deliver perfection.
            </p>
            <p className="text-base leading-relaxed mb-8" style={{ color: "#7A7A7A" }}>
              From our signature burgers to the slow-smoked Texas Brisket, we believe great food starts with honest ingredients and ends with a smile.
            </p>
            <div className="flex gap-2.5 flex-wrap mb-8">
              {["Fresh Daily", "100% Halal", "Premium Beef", "Artisan Recipes", "No Additives"].map((badge) => (
                <span
                  key={badge}
                  className="text-xs px-3.5 py-1.5 rounded-full font-mono font-semibold transition-all"
                  style={{ background: "rgba(212,175,55,0.07)", border: "1px solid rgba(212,175,55,0.18)", color: "#D4AF37" }}
                  onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.background = "rgba(212,175,55,0.15)"; }}
                  onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.background = "rgba(212,175,55,0.07)"; }}
                >
                  {badge}
                </span>
              ))}
            </div>
            <button onClick={() => onNavigate("about")} className="btn-outline-gold px-7 py-3 rounded-full text-sm font-semibold tracking-wide uppercase">
              Our Story →
            </button>
          </div>
          <div className="relative order-1 md:order-2 reveal-right">
            <div className="rounded-2xl overflow-hidden img-zoom-wrap" style={{ border: "1px solid rgba(212,175,55,0.15)" }}>
              <img
                src="https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=700&h=520&fit=crop&auto=format&q=80"
                alt="The Kitchen Malta dining room"
                loading="lazy"
                decoding="async"
                className="w-full object-cover"
                style={{ height: "440px" }}
                width={700}
                height={440}
              />
            </div>
            {/* Floating review card */}
            <div
              className="absolute -bottom-6 -left-6 rounded-2xl p-5 hidden md:block animate-float"
              style={{ background: "#1A1A1A", border: "1px solid rgba(212,175,55,0.25)", boxShadow: "0 8px 32px rgba(0,0,0,0.6)" }}
            >
              <div className="font-display text-3xl font-bold gold-gradient">4.9</div>
              <div className="flex gap-0.5 mt-1.5">
                {[1,2,3,4,5].map(s => (
                  <svg key={s} className="w-3.5 h-3.5 star-filled" fill="currentColor" viewBox="0 0 20 20">
                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                  </svg>
                ))}
              </div>
              <div className="text-xs mt-1.5 font-mono" style={{ color: "#6A6A6A" }}>500+ Reviews</div>
            </div>
            {/* Halal badge */}
            <div className="absolute -top-4 -right-4 hidden md:flex items-center gap-2 px-4 py-2 rounded-full" style={{ background: "rgba(74,174,74,0.12)", border: "1px solid rgba(94,196,94,0.3)", backdropFilter: "blur(8px)" }}>
              <span style={{ color: "#5EC45E", fontSize: "16px" }}>✓</span>
              <span className="text-xs font-mono font-semibold" style={{ color: "#5EC45E" }}>100% Halal</span>
            </div>
          </div>
        </div>
      </section>

      {/* ── SMOKEHOUSE SPOTLIGHT ──────────────────────────────────── */}
      <section className="py-20 px-6" style={{ background: "#080808" }}>
        <div className="max-w-6xl mx-auto reveal">
          <div className="rounded-3xl overflow-hidden relative" style={{ minHeight: "400px", border: "1px solid rgba(212,175,55,0.15)" }}>
            <img
              src="https://images.unsplash.com/photo-1544025162-d76538780aa1?w=1400&h=560&fit=crop&auto=format&q=80"
              alt="The Smokehouse Collection"
              loading="lazy"
              decoding="async"
              className="absolute inset-0 w-full h-full object-cover"
            />
            <div className="absolute inset-0" style={{ background: "linear-gradient(105deg, rgba(8,8,8,0.97) 0%, rgba(8,8,8,0.85) 45%, rgba(8,8,8,0.2) 100%)" }} />
            <div className="relative p-10 md:p-16 flex flex-col justify-center" style={{ minHeight: "400px", maxWidth: "560px" }}>
              <span className="text-xs tracking-widest uppercase mb-4 font-mono inline-block" style={{ color: "#D4AF37" }}>🔥 The Smokehouse Collection</span>
              <h2 className="font-display text-4xl md:text-5xl font-bold mb-5 leading-tight" style={{ color: "#F5F5F5" }}>
                24 Hours of Smoke.<br />
                <em style={{ color: "#D4AF37" }}>A Lifetime of Flavour.</em>
              </h2>
              <p className="text-base mb-8 leading-relaxed" style={{ color: "#8A8A8A" }}>
                Our Texas Brisket is smoked for 24 hours. Our chicken kissed with applewood. Our lamb shank falls off the bone. Serious BBQ, done right.
              </p>
              <div className="flex gap-3 flex-wrap">
                <button onClick={() => onNavigate("menu")} className="btn-gold px-8 py-3.5 rounded-full text-sm font-semibold tracking-wide uppercase">
                  View Smokehouse →
                </button>
                <button onClick={() => onNavigate("order")} className="btn-outline-gold px-8 py-3.5 rounded-full text-sm font-semibold tracking-wide uppercase">
                  Order Now
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── TESTIMONIALS ──────────────────────────────────────────── */}
      <section className="py-20 px-6" style={{ background: "#0D0D0D" }}>
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-14 reveal">
            <p className="text-xs tracking-widest uppercase mb-3 font-mono" style={{ color: "#D4AF37" }}>— What Guests Say —</p>
            <h2 className="font-display text-4xl font-bold" style={{ color: "#F5F5F5" }}>Malta Loves The Kitchen</h2>
          </div>
          <div className="grid md:grid-cols-3 gap-5">
            {[
              { quote: "The Texas Brisket is unlike anything I've had in Malta. 24 hours of smoking shows — absolutely worth every cent.", author: "Ahmed A.", title: "Regular Guest", rating: 5 },
              { quote: "Finally a 100% halal place in Malta that doesn't compromise on quality. The Smoked Lamb Shank was outstanding.", author: "Khalid M.", title: "Food Blogger", rating: 5 },
              { quote: "The Truffle Deluxe burger is extraordinary. You can taste the quality of every ingredient. My new favourite spot.", author: "Maria G.", title: "Restaurant Reviewer", rating: 5 },
            ].map((t, i) => (
              <div
                key={t.author}
                className={`reveal card-hover rounded-2xl p-7 stagger-${i + 1}`}
                style={{ background: "#111111", border: "1px solid rgba(255,255,255,0.05)" }}
              >
                <div className="flex gap-0.5 mb-4">
                  {[1,2,3,4,5].map(s => (
                    <svg key={s} className="w-4 h-4 star-filled" fill="currentColor" viewBox="0 0 20 20">
                      <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                    </svg>
                  ))}
                </div>
                <p className="text-sm leading-relaxed mb-5 font-display italic" style={{ color: "#C0C0C0" }}>"{t.quote}"</p>
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-full flex items-center justify-center text-sm font-bold shrink-0" style={{ background: "linear-gradient(135deg, #D4AF37, #E8C96B)", color: "#0D0D0D" }}>
                    {t.author[0]}
                  </div>
                  <div>
                    <div className="text-sm font-semibold" style={{ color: "#F0F0F0" }}>{t.author}</div>
                    <div className="text-xs font-mono" style={{ color: "#5A5A5A" }}>{t.title}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── CTA SECTION ───────────────────────────────────────────── */}
      <section className="py-20 px-6" style={{ background: "#080808" }}>
        <div className="max-w-3xl mx-auto text-center reveal">
          <div className="rounded-3xl p-12 relative overflow-hidden" style={{ background: "linear-gradient(135deg, #141414 0%, #1A1A0A 100%)", border: "1px solid rgba(212,175,55,0.2)" }}>
            {/* BG glow */}
            <div className="absolute inset-0 pointer-events-none" style={{ background: "radial-gradient(ellipse at 50% 0%, rgba(212,175,55,0.08) 0%, transparent 70%)" }} />
            <p className="text-xs tracking-widest uppercase mb-4 font-mono relative" style={{ color: "#D4AF37" }}>— Ready to Dine? —</p>
            <h2 className="font-display text-4xl md:text-5xl font-bold mb-4 relative" style={{ color: "#F5F5F5" }}>
              Book Your Table or<br /><span className="gold-gradient">Order Online</span>
            </h2>
            <p className="text-base mb-8 leading-relaxed relative" style={{ color: "#7A7A7A" }}>
              Whether you're dining in or ordering to your door — The Kitchen Malta is always ready to serve you something extraordinary.
            </p>
            <div className="flex gap-4 justify-center flex-wrap relative">
              <button onClick={() => onNavigate("reservation")} className="btn-gold px-8 py-4 rounded-full text-sm font-semibold tracking-wide uppercase">
                Book a Table
              </button>
              <button onClick={() => onNavigate("order")} className="btn-outline-gold px-8 py-4 rounded-full text-sm font-semibold tracking-wide uppercase">
                Order Delivery
              </button>
            </div>
            <p className="mt-6 text-xs font-mono relative" style={{ color: "#3A3A3A" }}>
              📞 +356 99119100 · Open 7 days a week
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}
