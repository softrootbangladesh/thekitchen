import { useState, useEffect } from "react";

const ORDER_STAGES = [
  { key: "confirmed", label: "Order Confirmed", desc: "We've received your order and are processing it.", icon: "✓", time: "12:45 PM" },
  { key: "preparing", label: "Preparing", desc: "Chef Elara's team is crafting your dishes with care.", icon: "👨‍🍳", time: "12:50 PM" },
  { key: "quality", label: "Quality Check", desc: "Your order is being inspected for perfection.", icon: "⭐", time: "1:05 PM" },
  { key: "delivery", label: "Out for Delivery", desc: "Your rider Marco is on the way — 8 minutes away.", icon: "🛵", time: "1:15 PM" },
  { key: "delivered", label: "Delivered", desc: "Enjoy your meal! We hope it exceeds expectations.", icon: "🎉", time: "" },
];

export default function Tracking() {
  const [currentStage, setCurrentStage] = useState(2);
  const [eta, setEta] = useState(22);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentStage((s) => Math.min(s + 1, ORDER_STAGES.length - 1));
      setEta((e) => Math.max(0, e - 1));
    }, 6000);
    return () => clearInterval(interval);
  }, []);

  const progress = (currentStage / (ORDER_STAGES.length - 1)) * 100;

  return (
    <div className="min-h-screen pt-24 pb-24 px-6">
      <div className="max-w-3xl mx-auto">
        <div className="mb-10">
          <p className="text-xs tracking-widest uppercase mb-2 font-mono" style={{ color: "#D4AF37" }}>— Live Updates —</p>
          <h1 className="font-display text-4xl font-bold" style={{ color: "#F5F5F5" }}>Order Tracking</h1>
        </div>

        {/* Order info card */}
        <div className="rounded-2xl p-6 mb-8 flex flex-wrap items-center gap-6 justify-between" style={{ background: "#1E1E1E", border: "1px solid #2E2E2E" }}>
          <div>
            <div className="text-xs font-mono uppercase tracking-wider mb-1" style={{ color: "#A0A0A0" }}>Order Number</div>
            <div className="font-mono font-bold text-xl" style={{ color: "#D4AF37" }}>#TK-2847</div>

          </div>
          <div>
            <div className="text-xs font-mono uppercase tracking-wider mb-1" style={{ color: "#A0A0A0" }}>Placed At</div>
            <div className="font-semibold" style={{ color: "#F5F5F5" }}>12:45 PM · July 31, 2026</div>
          </div>
          <div>
            <div className="text-xs font-mono uppercase tracking-wider mb-1" style={{ color: "#A0A0A0" }}>Total</div>
            <div className="font-mono font-bold" style={{ color: "#D4AF37" }}>€38.60</div>
          </div>
          <div>
            {currentStage < ORDER_STAGES.length - 1 ? (
              <div className="text-center">
                <div className="text-xs font-mono uppercase tracking-wider mb-1" style={{ color: "#A0A0A0" }}>ETA</div>
                <div className="font-mono font-bold text-xl" style={{ color: "#F5F5F5" }}>~{eta} min</div>
              </div>
            ) : (
              <span className="px-4 py-2 rounded-full text-sm font-semibold status-delivered">Delivered!</span>
            )}
          </div>
        </div>

        {/* Progress bar */}
        <div className="progress-bar mb-10 rounded-full" style={{ height: "6px" }}>
          <div className="progress-fill rounded-full" style={{ width: `${progress}%` }} />
        </div>

        {/* Stages */}
        <div className="relative">
          <div
            className="absolute left-8 top-8 bottom-8 w-px"
            style={{ background: "linear-gradient(to bottom, #D4AF37, rgba(212,175,55,0.1))" }}
          />
          <div className="space-y-2">
            {ORDER_STAGES.map((stage, idx) => {
              const isCompleted = idx < currentStage;
              const isActive = idx === currentStage;
              const isPending = idx > currentStage;

              return (
                <div key={stage.key} className="flex items-start gap-6 pl-0 relative">
                  <div
                    className="w-16 h-16 rounded-full flex items-center justify-center shrink-0 z-10 transition-all duration-500"
                    style={{
                      background: isCompleted ? "#D4AF37" : isActive ? "rgba(212,175,55,0.15)" : "#1E1E1E",
                      border: isCompleted ? "2px solid #D4AF37" : isActive ? "2px solid #D4AF37" : "2px solid #2E2E2E",
                      boxShadow: isActive ? "0 0 24px rgba(212,175,55,0.3)" : "none",
                    }}
                  >
                    <span className={`text-xl ${isPending ? "opacity-30" : ""}`}>{stage.icon}</span>
                  </div>
                  <div
                    className="flex-1 rounded-xl p-4 mb-2 transition-all duration-500"
                    style={{
                      background: isActive ? "rgba(212,175,55,0.06)" : "#1A1A1A",
                      border: isActive ? "1px solid rgba(212,175,55,0.3)" : "1px solid #2A2A2A",
                      opacity: isPending ? 0.4 : 1,
                    }}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <h3 className="font-semibold text-sm" style={{ color: isCompleted || isActive ? "#F5F5F5" : "#6A6A6A" }}>
                        {stage.label}
                        {isActive && (
                          <span className="ml-2 text-xs font-mono px-2 py-0.5 rounded-full" style={{ background: "rgba(212,175,55,0.2)", color: "#D4AF37" }}>
                            In Progress
                          </span>
                        )}
                        {isCompleted && (
                          <span className="ml-2 text-xs font-mono px-2 py-0.5 rounded-full status-delivered">
                            Done
                          </span>
                        )}
                      </h3>
                      {stage.time && (
                        <span className="text-xs font-mono" style={{ color: "#5A5A5A" }}>{stage.time}</span>
                      )}
                    </div>
                    <p className="text-sm" style={{ color: "#A0A0A0" }}>{stage.desc}</p>

                    {isActive && stage.key === "delivery" && (
                      <div className="mt-3 rounded-lg overflow-hidden" style={{ height: "140px", background: "#2A2A2A", border: "1px solid #3A3A3A", position: "relative" }}>
                        <div className="absolute inset-0 flex items-center justify-center">
                          <div style={{ color: "#5A5A5A", fontSize: "12px", textAlign: "center" }}>
                            <div className="text-2xl mb-2">🗺️</div>
                            <div>Live map · Rider is 0.8 km away</div>
                          </div>
                        </div>
                        {/* Simulated map dots */}
                        <svg className="absolute inset-0 w-full h-full opacity-20">
                          <circle cx="30%" cy="40%" r="4" fill="#D4AF37" />
                          <circle cx="70%" cy="60%" r="6" fill="#D4AF37" />
                          <line x1="30%" y1="40%" x2="70%" y2="60%" stroke="#D4AF37" strokeWidth="1" strokeDasharray="4 4" />
                        </svg>
                        <div className="absolute bottom-3 right-3 text-xs font-mono px-2 py-1 rounded" style={{ background: "rgba(212,175,55,0.15)", color: "#D4AF37" }}>
                          Marco · 🛵 · {eta} min
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Order items */}
        <div className="mt-8 rounded-2xl p-6" style={{ background: "#1E1E1E", border: "1px solid #2E2E2E" }}>
          <h3 className="font-display text-lg font-semibold mb-4" style={{ color: "#F5F5F5" }}>Order Items</h3>
          <div className="space-y-3">
            {[
              { name: "Truffle Deluxe Burger", qty: 1, price: 13.90 },
              { name: "Texas Brisket", qty: 1, price: 15.00 },
              { name: "Loaded Fries", qty: 2, price: 3.00 },
            ].map((item) => (
              <div key={item.name} className="flex justify-between text-sm">
                <span style={{ color: "#D0D0D0" }}>{item.name} <span style={{ color: "#A0A0A0" }}>×{item.qty}</span></span>
                <span className="font-mono" style={{ color: "#D4AF37" }}>€{(item.price * item.qty).toFixed(2)}</span>
              </div>
            ))}
            <hr style={{ borderColor: "#2E2E2E" }} />
            <div className="flex justify-between font-bold">
              <span style={{ color: "#F5F5F5" }}>Total</span>
              <span className="font-mono" style={{ color: "#D4AF37" }}>€38.60</span>
            </div>
          </div>
        </div>

        <p className="text-center text-xs mt-6" style={{ color: "#5A5A5A" }}>
          This page auto-updates every few seconds · <span style={{ color: "#D4AF37", cursor: "pointer" }}>Contact support</span> if you have concerns
        </p>
      </div>
    </div>
  );
}
