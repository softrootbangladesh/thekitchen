import { useState, useEffect, useRef } from "react";

function useScrollReveal() {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!ref.current) return;
    const el = ref.current;
    const obs = new IntersectionObserver(
      (entries) => entries.forEach((e) => { if (e.isIntersecting) { e.target.classList.add("revealed"); obs.unobserve(e.target); } }),
      { threshold: 0.1, rootMargin: "0px 0px -40px 0px" }
    );
    const t = setTimeout(() => el.querySelectorAll(".reveal, .reveal-left, .reveal-right").forEach((item) => obs.observe(item)), 60);
    return () => { clearTimeout(t); obs.disconnect(); };
  }, []);
  return ref;
}

const TIME_SLOTS = ["12:00 PM", "12:30 PM", "1:00 PM", "6:00 PM", "6:30 PM", "7:00 PM", "7:30 PM", "8:00 PM", "8:30 PM", "9:00 PM", "9:30 PM", "10:00 PM"];
const OCCASIONS = ["None", "Birthday", "Anniversary", "Business Lunch", "Date Night", "Family Gathering", "Celebration", "Other"];

export default function Reservation() {
  const [form, setForm] = useState({
    name: "", email: "", phone: "",
    date: "", time: "", guests: "2",
    occasion: "None", notes: "",
    seating: "indoor",
  });
  const [submitted, setSubmitted] = useState(false);
  const revealRef = useScrollReveal();

  if (submitted) {
    return (
      <div className="min-h-screen pt-24 flex items-center justify-center px-6">
        <div className="text-center max-w-md animate-fade-in">
          <div
            className="w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6 pulse-gold"
            style={{ background: "rgba(212,175,55,0.12)", border: "2px solid rgba(212,175,55,0.5)" }}
          >
            <span className="text-4xl">🕯️</span>
          </div>
          <h2 className="font-display text-4xl font-bold mb-3" style={{ color: "#F5F5F5" }}>Reservation Confirmed</h2>
          <p className="text-base mb-2" style={{ color: "#7A7A7A" }}>
            We look forward to welcoming you, <strong style={{ color: "#F5F5F5" }}>{form.name || "you"}</strong>.
          </p>
          <div
            className="rounded-2xl p-6 mt-6 mb-8 text-left space-y-3"
            style={{ background: "#111111", border: "1px solid rgba(212,175,55,0.25)" }}
          >
            {[
              { label: "Date", value: form.date },
              { label: "Time", value: form.time },
              { label: "Guests", value: `${form.guests} people` },
              { label: "Seating", value: form.seating.charAt(0).toUpperCase() + form.seating.slice(1) },
              ...(form.occasion !== "None" ? [{ label: "Occasion", value: `${form.occasion} 🎉` }] : []),
            ].map((row) => (
              <div key={row.label} className="flex justify-between text-sm">
                <span style={{ color: "#5A5A5A" }}>{row.label}</span>
                <span style={{ color: "#F5F5F5" }}>{row.value}</span>
              </div>
            ))}
          </div>
          <p className="text-sm mb-6" style={{ color: "#5A5A5A" }}>
            Confirmation sent to <strong style={{ color: "#F5F5F5" }}>{form.email || "your email"}</strong>
          </p>
          <div className="flex gap-3 justify-center">
            <button onClick={() => setSubmitted(false)} className="btn-outline-gold px-6 py-3 rounded-full text-sm font-semibold">
              New Reservation
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen" style={{ background: "#0A0A0A" }} ref={revealRef}>
      {/* Header */}
      <div className="pt-28 pb-14 px-6 text-center" style={{ background: "linear-gradient(to bottom, #0D0D0D, #0A0A0A)" }}>
        <p className="text-xs tracking-widest uppercase mb-3 font-mono animate-fade-in" style={{ color: "#D4AF37" }}>— Book a Table —</p>
        <h1 className="font-display font-bold mb-4 animate-fade-in" style={{ color: "#F5F5F5", fontSize: "clamp(2.5rem, 7vw, 4.5rem)", animationDelay: "0.1s" }}>
          Reserve Your Evening
        </h1>
        <p className="text-base max-w-md mx-auto animate-fade-in" style={{ color: "#6A6A6A", animationDelay: "0.15s" }}>
          We'd be honored to host you. Reservations recommended — especially for weekends and special occasions.
        </p>
      </div>

      <div className="max-w-6xl mx-auto px-6 pb-24">
        <div className="grid lg:grid-cols-5 gap-10">
          {/* Form */}
          <form
            onSubmit={(e) => { e.preventDefault(); setSubmitted(true); }}
            className="lg:col-span-3 space-y-5 reveal-left"
          >
            {/* Personal details */}
            <div className="rounded-2xl p-6 space-y-4" style={{ background: "#111111", border: "1px solid rgba(255,255,255,0.05)" }}>
              <h3 className="font-display text-lg font-semibold" style={{ color: "#F5F5F5" }}>Your Details</h3>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium mb-2" style={{ color: "#6A6A6A" }}>Full Name *</label>
                  <input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Ahmed Al-Farsi" />
                </div>
                <div>
                  <label className="block text-xs font-medium mb-2" style={{ color: "#6A6A6A" }}>Email *</label>
                  <input required type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} placeholder="ahmed@example.com" />
                </div>
              </div>
              <div>
                <label className="block text-xs font-medium mb-2" style={{ color: "#6A6A6A" }}>Phone</label>
                <input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} placeholder="+356 XXXX XXXX" />
              </div>
            </div>

            {/* Reservation details */}
            <div className="rounded-2xl p-6 space-y-5" style={{ background: "#111111", border: "1px solid rgba(255,255,255,0.05)" }}>
              <h3 className="font-display text-lg font-semibold" style={{ color: "#F5F5F5" }}>Reservation Details</h3>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium mb-2" style={{ color: "#6A6A6A" }}>Date *</label>
                  <input required type="date" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} min={new Date().toISOString().split("T")[0]} />
                </div>
                <div>
                  <label className="block text-xs font-medium mb-2" style={{ color: "#6A6A6A" }}>Guests *</label>
                  <select required value={form.guests} onChange={(e) => setForm({ ...form, guests: e.target.value })}>
                    {[1,2,3,4,5,6,7,8].map((n) => (
                      <option key={n} value={n}>{n} {n === 1 ? "person" : "people"}</option>
                    ))}
                    <option value="9+">9+ (large party)</option>
                  </select>
                </div>
              </div>

              {/* Time slots */}
              <div>
                <label className="block text-xs font-medium mb-3" style={{ color: "#6A6A6A" }}>Preferred Time *</label>
                <div className="grid grid-cols-4 gap-2">
                  {TIME_SLOTS.map((time) => (
                    <button
                      type="button"
                      key={time}
                      onClick={() => setForm({ ...form, time })}
                      className="py-2.5 rounded-xl text-xs font-medium transition-all"
                      style={{
                        background: form.time === time ? "linear-gradient(135deg, #D4AF37, #E8C96B)" : "#1A1A1A",
                        color: form.time === time ? "#0D0D0D" : "#6A6A6A",
                        border: form.time === time ? "1px solid #D4AF37" : "1px solid rgba(255,255,255,0.05)",
                        fontWeight: form.time === time ? "600" : "400",
                        boxShadow: form.time === time ? "0 4px 14px rgba(212,175,55,0.3)" : "none",
                        transform: form.time === time ? "scale(1.03)" : "scale(1)",
                      }}
                    >
                      {time}
                    </button>
                  ))}
                </div>
              </div>

              {/* Seating */}
              <div>
                <label className="block text-xs font-medium mb-3" style={{ color: "#6A6A6A" }}>Seating Preference</label>
                <div className="flex gap-3">
                  {[
                    { key: "indoor", label: "🏠 Indoor", desc: "Air-conditioned" },
                    { key: "outdoor", label: "🌿 Terrace", desc: "Open air" },
                    { key: "private", label: "🔒 Private", desc: "8–20 guests" },
                  ].map((s) => (
                    <button
                      type="button"
                      key={s.key}
                      onClick={() => setForm({ ...form, seating: s.key })}
                      className="flex-1 py-3 px-2 rounded-xl text-xs font-medium transition-all text-center"
                      style={{
                        background: form.seating === s.key ? "rgba(212,175,55,0.1)" : "#1A1A1A",
                        color: form.seating === s.key ? "#D4AF37" : "#6A6A6A",
                        border: form.seating === s.key ? "1px solid rgba(212,175,55,0.4)" : "1px solid rgba(255,255,255,0.05)",
                      }}
                    >
                      <div>{s.label}</div>
                      <div className="text-xs mt-0.5 font-mono" style={{ opacity: 0.6 }}>{s.desc}</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Occasion */}
              <div>
                <label className="block text-xs font-medium mb-2" style={{ color: "#6A6A6A" }}>Occasion</label>
                <select value={form.occasion} onChange={(e) => setForm({ ...form, occasion: e.target.value })}>
                  {OCCASIONS.map((o) => <option key={o}>{o}</option>)}
                </select>
              </div>

              {/* Notes */}
              <div>
                <label className="block text-xs font-medium mb-2" style={{ color: "#6A6A6A" }}>Special Requests</label>
                <textarea
                  rows={3}
                  value={form.notes}
                  onChange={(e) => setForm({ ...form, notes: e.target.value })}
                  placeholder="Dietary requirements, allergies, accessibility needs, birthday setup…"
                  style={{ resize: "none" }}
                />
              </div>
            </div>

            <button type="submit" className="btn-gold w-full py-4 rounded-2xl text-sm font-bold uppercase tracking-wider">
              Confirm Reservation →
            </button>
          </form>

          {/* Info sidebar */}
          <div className="lg:col-span-2 space-y-5 reveal-right">
            {/* Image */}
            <div className="rounded-2xl overflow-hidden img-zoom-wrap" style={{ border: "1px solid rgba(255,255,255,0.05)" }}>
              <img
                src="https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=600&h=300&fit=crop&auto=format&q=80"
                alt="The Kitchen Malta dining room"
                loading="lazy"
                decoding="async"
                className="w-full object-cover"
                style={{ height: "200px" }}
                width={600}
                height={200}
              />
            </div>

            {/* Hours */}
            <div className="rounded-2xl p-6" style={{ background: "#111111", border: "1px solid rgba(255,255,255,0.05)" }}>
              <h3 className="font-display text-lg font-semibold mb-5" style={{ color: "#F5F5F5" }}>Opening Hours</h3>
              {[
                { day: "Mon – Thu", hours: "12:00 PM – 10:30 PM" },
                { day: "Fri – Sat", hours: "12:00 PM – 11:30 PM" },
                { day: "Sunday", hours: "12:00 PM – 10:00 PM" },
              ].map((row) => (
                <div key={row.day} className="flex justify-between text-sm mb-3">
                  <span style={{ color: "#5A5A5A" }}>{row.day}</span>
                  <span style={{ color: "#D0D0D0" }}>{row.hours}</span>
                </div>
              ))}
              <div className="pt-3 mt-3 text-xs font-mono" style={{ color: "#3A3A3A", borderTop: "1px solid #1E1E1E" }}>
                📞 +356 99119100
              </div>
            </div>

            {/* Good to know */}
            <div className="rounded-2xl p-6" style={{ background: "#111111", border: "1px solid rgba(255,255,255,0.05)" }}>
              <h3 className="font-display text-lg font-semibold mb-5" style={{ color: "#F5F5F5" }}>Good to Know</h3>
              <ul className="space-y-3">
                {[
                  "Cancellations accepted up to 24 hours in advance",
                  "Walk-ins welcomed based on availability",
                  "Private dining for 8–20 guests",
                  "100% Halal menu — no alcohol served",
                  "We accommodate dietary requirements",
                ].map((note) => (
                  <li key={note} className="flex items-start gap-3 text-sm" style={{ color: "#5A5A5A" }}>
                    <span style={{ color: "#D4AF37", flexShrink: 0 }}>·</span>
                    {note}
                  </li>
                ))}
              </ul>
            </div>

            {/* Halal badge */}
            <div className="rounded-2xl p-5 flex items-center gap-4" style={{ background: "rgba(94,196,94,0.05)", border: "1px solid rgba(94,196,94,0.2)" }}>
              <div className="w-10 h-10 rounded-full flex items-center justify-center text-lg shrink-0" style={{ background: "rgba(94,196,94,0.1)", border: "1px solid rgba(94,196,94,0.25)" }}>✓</div>
              <div>
                <div className="text-sm font-semibold" style={{ color: "#5EC45E" }}>100% Halal Certified</div>
                <div className="text-xs font-mono mt-0.5" style={{ color: "#3A5A3A" }}>All dishes, all ingredients — always.</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
