import { useState, memo } from "react";
import { menuItems, type MenuItem } from "../data/menuData";

interface CartItem extends MenuItem {
  quantity: number;
}

interface OrderProps {
  cartItems: CartItem[];
  onUpdateQty: (id: string, qty: number) => void;
  onRemove: (id: string) => void;
  onNavigate: (page: string) => void;
  onAddToCart: (item: MenuItem) => void;
}

const recommended = menuItems.filter((i) => i.popular && !i.soldOut).slice(0, 3);

const RecommendCard = memo(function RecommendCard({ item, inCart, onAdd }: { item: MenuItem; inCart: boolean; onAdd: () => void }) {
  return (
    <div className="rounded-xl overflow-hidden" style={{ background: "#1E1E1E", border: "1px solid #2E2E2E" }}>
      <img src={item.image} alt={item.name} loading="lazy" decoding="async" className="w-full h-24 object-cover" width={200} height={96} />
      <div className="p-3">
        <h4 className="text-xs font-semibold line-clamp-1" style={{ color: "#F5F5F5" }}>{item.name}</h4>
        <div className="flex items-center justify-between mt-2">
          <span className="font-mono text-xs font-bold" style={{ color: "#D4AF37" }}>€{item.price.toFixed(2)}</span>
          {!inCart && <button onClick={onAdd} className="text-xs font-semibold" style={{ color: "#D4AF37" }}>+ Add</button>}
          {inCart && <span className="text-xs" style={{ color: "#4CAF50" }}>✓ Added</span>}
        </div>
      </div>
    </div>
  );
});

export default function Order({ cartItems, onUpdateQty, onRemove, onNavigate, onAddToCart }: OrderProps) {
  const [mode, setMode] = useState<"delivery" | "pickup">("delivery");

  const subtotal = cartItems.reduce((sum, i) => sum + i.price * i.quantity, 0);
  const deliveryFee = mode === "delivery" ? 2.00 : 0;
  const total = subtotal + deliveryFee;

  const inCart = (id: string) => cartItems.some((i) => i.id === id);

  return (
    <div className="min-h-screen pt-24 pb-24 px-6">
      <div className="max-w-6xl mx-auto">
        <div className="mb-10">
          <p className="text-xs tracking-widest uppercase mb-2 font-mono" style={{ color: "#D4AF37" }}>— Your Order —</p>
          <h1 className="font-display text-4xl font-bold" style={{ color: "#F5F5F5" }}>Order Online</h1>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-6">
            {/* Delivery / Pickup toggle */}
            <div className="flex gap-2 p-1 rounded-xl w-fit" style={{ background: "#1E1E1E" }}>
              {(["delivery", "pickup"] as const).map((m) => (
                <button
                  key={m}
                  onClick={() => setMode(m)}
                  className="px-6 py-2 rounded-lg text-sm font-semibold transition-all duration-200"
                  style={{ background: mode === m ? "#D4AF37" : "transparent", color: mode === m ? "#0D0D0D" : "#A0A0A0" }}
                >
                  {m === "delivery" ? "🛵 Delivery" : "🏃 Pickup"}
                </button>
              ))}
            </div>

            {cartItems.length === 0 ? (
              <div className="rounded-2xl p-16 text-center" style={{ background: "#1E1E1E", border: "1px solid #2E2E2E" }}>
                <div className="text-5xl mb-4">🛒</div>
                <h3 className="font-display text-xl font-semibold mb-2" style={{ color: "#F5F5F5" }}>Your Cart is Empty</h3>
                <p className="text-sm mb-6" style={{ color: "#A0A0A0" }}>Add dishes from the menu to get started</p>
                <button onClick={() => onNavigate("menu")} className="btn-gold px-6 py-3 rounded-full text-sm font-semibold">Browse Menu →</button>
              </div>
            ) : (
              <div className="rounded-2xl overflow-hidden" style={{ background: "#1E1E1E", border: "1px solid #2E2E2E" }}>
                {cartItems.map((item, idx) => (
                  <div key={item.id} className="flex items-center gap-4 p-4" style={{ borderBottom: idx < cartItems.length - 1 ? "1px solid #2A2A2A" : "none" }}>
                    <div className="w-16 h-16 rounded-lg overflow-hidden shrink-0">
                      <img src={item.image} alt={item.name} loading="lazy" className="w-full h-full object-cover" width={64} height={64} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h4 className="font-semibold text-sm" style={{ color: "#F5F5F5" }}>{item.name}</h4>
                      {item.nameAr && <p className="text-xs font-mono" style={{ color: "#5A5A5A", direction: "rtl" }}>{item.nameAr}</p>}
                      <span className="font-mono text-sm mt-1 inline-block" style={{ color: "#D4AF37" }}>€{item.price.toFixed(2)}</span>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      <button onClick={() => onUpdateQty(item.id, Math.max(0, item.quantity - 1))} className="w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold" style={{ background: "#2A2A2A", color: "#F5F5F5" }}>−</button>
                      <span className="w-6 text-center font-mono font-semibold" style={{ color: "#F5F5F5" }}>{item.quantity}</span>
                      <button onClick={() => onUpdateQty(item.id, item.quantity + 1)} className="w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold" style={{ background: "#D4AF37", color: "#0D0D0D" }}>+</button>
                    </div>
                    <div className="text-right shrink-0">
                      <div className="font-mono font-bold" style={{ color: "#F5F5F5" }}>€{(item.price * item.quantity).toFixed(2)}</div>
                      <button onClick={() => onRemove(item.id)} className="text-xs mt-1" style={{ color: "#B33A3A" }}>Remove</button>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {cartItems.length > 0 && (
              <div>
                <h3 className="font-display text-lg font-semibold mb-4" style={{ color: "#F5F5F5" }}>You Might Also Like</h3>
                <div className="grid grid-cols-3 gap-3">
                  {recommended.filter((r) => !inCart(r.id)).slice(0, 3).map((item) => (
                    <RecommendCard key={item.id} item={item} inCart={inCart(item.id)} onAdd={() => onAddToCart(item)} />
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Summary */}
          <div>
            <div className="rounded-2xl p-6 sticky top-24" style={{ background: "#1E1E1E", border: "1px solid #2E2E2E" }}>
              <h3 className="font-display text-xl font-bold mb-6" style={{ color: "#F5F5F5" }}>Order Summary</h3>
              <div className="space-y-3 mb-6">
                <div className="flex justify-between text-sm">
                  <span style={{ color: "#A0A0A0" }}>Subtotal ({cartItems.reduce((s, i) => s + i.quantity, 0)} items)</span>
                  <span style={{ color: "#F5F5F5" }}>€{subtotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span style={{ color: "#A0A0A0" }}>{mode === "delivery" ? "Delivery fee" : "Pickup (free)"}</span>
                  <span style={{ color: mode === "pickup" ? "#4CAF50" : "#F5F5F5" }}>{mode === "pickup" ? "FREE" : `€${deliveryFee.toFixed(2)}`}</span>
                </div>
                <hr style={{ borderColor: "#2E2E2E" }} />
                <div className="flex justify-between font-bold">
                  <span style={{ color: "#F5F5F5" }}>Total</span>
                  <span className="font-mono text-lg" style={{ color: "#D4AF37" }}>€{total.toFixed(2)}</span>
                </div>
              </div>

              {mode === "delivery" && (
                <div className="rounded-lg p-3 mb-4 flex items-center gap-3" style={{ background: "rgba(212,175,55,0.08)", border: "1px solid rgba(212,175,55,0.2)" }}>
                  <span className="text-xl">🕐</span>
                  <div>
                    <div className="text-xs font-semibold" style={{ color: "#D4AF37" }}>Estimated Delivery</div>
                    <div className="text-sm" style={{ color: "#F5F5F5" }}>30–45 minutes</div>
                  </div>
                </div>
              )}

              <div className="flex gap-2 mb-4">
                <input type="text" placeholder="Promo code" style={{ paddingTop: "8px", paddingBottom: "8px" }} />
                <button className="btn-outline-gold px-4 py-2 rounded-lg text-sm font-semibold whitespace-nowrap shrink-0">Apply</button>
              </div>

              <button
                onClick={() => cartItems.length > 0 && onNavigate("checkout")}
                disabled={cartItems.length === 0}
                className="btn-gold w-full py-4 rounded-xl text-sm font-semibold uppercase tracking-wider disabled:opacity-40 disabled:cursor-not-allowed"
              >
                Checkout →
              </button>
              <p className="text-center text-xs mt-3" style={{ color: "#A0A0A0" }}>SSL Secured · Card · Cash on Delivery</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
