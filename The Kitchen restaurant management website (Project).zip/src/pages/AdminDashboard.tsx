import { useState } from "react";
import { menuItems } from "../data/menuData";

type AdminTab = "overview" | "orders" | "menu" | "inventory" | "staff" | "analytics" | "reservations" | "reviews";

const liveOrders = [
  { id: "TK-2847", customer: "Ahmed Al-Farsi", items: "Truffle Deluxe, Smokehouse BBQ, Fresh Fries x2", total: 31.70, status: "preparing", time: "12:45 PM" },
  { id: "TK-2848", customer: "Maria Grech", items: "Texas Brisket, Patata Harrah", total: 18.00, status: "confirmed", time: "12:52 PM" },
  { id: "TK-2849", customer: "Khalid Mansour", items: "Smoked Lamb Shank, Beef Wrap", total: 22.80, status: "delivery", time: "1:05 PM" },
  { id: "TK-2850", customer: "Claudia Borg", items: "Margherita, Falafel Wrap, Side Salad", total: 18.40, status: "delivered", time: "12:30 PM" },
];

const staff = [
  { name: "Elara Voss", role: "Executive Chef", status: "on-duty", shift: "4 PM – 11 PM" },
  { name: "Marco Fontaine", role: "Head Pastry", status: "on-duty", shift: "3 PM – 11 PM" },
  { name: "Yuki Tanaka", role: "Sommelier", status: "on-duty", shift: "5 PM – 12 AM" },
  { name: "Bruno Ashford", role: "Sous Chef", status: "off-duty", shift: "Off today" },
  { name: "Clara Reyes", role: "Front of House", status: "on-duty", shift: "4 PM – 11 PM" },
  { name: "Ahmed Hassan", role: "Bartender", status: "on-duty", shift: "5 PM – 1 AM" },
];

const inventory = [
  { item: "Premium Beef Patties", stock: 42, min: 60, unit: "pcs", status: "low" },
  { item: "Chicken Breast", stock: 8.5, min: 6, unit: "kg", status: "ok" },
  { item: "Lamb Shank", stock: 6, min: 8, unit: "pcs", status: "low" },
  { item: "Pizza Dough Bases", stock: 24, min: 20, unit: "pcs", status: "ok" },
  { item: "Mozzarella Cheese", stock: 3.2, min: 5, unit: "kg", status: "low" },
  { item: "Truffle Oil", stock: 0.4, min: 1, unit: "L", status: "critical" },
  { item: "BBQ Sauce (house)", stock: 8, min: 6, unit: "L", status: "ok" },
  { item: "Fresh Fries (frozen)", stock: 12, min: 15, unit: "kg", status: "low" },
];

const reservationsToday = [
  { time: "6:00 PM", name: "Fontaine, 2 guests", occasion: "Anniversary", table: "T-4", seating: "Indoor" },
  { time: "6:30 PM", name: "Chen, 4 guests", occasion: "-", table: "T-7", seating: "Terrace" },
  { time: "7:00 PM", name: "Whitmore, 6 guests", occasion: "Birthday", table: "Private", seating: "Private" },
  { time: "7:30 PM", name: "Sharma, 2 guests", occasion: "Date Night", table: "T-2", seating: "Indoor" },
  { time: "8:00 PM", name: "Andreou, 3 guests", occasion: "-", table: "T-9", seating: "Indoor" },
  { time: "8:30 PM", name: "Mehta, 8 guests", occasion: "Business", table: "T-12", seating: "Indoor" },
  { time: "9:00 PM", name: "Voss, 2 guests", occasion: "-", table: "T-5", seating: "Terrace" },
];

const weeklyData = [
  { day: "Mon", revenue: 480, orders: 28 },
  { day: "Tue", revenue: 420, orders: 24 },
  { day: "Wed", revenue: 585, orders: 34 },
  { day: "Thu", revenue: 630, orders: 38 },
  { day: "Fri", revenue: 1020, orders: 62 },
  { day: "Sat", revenue: 1230, orders: 74 },
  { day: "Sun", revenue: 810, orders: 49 },
];

const maxRevenue = Math.max(...weeklyData.map((d) => d.revenue));

export default function AdminDashboard() {
  const [activeTab, setActiveTab] = useState<AdminTab>("overview");
  const [menuList, setMenuList] = useState(menuItems);
  const [orderStatuses, setOrderStatuses] = useState(
    Object.fromEntries(liveOrders.map((o) => [o.id, o.status]))
  );

  const tabs: { key: AdminTab; label: string; icon: string }[] = [
    { key: "overview", label: "Overview", icon: "📊" },
    { key: "orders", label: "Orders", icon: "🛒" },
    { key: "menu", label: "Menu Mgmt", icon: "🍽" },
    { key: "inventory", label: "Inventory", icon: "📦" },
    { key: "staff", label: "Staff", icon: "👥" },
    { key: "analytics", label: "Analytics", icon: "📈" },
    { key: "reservations", label: "Reservations", icon: "📅" },
    { key: "reviews", label: "Reviews", icon: "⭐" },
  ];

  const statusCycle: Record<string, string> = {
    confirmed: "preparing",
    preparing: "quality",
    quality: "delivery",
    delivery: "delivered",
    delivered: "delivered",
  };

  const statusLabel: Record<string, string> = {
    confirmed: "Confirmed",
    preparing: "Preparing",
    quality: "Quality Check",
    delivery: "Out for Delivery",
    delivered: "Delivered",
  };

  const statusClass: Record<string, string> = {
    confirmed: "status-delivery",
    preparing: "status-preparing",
    quality: "status-preparing",
    delivery: "status-delivery",
    delivered: "status-delivered",
  };

  return (
    <div className="min-h-screen pt-24 pb-24 px-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <p className="text-xs tracking-widest uppercase mb-1 font-mono" style={{ color: "#D4AF37" }}>Admin Panel</p>
            <h1 className="font-display text-3xl font-bold" style={{ color: "#F5F5F5" }}>The Kitchen — Management</h1>
          </div>
          <div className="flex items-center gap-3">
            <span className="text-xs font-mono" style={{ color: "#A0A0A0" }}>Thursday, July 31, 2026</span>
            <div className="w-2 h-2 rounded-full pulse-gold" style={{ background: "#4CAF50" }} />
            <span className="text-xs" style={{ color: "#4CAF50" }}>Live</span>
          </div>
        </div>

        <div className="grid lg:grid-cols-5 gap-8">
          {/* Sidebar */}
          <div className="lg:col-span-1">
            <nav className="rounded-2xl p-3 space-y-1 sticky top-24" style={{ background: "#1E1E1E", border: "1px solid #2E2E2E" }}>
              {tabs.map((tab) => (
                <button
                  key={tab.key}
                  onClick={() => setActiveTab(tab.key)}
                  className={`sidebar-link w-full ${activeTab === tab.key ? "active" : ""}`}
                >
                  <span>{tab.icon}</span>
                  <span className="text-xs">{tab.label}</span>
                </button>
              ))}
            </nav>
          </div>

          {/* Main content */}
          <div className="lg:col-span-4">

            {/* OVERVIEW */}
            {activeTab === "overview" && (
              <div className="space-y-6">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {[
                    { value: "€727", label: "Today's Revenue", change: "+12%", icon: "💰" },
                    { value: "42", label: "Orders Today", change: "+8%", icon: "📋" },
                    { value: "7", label: "Active Tables", change: "", icon: "🪑" },
                    { value: "4.9★", label: "Avg Rating", change: "+0.1", icon: "⭐" },
                  ].map((s) => (
                    <div key={s.label} className="rounded-2xl p-5" style={{ background: "#1E1E1E", border: "1px solid #2E2E2E" }}>
                      <div className="text-xl mb-2">{s.icon}</div>
                      <div className="font-mono font-bold text-2xl" style={{ color: "#D4AF37" }}>{s.value}</div>
                      <div className="text-xs mt-0.5" style={{ color: "#A0A0A0" }}>{s.label}</div>
                      {s.change && <div className="text-xs mt-1" style={{ color: "#4CAF50" }}>{s.change} vs yesterday</div>}
                    </div>
                  ))}
                </div>

                {/* Live orders preview */}
                <div className="rounded-2xl p-6" style={{ background: "#1E1E1E", border: "1px solid #2E2E2E" }}>
                  <div className="flex items-center justify-between mb-5">
                    <h3 className="font-display text-lg font-semibold" style={{ color: "#F5F5F5" }}>Live Orders</h3>
                    <button onClick={() => setActiveTab("orders")} className="text-xs" style={{ color: "#D4AF37" }}>View all →</button>
                  </div>
                  <div className="space-y-3">
                    {liveOrders.slice(0, 3).map((order) => (
                      <div key={order.id} className="flex items-center gap-4 p-3 rounded-xl" style={{ background: "#2A2A2A" }}>
                        <span className="font-mono text-xs font-bold" style={{ color: "#D4AF37" }}>#{order.id}</span>
                        <span className="text-sm flex-1" style={{ color: "#D0D0D0" }}>{order.customer}</span>
                        <span className={`text-xs px-2 py-0.5 rounded-full ${statusClass[orderStatuses[order.id] || order.status]}`}>
                          {statusLabel[orderStatuses[order.id] || order.status]}
                        </span>
                        <span className="font-mono text-sm" style={{ color: "#F5F5F5" }}>€{order.total.toFixed(2)}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Inventory alerts */}
                <div className="rounded-2xl p-6" style={{ background: "#1E1E1E", border: "1px solid #2E2E2E" }}>
                  <h3 className="font-display text-lg font-semibold mb-4" style={{ color: "#F5F5F5" }}>⚠️ Stock Alerts</h3>
                  <div className="space-y-2">
                    {inventory.filter((i) => i.status !== "ok").map((inv) => (
                      <div key={inv.item} className="flex items-center justify-between p-3 rounded-xl" style={{ background: inv.status === "critical" ? "rgba(179,58,58,0.1)" : "rgba(255,165,0,0.08)", border: `1px solid ${inv.status === "critical" ? "rgba(179,58,58,0.3)" : "rgba(255,165,0,0.2)"}` }}>
                        <span className="text-sm" style={{ color: "#D0D0D0" }}>{inv.item}</span>
                        <div className="flex items-center gap-3">
                          <span className="font-mono text-sm" style={{ color: "#F5F5F5" }}>{inv.stock} {inv.unit}</span>
                          <span className={`text-xs px-2 py-0.5 rounded-full font-mono uppercase font-bold`} style={{ color: inv.status === "critical" ? "#B33A3A" : "#FFA500", background: inv.status === "critical" ? "rgba(179,58,58,0.15)" : "rgba(255,165,0,0.1)" }}>
                            {inv.status}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* ORDERS */}
            {activeTab === "orders" && (
              <div>
                <h2 className="font-display text-2xl font-bold mb-6" style={{ color: "#F5F5F5" }}>Order Management</h2>
                <div className="rounded-2xl overflow-hidden" style={{ background: "#1E1E1E", border: "1px solid #2E2E2E" }}>
                  <table>
                    <thead>
                      <tr style={{ background: "#1A1A1A" }}>
                        <th>Order ID</th>
                        <th>Customer</th>
                        <th>Items</th>
                        <th>Time</th>
                        <th>Total</th>
                        <th>Status</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      {liveOrders.map((order) => {
                        const status = orderStatuses[order.id] || order.status;
                        return (
                          <tr key={order.id}>
                            <td className="font-mono font-bold" style={{ color: "#D4AF37" }}>#{order.id}</td>
                            <td style={{ color: "#F5F5F5" }}>{order.customer}</td>
                            <td style={{ color: "#A0A0A0" }} className="text-xs">{order.items}</td>
                            <td className="font-mono text-xs" style={{ color: "#5A5A5A" }}>{order.time}</td>
                            <td className="font-mono" style={{ color: "#F5F5F5" }}>€{order.total.toFixed(2)}</td>
                            <td>
                              <span className={`text-xs px-2 py-1 rounded-full font-mono ${statusClass[status]}`}>
                                {statusLabel[status]}
                              </span>
                            </td>
                            <td>
                              {status !== "delivered" && (
                                <button
                                  onClick={() => setOrderStatuses((prev) => ({ ...prev, [order.id]: statusCycle[status] }))}
                                  className="btn-gold px-3 py-1 rounded-lg text-xs font-semibold"
                                >
                                  → {statusLabel[statusCycle[status]]}
                                </button>
                              )}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* MENU MANAGEMENT */}
            {activeTab === "menu" && (
              <div>
                <div className="flex items-center justify-between mb-6">
                  <h2 className="font-display text-2xl font-bold" style={{ color: "#F5F5F5" }}>Menu Management</h2>
                  <button className="btn-gold px-4 py-2 rounded-lg text-sm font-semibold">+ Add Dish</button>
                </div>
                <div className="rounded-2xl overflow-hidden" style={{ background: "#1E1E1E", border: "1px solid #2E2E2E" }}>
                  <table>
                    <thead>
                      <tr>
                        <th>Dish</th>
                        <th>Category</th>
                        <th>Price</th>
                        <th>Status</th>
                        <th>Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {menuList.map((item) => (
                        <tr key={item.id}>
                          <td>
                            <div className="flex items-center gap-3">
                              <img src={item.image} alt={item.name} className="w-10 h-10 rounded-lg object-cover" />
                              <span style={{ color: "#F5F5F5" }}>{item.name}</span>
                            </div>
                          </td>
                          <td className="capitalize text-xs" style={{ color: "#A0A0A0" }}>{item.category}</td>
                          <td className="font-mono" style={{ color: "#D4AF37" }}>${item.price}</td>
                          <td>
                            <span className={`text-xs px-2 py-0.5 rounded-full ${item.soldOut ? "tag-soldout" : "status-delivered"}`}>
                              {item.soldOut ? "Sold Out" : "Available"}
                            </span>
                          </td>
                          <td>
                            <div className="flex gap-2">
                              <button
                                onClick={() => setMenuList((prev) => prev.map((m) => m.id === item.id ? { ...m, soldOut: !m.soldOut } : m))}
                                className="text-xs px-2 py-1 rounded"
                                style={{ background: "#2A2A2A", color: "#A0A0A0" }}
                              >
                                Toggle
                              </button>
                              <button className="text-xs" style={{ color: "#D4AF37" }}>Edit</button>
                              <button className="text-xs" style={{ color: "#B33A3A" }}>Delete</button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* INVENTORY */}
            {activeTab === "inventory" && (
              <div>
                <div className="flex items-center justify-between mb-6">
                  <h2 className="font-display text-2xl font-bold" style={{ color: "#F5F5F5" }}>Inventory & Stock</h2>
                  <button className="btn-gold px-4 py-2 rounded-lg text-sm font-semibold">+ Add Item</button>
                </div>
                <div className="rounded-2xl overflow-hidden" style={{ background: "#1E1E1E", border: "1px solid #2E2E2E" }}>
                  <table>
                    <thead>
                      <tr>
                        <th>Item</th>
                        <th>Stock</th>
                        <th>Min Level</th>
                        <th>Status</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      {inventory.map((inv) => (
                        <tr key={inv.item}>
                          <td style={{ color: "#F5F5F5" }}>{inv.item}</td>
                          <td className="font-mono" style={{ color: "#F5F5F5" }}>{inv.stock} {inv.unit}</td>
                          <td className="font-mono text-xs" style={{ color: "#5A5A5A" }}>{inv.min} {inv.unit}</td>
                          <td>
                            <span
                              className="text-xs px-2 py-0.5 rounded-full font-mono uppercase font-bold"
                              style={{
                                color: inv.status === "critical" ? "#B33A3A" : inv.status === "low" ? "#FFA500" : "#4CAF50",
                                background: inv.status === "critical" ? "rgba(179,58,58,0.15)" : inv.status === "low" ? "rgba(255,165,0,0.1)" : "rgba(76,175,80,0.1)",
                                border: `1px solid ${inv.status === "critical" ? "rgba(179,58,58,0.3)" : inv.status === "low" ? "rgba(255,165,0,0.2)" : "rgba(76,175,80,0.2)"}`,
                              }}
                            >
                              {inv.status}
                            </span>
                          </td>
                          <td>
                            <button className="text-xs font-semibold" style={{ color: "#D4AF37" }}>+ Reorder</button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* STAFF */}
            {activeTab === "staff" && (
              <div>
                <div className="flex items-center justify-between mb-6">
                  <h2 className="font-display text-2xl font-bold" style={{ color: "#F5F5F5" }}>Staff Management</h2>
                  <button className="btn-gold px-4 py-2 rounded-lg text-sm font-semibold">+ Add Staff</button>
                </div>
                <div className="grid md:grid-cols-2 gap-4">
                  {staff.map((member) => (
                    <div key={member.name} className="rounded-xl p-5 flex items-start gap-4" style={{ background: "#1E1E1E", border: "1px solid #2E2E2E" }}>
                      <div
                        className="w-12 h-12 rounded-full flex items-center justify-center text-lg font-bold shrink-0"
                        style={{ background: member.status === "on-duty" ? "rgba(76,175,80,0.15)" : "#2A2A2A", color: member.status === "on-duty" ? "#4CAF50" : "#5A5A5A", border: `1px solid ${member.status === "on-duty" ? "rgba(76,175,80,0.3)" : "#3A3A3A"}` }}
                      >
                        {member.name[0]}
                      </div>
                      <div className="flex-1">
                        <div className="font-semibold" style={{ color: "#F5F5F5" }}>{member.name}</div>
                        <div className="text-xs mb-2" style={{ color: "#A0A0A0" }}>{member.role}</div>
                        <div className="flex items-center gap-2">
                          <div className="w-2 h-2 rounded-full" style={{ background: member.status === "on-duty" ? "#4CAF50" : "#5A5A5A" }} />
                          <span className="text-xs" style={{ color: member.status === "on-duty" ? "#4CAF50" : "#5A5A5A" }}>
                            {member.status === "on-duty" ? "On Duty" : "Off Duty"}
                          </span>
                          <span className="text-xs" style={{ color: "#5A5A5A" }}>· {member.shift}</span>
                        </div>
                      </div>
                      <button className="text-xs shrink-0" style={{ color: "#D4AF37" }}>Edit</button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* ANALYTICS */}
            {activeTab === "analytics" && (
              <div className="space-y-6">
                <h2 className="font-display text-2xl font-bold" style={{ color: "#F5F5F5" }}>Sales Analytics</h2>

                {/* Key metrics */}
                <div className="grid grid-cols-4 gap-4">
                  {[
                    { label: "Weekly Revenue", value: "€5,175", change: "+18%" },
                    { label: "Weekly Orders", value: "309", change: "+12%" },
                    { label: "Avg Order Value", value: "€16.75", change: "+5%" },
                    { label: "Returning Guests", value: "68%", change: "+3%" },
                  ].map((m) => (
                    <div key={m.label} className="rounded-2xl p-4" style={{ background: "#1E1E1E", border: "1px solid #2E2E2E" }}>
                      <div className="text-xs mb-1" style={{ color: "#A0A0A0" }}>{m.label}</div>
                      <div className="font-mono font-bold text-xl" style={{ color: "#D4AF37" }}>{m.value}</div>
                      <div className="text-xs mt-1" style={{ color: "#4CAF50" }}>{m.change}</div>
                    </div>
                  ))}
                </div>

                {/* Bar chart */}
                <div className="rounded-2xl p-6" style={{ background: "#1E1E1E", border: "1px solid #2E2E2E" }}>
                  <h3 className="font-display text-lg font-semibold mb-6" style={{ color: "#F5F5F5" }}>Weekly Revenue</h3>
                  <div className="flex items-end gap-3 h-40">
                    {weeklyData.map((d) => (
                      <div key={d.day} className="flex-1 flex flex-col items-center gap-2">
                        <div className="text-xs font-mono" style={{ color: "#A0A0A0" }}>€{d.revenue}</div>
                        <div
                          className="w-full rounded-t-md transition-all duration-500"
                          style={{
                            height: `${(d.revenue / maxRevenue) * 100}px`,
                            background: d.day === "Sat" ? "linear-gradient(to top, #D4AF37, #E8C96B)" : "rgba(212,175,55,0.3)",
                            minHeight: "8px",
                          }}
                        />
                        <div className="text-xs" style={{ color: "#5A5A5A" }}>{d.day}</div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Top dishes */}
                <div className="rounded-2xl p-6" style={{ background: "#1E1E1E", border: "1px solid #2E2E2E" }}>
                  <h3 className="font-display text-lg font-semibold mb-4" style={{ color: "#F5F5F5" }}>Top Dishes by Revenue</h3>
                  <div className="space-y-4">
                    {[
                      { name: "Texas Brisket", revenue: 4890, orders: 326 },
                      { name: "Truffle Deluxe", revenue: 4202, orders: 302 },
                      { name: "Smoked Lamb Shank", revenue: 3888, orders: 280 },
                      { name: "Smokehouse BBQ", revenue: 3024, orders: 234 },
                      { name: "Mediterranean Chicken", revenue: 2735, orders: 230 },
                    ].map((dish, i) => (
                      <div key={dish.name}>
                        <div className="flex justify-between text-sm mb-1">
                          <span style={{ color: "#D0D0D0" }}>{i + 1}. {dish.name}</span>
                          <span className="font-mono" style={{ color: "#D4AF37" }}>€{dish.revenue.toLocaleString()}</span>
                        </div>
                        <div className="progress-bar" style={{ height: "4px" }}>
                          <div className="progress-fill" style={{ width: `${(dish.revenue / 4890) * 100}%` }} />
                        </div>
                        <div className="text-xs mt-0.5" style={{ color: "#5A5A5A" }}>{dish.orders} orders</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* RESERVATIONS */}
            {activeTab === "reservations" && (
              <div>
                <div className="flex items-center justify-between mb-6">
                  <h2 className="font-display text-2xl font-bold" style={{ color: "#F5F5F5" }}>
                    Reservations · <span style={{ color: "#D4AF37" }}>July 31</span>
                  </h2>
                  <span className="font-mono text-sm" style={{ color: "#A0A0A0" }}>{reservationsToday.length} bookings today</span>
                </div>
                <div className="rounded-2xl overflow-hidden" style={{ background: "#1E1E1E", border: "1px solid #2E2E2E" }}>
                  <table>
                    <thead>
                      <tr>
                        <th>Time</th>
                        <th>Guest</th>
                        <th>Occasion</th>
                        <th>Table</th>
                        <th>Seating</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      {reservationsToday.map((res, i) => (
                        <tr key={i}>
                          <td className="font-mono font-bold" style={{ color: "#D4AF37" }}>{res.time}</td>
                          <td style={{ color: "#F5F5F5" }}>{res.name}</td>
                          <td style={{ color: res.occasion !== "-" ? "#D4AF37" : "#5A5A5A" }}>{res.occasion}</td>
                          <td className="font-mono text-xs" style={{ color: "#F5F5F5" }}>{res.table}</td>
                          <td className="text-xs" style={{ color: "#A0A0A0" }}>{res.seating}</td>
                          <td>
                            <div className="flex gap-2">
                              <button className="text-xs" style={{ color: "#4CAF50" }}>✓ Confirm</button>
                              <button className="text-xs" style={{ color: "#B33A3A" }}>× Cancel</button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* REVIEWS MODERATION */}
            {activeTab === "reviews" && (
              <div>
                <h2 className="font-display text-2xl font-bold mb-6" style={{ color: "#F5F5F5" }}>Review Moderation</h2>
                <div className="space-y-4">
                  {[
                    { name: "Isabelle Fontaine", rating: 5, text: "An absolutely transcendent dining experience...", status: "published", date: "Jul 18" },
                    { name: "Marcus Chen", rating: 5, text: "The Prime Ribeye was perfectly cooked — a true 10/10...", status: "published", date: "Jul 14" },
                    { name: "Anonymous", rating: 2, text: "Service was slow and the food was cold. Disappointed.", status: "pending", date: "Jul 30" },
                    { name: "Priya Sharma", rating: 5, text: "As someone who primarily eats plant-based...", status: "published", date: "Jul 10" },
                  ].map((review, i) => (
                    <div key={i} className="rounded-xl p-5" style={{ background: "#1E1E1E", border: "1px solid #2E2E2E" }}>
                      <div className="flex items-start justify-between gap-4">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-1">
                            <span className="font-semibold text-sm" style={{ color: "#F5F5F5" }}>{review.name}</span>
                            <div className="flex">
                              {[1,2,3,4,5].map((s) => (
                                <svg key={s} className={`w-3 h-3 ${s <= review.rating ? "star-filled" : "star-empty"}`} fill="currentColor" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" /></svg>
                              ))}
                            </div>
                            <span className="text-xs font-mono" style={{ color: "#5A5A5A" }}>{review.date}</span>
                          </div>
                          <p className="text-sm" style={{ color: "#A0A0A0" }}>{review.text}</p>
                        </div>
                        <div className="flex flex-col items-end gap-2 shrink-0">
                          <span className={`text-xs px-2 py-0.5 rounded-full font-mono ${review.status === "published" ? "status-delivered" : "status-preparing"}`}>
                            {review.status}
                          </span>
                          {review.status === "pending" && (
                            <div className="flex gap-2">
                              <button className="text-xs font-semibold" style={{ color: "#4CAF50" }}>Approve</button>
                              <button className="text-xs font-semibold" style={{ color: "#B33A3A" }}>Remove</button>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

          </div>
        </div>
      </div>
    </div>
  );
}
