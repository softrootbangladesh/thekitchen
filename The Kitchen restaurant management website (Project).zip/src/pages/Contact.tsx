import { useState } from "react";

export default function Contact() {
  const [form, setForm] = useState({ name: "", email: "", subject: "", message: "" });
  const [sent, setSent] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSent(true);
  };

  return (
    <div className="min-h-screen pt-24 pb-24 px-6">
      <div className="max-w-5xl mx-auto">
        <div className="text-center mb-14">
          <p className="text-xs tracking-widest uppercase mb-3 font-mono" style={{ color: "#D4AF37" }}>— Reach Out —</p>
          <h1 className="font-display text-5xl font-bold" style={{ color: "#F5F5F5" }}>Contact Us</h1>
          <p className="mt-4 text-base max-w-md mx-auto" style={{ color: "#A0A0A0" }}>
            We'd love to hear from you — whether it's a reservation enquiry, feedback, or an event proposal.
          </p>
        </div>

        <div className="grid lg:grid-cols-5 gap-10">
          {/* Form */}
          <div className="lg:col-span-3">
            {sent ? (
              <div className="rounded-2xl p-10 text-center animate-fade-in" style={{ background: "#1E1E1E", border: "1px solid rgba(212,175,55,0.3)" }}>
                <div className="text-4xl mb-4">✉️</div>
                <h3 className="font-display text-2xl font-bold mb-2" style={{ color: "#F5F5F5" }}>Message Sent</h3>
                <p className="text-sm mb-6" style={{ color: "#A0A0A0" }}>
                  Thank you, {form.name}! We'll get back to you within 24 hours.
                </p>
                <button onClick={() => setSent(false)} className="btn-outline-gold px-5 py-2.5 rounded-full text-sm font-semibold">
                  Send Another
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="rounded-2xl p-6 space-y-4" style={{ background: "#1E1E1E", border: "1px solid #2E2E2E" }}>
                <h3 className="font-display text-xl font-semibold mb-5" style={{ color: "#F5F5F5" }}>Send a Message</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-medium mb-2" style={{ color: "#A0A0A0" }}>Name *</label>
                    <input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Your name" />
                  </div>
                  <div>
                    <label className="block text-xs font-medium mb-2" style={{ color: "#A0A0A0" }}>Email *</label>
                    <input required type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} placeholder="your@email.com" />
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-medium mb-2" style={{ color: "#A0A0A0" }}>Subject</label>
                  <select value={form.subject} onChange={(e) => setForm({ ...form, subject: e.target.value })}>
                    <option value="">Select a topic</option>
                    <option>Reservation Enquiry</option>
                    <option>Private Event</option>
                    <option>Feedback</option>
                    <option>Press & Media</option>
                    <option>Other</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-medium mb-2" style={{ color: "#A0A0A0" }}>Message *</label>
                  <textarea required rows={5} value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} placeholder="Tell us how we can help…" style={{ resize: "none" }} />
                </div>
                <button type="submit" className="btn-gold w-full py-3 rounded-xl text-sm font-semibold uppercase tracking-wide">
                  Send Message
                </button>
              </form>
            )}
          </div>

          {/* Info */}
          <div className="lg:col-span-2 space-y-5">
            {/* Map placeholder */}
            <div className="rounded-2xl overflow-hidden relative" style={{ height: "220px", background: "#1A1A1A", border: "1px solid #2E2E2E" }}>
              <img
                src="https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=600&h=300&fit=crop&auto=format"
                alt="The Kitchen location"
                className="w-full h-full object-cover opacity-30"
              />
              <div className="absolute inset-0 flex items-center justify-center flex-col gap-2">
                <div className="text-3xl">📍</div>
                <div className="text-sm font-semibold" style={{ color: "#F5F5F5" }}>The Kitchen Malta</div>
                <div className="text-xs" style={{ color: "#A0A0A0" }}>Malta, Mediterranean</div>
                <a
                  href="#"
                  className="mt-2 text-xs font-semibold"
                  style={{ color: "#D4AF37", textDecoration: "underline" }}
                >
                  Open in Google Maps →
                </a>
              </div>
            </div>

            <div className="rounded-2xl p-6 space-y-4" style={{ background: "#1E1E1E", border: "1px solid #2E2E2E" }}>
              <h3 className="font-display text-lg font-semibold" style={{ color: "#F5F5F5" }}>Contact Details</h3>
              {[
                { icon: "📞", label: "Phone", value: "+356 99119100" },
                { icon: "✉️", label: "Email", value: "info@thekitchenmalta.com" },
                { icon: "📍", label: "Address", value: "The Kitchen Malta, Mediterranean" },
              ].map((item) => (
                <div key={item.label} className="flex items-start gap-3">
                  <span className="text-lg mt-0.5">{item.icon}</span>
                  <div>
                    <div className="text-xs font-semibold uppercase tracking-wider mb-0.5" style={{ color: "#A0A0A0" }}>{item.label}</div>
                    <div className="text-sm" style={{ color: "#F5F5F5" }}>{item.value}</div>
                  </div>
                </div>
              ))}
            </div>

            <div className="rounded-2xl p-6" style={{ background: "#1E1E1E", border: "1px solid #2E2E2E" }}>
              <h3 className="font-display text-lg font-semibold mb-4" style={{ color: "#F5F5F5" }}>Opening Hours</h3>
              {[
                { day: "Monday – Thursday", hours: "5:30 PM – 10:30 PM" },
                { day: "Friday – Saturday", hours: "5:00 PM – 11:30 PM" },
                { day: "Sunday", hours: "5:00 PM – 9:30 PM" },
                { day: "Brunch (Sat – Sun)", hours: "11:00 AM – 2:30 PM" },
              ].map((row) => (
                <div key={row.day} className="flex justify-between text-sm mb-2">
                  <span style={{ color: "#A0A0A0" }}>{row.day}</span>
                  <span style={{ color: "#F5F5F5" }}>{row.hours}</span>
                </div>
              ))}
            </div>

            {/* Social */}
            <div className="rounded-2xl p-6" style={{ background: "#1E1E1E", border: "1px solid #2E2E2E" }}>
              <h3 className="font-display text-lg font-semibold mb-4" style={{ color: "#F5F5F5" }}>Follow Us</h3>
              <div className="flex gap-3">
                {[
                  { name: "Instagram", handle: "@thekitchenmalta" },
                  { name: "TikTok", handle: "@thekitchenmalta" },
                  { name: "Facebook", handle: "TheKitchenMalta" },
                ].map((s) => (
                  <div key={s.name} className="flex-1 rounded-xl p-3 text-center" style={{ background: "#2A2A2A", border: "1px solid #3A3A3A" }}>
                    <div className="text-xs font-semibold" style={{ color: "#F5F5F5" }}>{s.name}</div>
                    <div className="text-xs mt-1" style={{ color: "#D4AF37" }}>{s.handle}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
