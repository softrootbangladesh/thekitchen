import { useState } from "react";
import { type MenuItem } from "../data/menuData";

interface CartItem extends MenuItem {
  quantity: number;
}

interface CheckoutProps {
  cartItems: CartItem[];
  onNavigate: (page: string) => void;
  onPlaceOrder: () => void;
}

const MALTA_AREAS = [
  "Valletta", "Sliema", "St. Julian's", "Msida", "Gzira", "Birkirkara",
  "Qormi", "Mosta", "Naxxar", "San Gwann", "Hamrun", "Floriana", "Swieqi", "Pembroke",
];

export default function Checkout({ cartItems, onNavigate, onPlaceOrder }: CheckoutProps) {
  const [step, setStep] = useState(1);
  const [paymentMethod, setPaymentMethod] = useState("card");
  const [form, setForm] = useState({
    name: "", email: "", phone: "",
    address: "", area: "", city: "Malta",
    cardNumber: "", expiry: "", cvv: "", cardName: "",
  });
  const [placed, setPlaced] = useState(false);

  const subtotal = cartItems.reduce((s, i) => s + i.price * i.quantity, 0);
  const deliveryFee = 2.00;
  const total = subtotal + deliveryFee;

  const handlePlace = () => {
    setPlaced(true);
    onPlaceOrder();
  };

  if (placed) {
    return (
      <div className="min-h-screen pt-24 flex items-center justify-center px-6">
        <div className="text-center max-w-md">
          <div className="w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6 pulse-gold" style={{ background: "rgba(212,175,55,0.15)", border: "2px solid #D4AF37" }}>
            <svg className="w-10 h-10" fill="none" stroke="#D4AF37" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
            </svg>
          </div>
          <h2 className="font-display text-4xl font-bold mb-3" style={{ color: "#F5F5F5" }}>Order Placed!</h2>
          <p className="text-base mb-2" style={{ color: "#A0A0A0" }}>
            Thank you, {form.name || "dear guest"}! Your order{" "}
            <span className="font-mono" style={{ color: "#D4AF37" }}>#TK-2847</span>{" "}
            has been received.
          </p>
          <p className="text-sm mb-8" style={{ color: "#A0A0A0" }}>
            Estimated delivery: <strong style={{ color: "#F5F5F5" }}>30–45 minutes</strong>
          </p>
          <div className="flex gap-3 justify-center">
            <button onClick={() => onNavigate("tracking")} className="btn-gold px-6 py-3 rounded-full text-sm font-semibold">Track Order</button>
            <button onClick={() => onNavigate("home")} className="btn-outline-gold px-6 py-3 rounded-full text-sm font-semibold">Home</button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pt-24 pb-24 px-6">
      <div className="max-w-5xl mx-auto">
        <div className="mb-10">
          <p className="text-xs tracking-widest uppercase mb-2 font-mono" style={{ color: "#D4AF37" }}>— Almost There —</p>
          <h1 className="font-display text-4xl font-bold" style={{ color: "#F5F5F5" }}>Checkout</h1>
        </div>

        {/* Steps */}
        <div className="flex items-center gap-2 mb-10">
          {["Delivery Info", "Payment", "Confirm"].map((s, i) => (
            <div key={s} className="flex items-center gap-2">
              <div className="flex items-center gap-2 text-sm font-medium" style={{ color: step > i + 1 ? "#D4AF37" : step === i + 1 ? "#F5F5F5" : "#5A5A5A" }}>
                <span className="w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold" style={{ background: step > i + 1 ? "#D4AF37" : step === i + 1 ? "rgba(212,175,55,0.2)" : "#2A2A2A", color: step > i + 1 ? "#0D0D0D" : step === i + 1 ? "#D4AF37" : "#5A5A5A", border: step === i + 1 ? "1px solid #D4AF37" : "1px solid transparent" }}>
                  {step > i + 1 ? "✓" : i + 1}
                </span>
                <span className="hidden md:inline text-xs">{s}</span>
              </div>
              {i < 2 && <div className="h-px w-8 md:w-16" style={{ background: step > i + 1 ? "#D4AF37" : "#2E2E2E" }} />}
            </div>
          ))}
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            {step === 1 && (
              <div className="rounded-2xl p-6 space-y-4" style={{ background: "#1E1E1E", border: "1px solid #2E2E2E" }}>
                <h3 className="font-display text-xl font-semibold mb-6" style={{ color: "#F5F5F5" }}>Delivery Information</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-medium mb-2" style={{ color: "#A0A0A0" }}>Full Name *</label>
                    <input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Your name" />
                  </div>
                  <div>
                    <label className="block text-xs font-medium mb-2" style={{ color: "#A0A0A0" }}>Mobile Number *</label>
                    <input required value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} placeholder="+356 XXXX XXXX" />
                  </div>
                  <div className="col-span-2">
                    <label className="block text-xs font-medium mb-2" style={{ color: "#A0A0A0" }}>Email</label>
                    <input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} placeholder="email@example.com" />
                  </div>
                  <div className="col-span-2">
                    <label className="block text-xs font-medium mb-2" style={{ color: "#A0A0A0" }}>Full Address *</label>
                    <input required value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} placeholder="Street, apartment, building" />
                  </div>
                  <div>
                    <label className="block text-xs font-medium mb-2" style={{ color: "#A0A0A0" }}>Town / Area</label>
                    <select value={form.area} onChange={(e) => setForm({ ...form, area: e.target.value })}>
                      <option value="">Select area</option>
                      {MALTA_AREAS.map((a) => <option key={a}>{a}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-medium mb-2" style={{ color: "#A0A0A0" }}>Country</label>
                    <input value={form.city} readOnly style={{ background: "#2A2A2A", color: "#7A7A7A" }} />
                  </div>
                </div>
                <div className="pt-2">
                  <label className="block text-xs font-medium mb-2" style={{ color: "#A0A0A0" }}>Special Instructions</label>
                  <textarea rows={3} placeholder="Allergies, special requests or delivery notes…" style={{ resize: "none" }} />
                </div>
                <button onClick={() => setStep(2)} className="btn-gold w-full py-3 rounded-xl text-sm font-semibold uppercase tracking-wide mt-4">
                  Proceed to Payment →
                </button>
              </div>
            )}

            {step === 2 && (
              <div className="rounded-2xl p-6 space-y-6" style={{ background: "#1E1E1E", border: "1px solid #2E2E2E" }}>
                <h3 className="font-display text-xl font-semibold" style={{ color: "#F5F5F5" }}>Payment Method</h3>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  {[
                    { key: "card", label: "Credit / Debit Card", icon: "💳" },
                    { key: "cash", label: "Cash on Delivery", icon: "💵" },
                    { key: "revolut", label: "Revolut", icon: "📱" },
                  ].map((m) => (
                    <button key={m.key} onClick={() => setPaymentMethod(m.key)} className="flex flex-col items-center gap-2 p-4 rounded-xl transition-all text-xs font-medium" style={{ background: paymentMethod === m.key ? "rgba(212,175,55,0.1)" : "#2A2A2A", border: paymentMethod === m.key ? "1px solid #D4AF37" : "1px solid #3A3A3A", color: paymentMethod === m.key ? "#D4AF37" : "#A0A0A0" }}>
                      <span className="text-2xl">{m.icon}</span>
                      {m.label}
                    </button>
                  ))}
                </div>

                {paymentMethod === "card" && (
                  <div className="space-y-4">
                    <div>
                      <label className="block text-xs font-medium mb-2" style={{ color: "#A0A0A0" }}>Card Number</label>
                      <input value={form.cardNumber} onChange={(e) => setForm({ ...form, cardNumber: e.target.value })} placeholder="4242 4242 4242 4242" className="font-mono" />
                    </div>
                    <div className="grid grid-cols-3 gap-4">
                      <div className="col-span-2">
                        <label className="block text-xs font-medium mb-2" style={{ color: "#A0A0A0" }}>Cardholder Name</label>
                        <input value={form.cardName} onChange={(e) => setForm({ ...form, cardName: e.target.value })} placeholder="Your Name" />
                      </div>
                      <div>
                        <label className="block text-xs font-medium mb-2" style={{ color: "#A0A0A0" }}>Expiry</label>
                        <input value={form.expiry} onChange={(e) => setForm({ ...form, expiry: e.target.value })} placeholder="MM/YY" className="font-mono" />
                      </div>
                    </div>
                  </div>
                )}

                {paymentMethod === "cash" && (
                  <div className="rounded-xl p-4 flex gap-3" style={{ background: "rgba(212,175,55,0.08)", border: "1px solid rgba(212,175,55,0.2)" }}>
                    <span className="text-xl">ℹ️</span>
                    <p className="text-sm" style={{ color: "#D0D0D0" }}>
                      Please have <strong style={{ color: "#D4AF37" }}>€{total.toFixed(2)}</strong> ready when the delivery arrives.
                    </p>
                  </div>
                )}

                {paymentMethod === "revolut" && (
                  <div className="rounded-xl p-4 flex gap-3" style={{ background: "rgba(212,175,55,0.06)", border: "1px solid rgba(212,175,55,0.2)" }}>
                    <p className="text-sm" style={{ color: "#D0D0D0" }}>
                      📱 Send <strong style={{ color: "#D4AF37" }}>€{total.toFixed(2)}</strong> via Revolut to <strong style={{ color: "#D4AF37" }}>@thekitchenmalta</strong>. Include your order reference.
                    </p>
                  </div>
                )}

                <div className="flex gap-3">
                  <button onClick={() => setStep(1)} className="btn-outline-gold px-6 py-3 rounded-xl text-sm font-semibold">← Back</button>
                  <button onClick={() => setStep(3)} className="btn-gold flex-1 py-3 rounded-xl text-sm font-semibold uppercase tracking-wide">Review Order →</button>
                </div>
              </div>
            )}

            {step === 3 && (
              <div className="rounded-2xl p-6 space-y-6" style={{ background: "#1E1E1E", border: "1px solid #2E2E2E" }}>
                <h3 className="font-display text-xl font-semibold" style={{ color: "#F5F5F5" }}>Confirm Order</h3>
                <div className="space-y-3">
                  {cartItems.map((item) => (
                    <div key={item.id} className="flex items-center gap-3">
                      <img src={item.image} alt={item.name} loading="lazy" className="w-12 h-12 rounded-lg object-cover" width={48} height={48} />
                      <div className="flex-1">
                        <div className="text-sm font-medium" style={{ color: "#F5F5F5" }}>{item.name}</div>
                        <div className="text-xs" style={{ color: "#A0A0A0" }}>×{item.quantity}</div>
                      </div>
                      <div className="font-mono text-sm" style={{ color: "#D4AF37" }}>€{(item.price * item.quantity).toFixed(2)}</div>
                    </div>
                  ))}
                </div>
                <hr style={{ borderColor: "#2E2E2E" }} />
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <div className="text-xs font-semibold mb-1 uppercase tracking-wider" style={{ color: "#A0A0A0" }}>Delivery Address</div>
                    <div style={{ color: "#F5F5F5" }}>{form.name || "Guest"}</div>
                    <div style={{ color: "#A0A0A0" }}>{form.address || "Address not provided"}</div>
                    <div style={{ color: "#A0A0A0" }}>{form.area} {form.city && `· ${form.city}`}</div>
                  </div>
                  <div>
                    <div className="text-xs font-semibold mb-1 uppercase tracking-wider" style={{ color: "#A0A0A0" }}>Payment</div>
                    <div style={{ color: "#F5F5F5" }}>
                      {paymentMethod === "card" ? "Credit / Debit Card" : paymentMethod === "cash" ? "Cash on Delivery" : "Revolut"}
                    </div>
                  </div>
                </div>
                <div className="flex gap-3">
                  <button onClick={() => setStep(2)} className="btn-outline-gold px-6 py-3 rounded-xl text-sm font-semibold">← Back</button>
                  <button onClick={handlePlace} className="btn-gold flex-1 py-3 rounded-xl text-sm font-bold uppercase tracking-wide">
                    Place Order · €{total.toFixed(2)}
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Summary sidebar */}
          <div>
            <div className="rounded-2xl p-6 sticky top-24" style={{ background: "#1E1E1E", border: "1px solid #2E2E2E" }}>
              <h3 className="font-semibold mb-4" style={{ color: "#F5F5F5" }}>Order Summary</h3>
              <div className="space-y-2 text-sm mb-4">
                <div className="flex justify-between">
                  <span style={{ color: "#A0A0A0" }}>Subtotal</span>
                  <span style={{ color: "#F5F5F5" }}>€{subtotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span style={{ color: "#A0A0A0" }}>Delivery</span>
                  <span style={{ color: "#F5F5F5" }}>€{deliveryFee.toFixed(2)}</span>
                </div>
                <hr style={{ borderColor: "#2E2E2E" }} />
                <div className="flex justify-between font-bold">
                  <span style={{ color: "#F5F5F5" }}>Total</span>
                  <span className="font-mono" style={{ color: "#D4AF37" }}>€{total.toFixed(2)}</span>
                </div>
              </div>
              <div className="flex items-center gap-2 text-xs" style={{ color: "#5A5A5A" }}>
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" /></svg>
                SSL Secured · Card · Cash · Revolut
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
