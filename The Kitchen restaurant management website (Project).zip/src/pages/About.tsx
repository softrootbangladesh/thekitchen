import { useEffect, useRef } from "react";

function useScrollReveal() {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!ref.current) return;
    const el = ref.current;
    const obs = new IntersectionObserver(
      (entries) => entries.forEach((e) => { if (e.isIntersecting) { e.target.classList.add("revealed"); obs.unobserve(e.target); } }),
      { threshold: 0.1, rootMargin: "0px 0px -40px 0px" }
    );
    const t = setTimeout(() => {
      el.querySelectorAll(".reveal, .reveal-left, .reveal-right").forEach((item) => obs.observe(item));
    }, 60);
    return () => { clearTimeout(t); obs.disconnect(); };
  }, []);
  return ref;
}

const TEAM = [
  {
    name: "Chef Yusuf Al-Rashid",
    title: "Executive Chef & Co-Founder",
    bio: "Born in Beirut and trained across Dubai and Istanbul's finest kitchens, Chef Yusuf brought his passion for bold, halal-certified cuisine to Malta in 2019. His philosophy: premium ingredients, honest cooking, unforgettable results.",
    img: "https://images.unsplash.com/photo-1577219491135-ce391730fb2c?w=400&h=500&fit=crop&auto=format",
    awards: ["Best Chef Malta 2023", "Mediterranean Halal Dining Award 2024"],
  },
  {
    name: "Marco Camilleri",
    title: "Head of Smokehouse",
    bio: "A Malta native with 12 years of BBQ mastery across the US and UK, Marco oversees The Kitchen's signature 24-hour smoke programme. His Texas Brisket has been called 'the best slow-smoked meat in the Mediterranean.'",
    img: "https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=400&h=500&fit=crop&auto=format",
    awards: ["Pitmaster of the Year · Malta Food Awards 2024"],
  },
  {
    name: "Fatima Zarour",
    title: "Operations & Guest Experience",
    bio: "Fatima ensures every visit — dine-in or delivery — meets The Kitchen standard. With a background in luxury hospitality from Dubai and London, she has built a team that treats every guest like family.",
    img: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=500&fit=crop&auto=format",
    awards: ["Best Hospitality Team · Malta 2024"],
  },
];

const MILESTONES = [
  { year: "2019", event: "The Kitchen Malta opens its doors — the island's first premium 100% Halal burger & smokehouse restaurant." },
  { year: "2020", event: "Online ordering launched; delivery expands across Valletta, Sliema, and St. Julian's." },
  { year: "2021", event: "Smokehouse Collection introduced — Texas Brisket becomes an instant cult favourite." },
  { year: "2022", event: "Awarded 'Best New Restaurant in Malta' by Malta Food & Wine Guide." },
  { year: "2023", event: "Named Best Chef Malta. Truffle Deluxe Burger featured in international food press." },
  { year: "2024", event: "Mediterranean Halal Dining Award. Loyalty programme launched; 20,000+ members." },
  { year: "2025", event: "Kitchen Rewards app launched. Over 50,000 satisfied guests served across Malta." },
];

const VALUES = [
  { icon: "✓", title: "100% Halal, Always", desc: "Every ingredient, every supplier, every dish — certified Halal. No exceptions, no compromises. Our guests deserve complete confidence in what they eat." },
  { icon: "🔥", title: "Craft & Passion", desc: "From 24-hour smoked brisket to hand-pressed burger patties, everything is made with obsessive care. We don't cut corners — we cut only the finest meats." },
  { icon: "🌿", title: "Fresh Every Day", desc: "We source produce fresh daily from Malta's local markets and trusted suppliers. Nothing frozen. Nothing artificial. Just clean, honest food you can taste." },
];

export default function About() {
  const ref = useScrollReveal();

  return (
    <div className="min-h-screen" ref={ref}>
      {/* ── HERO ─────────────────────────────────────────── */}
      <section className="relative pt-32 pb-24 px-6 overflow-hidden" style={{ background: "#0D0D0D" }}>
        <div className="absolute inset-0 pointer-events-none" style={{ background: "radial-gradient(ellipse at 70% 50%, rgba(212,175,55,0.05) 0%, transparent 60%)" }} />
        <div className="max-w-6xl mx-auto grid md:grid-cols-2 gap-16 items-center">
          <div className="reveal-left">
            <p className="text-xs tracking-widest uppercase mb-4 font-mono" style={{ color: "#D4AF37" }}>— Our Story —</p>
            <h1 className="font-display font-bold leading-tight mb-6" style={{ color: "#F5F5F5", fontSize: "clamp(2.5rem, 6vw, 4rem)" }}>
              Born from a passion for<br />
              <em style={{ color: "#D4AF37" }}>honest, halal food.</em>
            </h1>
            <p className="text-base leading-relaxed mb-5" style={{ color: "#7A7A7A" }}>
              The Kitchen Malta was born from a simple but powerful belief: that 100% Halal food in Malta should never mean a compromise on quality, creativity, or experience. When Chef Yusuf Al-Rashid arrived in Malta in 2019, that vision became a restaurant.
            </p>
            <p className="text-base leading-relaxed mb-8" style={{ color: "#7A7A7A" }}>
              From our hand-pressed burgers to our 24-hour smoked brisket, every dish is a reflection of what food can be when passion meets precision — and when integrity is never negotiable.
            </p>
            <div className="flex gap-3 flex-wrap">
              {["Est. 2019", "100% Halal", "Malta", "Made With Passion"].map((badge) => (
                <span key={badge} className="text-xs px-3.5 py-1.5 rounded-full font-mono font-semibold" style={{ background: "rgba(212,175,55,0.07)", border: "1px solid rgba(212,175,55,0.18)", color: "#D4AF37" }}>
                  {badge}
                </span>
              ))}
            </div>
          </div>
          <div className="relative reveal-right">
            <div className="rounded-3xl overflow-hidden img-zoom-wrap" style={{ border: "1px solid rgba(212,175,55,0.15)" }}>
              <img
                src="https://images.unsplash.com/photo-1414235077428-338989a2e8c0?w=700&h=520&fit=crop&auto=format&q=80"
                alt="The Kitchen Malta interior"
                loading="lazy"
                decoding="async"
                className="w-full object-cover"
                style={{ height: "440px" }}
                width={700}
                height={440}
              />
            </div>
            <div
              className="absolute -bottom-5 -left-5 rounded-2xl p-5 hidden md:block animate-float"
              style={{ background: "#161616", border: "1px solid rgba(212,175,55,0.25)", boxShadow: "0 8px 32px rgba(0,0,0,0.7)" }}
            >
              <div className="text-2xl font-display font-black gold-gradient">Est. 2019</div>
              <div className="text-xs font-mono mt-1" style={{ color: "#5A5A5A" }}>Malta's Premier Halal Kitchen</div>
            </div>
          </div>
        </div>
      </section>

      {/* ── MISSION QUOTE ───────────────────────────────── */}
      <section className="py-20 px-6" style={{ background: "#080808" }}>
        <div className="max-w-4xl mx-auto text-center reveal">
          <div className="text-5xl mb-6" style={{ color: "rgba(212,175,55,0.3)", fontFamily: "serif" }}>"</div>
          <blockquote className="font-display text-2xl md:text-3xl font-semibold italic leading-relaxed mb-6" style={{ color: "#E8E8E8" }}>
            Every dish we serve carries a promise — that it was made with care, with pride, and with 100% Halal ingredients. That promise will never change.
          </blockquote>
          <div className="flex items-center justify-center gap-3">
            <div className="w-9 h-9 rounded-full flex items-center justify-center font-bold text-sm" style={{ background: "linear-gradient(135deg, #D4AF37, #E8C96B)", color: "#0D0D0D" }}>Y</div>
            <div className="text-left">
              <div className="text-sm font-semibold" style={{ color: "#F5F5F5" }}>Chef Yusuf Al-Rashid</div>
              <div className="text-xs font-mono" style={{ color: "#5A5A5A" }}>Executive Chef & Co-Founder</div>
            </div>
          </div>
        </div>
      </section>

      {/* ── VALUES ──────────────────────────────────────── */}
      <section className="py-20 px-6" style={{ background: "#0D0D0D" }}>
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-14 reveal">
            <p className="text-xs tracking-widest uppercase mb-3 font-mono" style={{ color: "#D4AF37" }}>— What We Stand For —</p>
            <h2 className="font-display text-4xl font-bold" style={{ color: "#F5F5F5" }}>Our Values</h2>
          </div>
          <div className="grid md:grid-cols-3 gap-6">
            {VALUES.map((v, i) => (
              <div
                key={v.title}
                className={`reveal card-hover rounded-2xl p-7 stagger-${i + 1}`}
                style={{ background: "#111111", border: "1px solid rgba(255,255,255,0.05)" }}
              >
                <div className="w-12 h-12 rounded-xl flex items-center justify-center text-xl mb-5" style={{ background: "rgba(212,175,55,0.1)", border: "1px solid rgba(212,175,55,0.2)" }}>
                  {v.icon}
                </div>
                <h3 className="font-display text-xl font-semibold mb-3" style={{ color: "#F5F5F5" }}>{v.title}</h3>
                <p className="text-sm leading-relaxed" style={{ color: "#6A6A6A" }}>{v.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── TEAM ────────────────────────────────────────── */}
      <section className="py-20 px-6" style={{ background: "#080808" }}>
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-14 reveal">
            <p className="text-xs tracking-widest uppercase mb-3 font-mono" style={{ color: "#D4AF37" }}>— The People Behind the Food —</p>
            <h2 className="font-display text-4xl font-bold" style={{ color: "#F5F5F5" }}>Meet the Team</h2>
          </div>
          <div className="grid md:grid-cols-3 gap-7">
            {TEAM.map((member, i) => (
              <div
                key={member.name}
                className={`reveal card-hover rounded-2xl overflow-hidden stagger-${i + 1}`}
                style={{ background: "#111111", border: "1px solid rgba(255,255,255,0.05)" }}
              >
                <div className="img-zoom-wrap" style={{ height: "240px", background: "#1A1A1A" }}>
                  <img
                    src={member.img}
                    alt={member.name}
                    loading="lazy"
                    decoding="async"
                    className="w-full h-full object-cover"
                    width={400}
                    height={240}
                  />
                </div>
                <div className="p-6">
                  <h3 className="font-display text-lg font-bold mb-0.5" style={{ color: "#F5F5F5" }}>{member.name}</h3>
                  <p className="text-xs font-semibold uppercase tracking-wider mb-4 font-mono" style={{ color: "#D4AF37" }}>{member.title}</p>
                  <p className="text-sm leading-relaxed mb-5" style={{ color: "#6A6A6A" }}>{member.bio}</p>
                  <div className="space-y-1.5">
                    {member.awards.map((a) => (
                      <div key={a} className="text-xs flex items-center gap-2 font-mono" style={{ color: "#D4AF37" }}>
                        <span style={{ color: "#D4AF37" }}>⭐</span> {a}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── TIMELINE ────────────────────────────────────── */}
      <section className="py-20 px-6" style={{ background: "#0D0D0D" }}>
        <div className="max-w-3xl mx-auto">
          <div className="text-center mb-14 reveal">
            <p className="text-xs tracking-widest uppercase mb-3 font-mono" style={{ color: "#D4AF37" }}>— Our Journey —</p>
            <h2 className="font-display text-4xl font-bold" style={{ color: "#F5F5F5" }}>Six Years of Passion</h2>
          </div>
          <div className="relative">
            <div className="absolute left-16 top-0 bottom-0 w-px" style={{ background: "linear-gradient(to bottom, rgba(212,175,55,0.4), rgba(212,175,55,0.05))" }} />
            <div className="space-y-7">
              {MILESTONES.map((m, i) => (
                <div key={m.year} className={`flex gap-6 items-start reveal stagger-${Math.min(i + 1, 6)}`}>
                  <div className="shrink-0 w-14 text-right">
                    <span className="font-mono font-bold text-sm" style={{ color: "#D4AF37" }}>{m.year}</span>
                  </div>
                  <div
                    className="w-4 h-4 rounded-full shrink-0 mt-0.5 z-10 transition-all"
                    style={{ background: "linear-gradient(135deg, #D4AF37, #E8C96B)", border: "3px solid #0D0D0D", boxShadow: "0 0 8px rgba(212,175,55,0.4)" }}
                  />
                  <p className="text-sm leading-relaxed pt-0.5" style={{ color: "#A0A0A0" }}>{m.event}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ── HALAL PROMISE BANNER ─────────────────────────── */}
      <section className="py-16 px-6" style={{ background: "#080808" }}>
        <div className="max-w-4xl mx-auto reveal">
          <div className="rounded-3xl p-10 md:p-14 text-center relative overflow-hidden" style={{ background: "linear-gradient(135deg, #0F1A0A, #0A130A)", border: "1px solid rgba(94,196,94,0.2)" }}>
            <div className="absolute inset-0 pointer-events-none" style={{ background: "radial-gradient(ellipse at 50% 0%, rgba(94,196,94,0.06) 0%, transparent 60%)" }} />
            <div className="text-5xl mb-5">✓</div>
            <h2 className="font-display text-3xl md:text-4xl font-bold mb-4 relative" style={{ color: "#F5F5F5" }}>
              Our Halal Promise
            </h2>
            <p className="text-base leading-relaxed max-w-xl mx-auto relative" style={{ color: "#7A7A7A" }}>
              Every item on our menu is certified 100% Halal — verified by accredited certification bodies. We are transparent about our sourcing and proud to serve a community that deserves the very best.
            </p>
            <div className="flex justify-center gap-4 mt-8 flex-wrap relative">
              {["Halal Certified Meat", "No Alcohol", "No Pork", "Transparent Sourcing"].map((tag) => (
                <span key={tag} className="text-xs px-4 py-2 rounded-full font-mono font-semibold" style={{ background: "rgba(94,196,94,0.1)", border: "1px solid rgba(94,196,94,0.25)", color: "#5EC45E" }}>
                  ✓ {tag}
                </span>
              ))}
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
