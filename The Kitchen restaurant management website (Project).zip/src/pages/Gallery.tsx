import { useState, useEffect, useCallback } from "react";
import { galleryImages } from "../data/menuData";

const FILTER_CATS = ["All", "Food", "Drinks", "Interior", "Ambience"];

export default function Gallery() {
  const [filter, setFilter] = useState("All");
  const [lightbox, setLightbox] = useState<null | typeof galleryImages[0]>(null);
  const [lightboxLoaded, setLightboxLoaded] = useState(false);

  const filtered = filter === "All" ? galleryImages : galleryImages.filter((img) => img.category === filter);

  // Build a high-res URL robustly — replace any w=NNN or add width param
  const hiResUrl = (src: string) => {
    if (src.includes("w=")) {
      return src.replace(/w=\d+/, "w=1400").replace(/h=\d+/, "h=900");
    }
    const sep = src.includes("?") ? "&" : "?";
    return `${src}${sep}w=1400&h=900&fit=crop&auto=format`;
  };

  const closeLightbox = useCallback(() => {
    setLightbox(null);
    setLightboxLoaded(false);
  }, []);

  const navLightbox = useCallback((dir: 1 | -1) => {
    if (!lightbox) return;
    const idx = filtered.findIndex((i) => i.id === lightbox.id);
    const next = filtered[(idx + dir + filtered.length) % filtered.length];
    setLightbox(next);
    setLightboxLoaded(false);
  }, [lightbox, filtered]);

  // Keyboard navigation
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (!lightbox) return;
      if (e.key === "Escape") closeLightbox();
      if (e.key === "ArrowRight") navLightbox(1);
      if (e.key === "ArrowLeft") navLightbox(-1);
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [lightbox, closeLightbox, navLightbox]);

  // Prevent body scroll when lightbox is open
  useEffect(() => {
    document.body.style.overflow = lightbox ? "hidden" : "";
    return () => { document.body.style.overflow = ""; };
  }, [lightbox]);

  return (
    <div className="min-h-screen" style={{ background: "#0A0A0A" }}>
      {/* Header */}
      <div className="pt-28 pb-14 px-6 text-center" style={{ background: "linear-gradient(to bottom, #0D0D0D, #0A0A0A)" }}>
        <p className="text-xs tracking-widest uppercase mb-3 font-mono animate-fade-in" style={{ color: "#D4AF37" }}>— A Visual Feast —</p>
        <h1 className="font-display font-bold mb-4 animate-fade-in" style={{ color: "#F5F5F5", fontSize: "clamp(2.5rem, 7vw, 4.5rem)", animationDelay: "0.1s" }}>
          Gallery
        </h1>
        <p className="text-base max-w-md mx-auto animate-fade-in" style={{ color: "#6A6A6A", animationDelay: "0.15s" }}>
          From the pass to the plate — a glimpse into The Kitchen Malta.
        </p>
      </div>

      <div className="max-w-7xl mx-auto px-6 pb-24">
        {/* Filter pills */}
        <div className="flex gap-2.5 justify-center mb-10 flex-wrap animate-fade-in" style={{ animationDelay: "0.2s" }}>
          {FILTER_CATS.map((cat) => (
            <button
              key={cat}
              onClick={() => setFilter(cat)}
              className={`cat-pill ${filter === cat ? "active" : "inactive"}`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Masonry grid */}
        <div className="columns-1 sm:columns-2 lg:columns-3 gap-4" style={{ columnGap: "16px" }}>
          {filtered.map((img, i) => (
            <div
              key={img.id}
              className="break-inside-avoid cursor-pointer group relative rounded-2xl overflow-hidden mb-4 animate-fade-in"
              style={{
                border: "1px solid rgba(255,255,255,0.05)",
                animationDelay: `${(i % 6) * 0.06}s`,
              }}
              onClick={() => { setLightbox(img); setLightboxLoaded(false); }}
            >
              <div className="img-zoom-wrap">
                <img
                  src={img.src}
                  alt={img.alt}
                  loading="lazy"
                  decoding="async"
                  className="w-full object-cover"
                  style={{ display: "block" }}
                />
              </div>
              {/* Hover overlay */}
              <div
                className="absolute inset-0 flex items-end p-4 opacity-0 group-hover:opacity-100 transition-all duration-350"
                style={{ background: "linear-gradient(to top, rgba(8,8,8,0.9) 0%, rgba(8,8,8,0.2) 60%, transparent 100%)" }}
              >
                <div className="translate-y-2 group-hover:translate-y-0 transition-transform duration-300">
                  <span className="text-xs font-mono px-2.5 py-1 rounded-full inline-block mb-2" style={{ background: "rgba(212,175,55,0.2)", color: "#D4AF37", border: "1px solid rgba(212,175,55,0.3)" }}>
                    {img.category}
                  </span>
                  <p className="text-sm" style={{ color: "#F5F5F5" }}>{img.alt}</p>
                </div>
                {/* Expand icon */}
                <div className="absolute top-3 right-3 w-8 h-8 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all" style={{ background: "rgba(212,175,55,0.2)", border: "1px solid rgba(212,175,55,0.3)" }}>
                  <svg className="w-4 h-4" fill="none" stroke="#D4AF37" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 8V4m0 0h4M4 4l5 5m11-1V4m0 0h-4m4 0l-5 5M4 16v4m0 0h4m-4 0l5-5m11 5l-5-5m5 5v-4m0 4h-4" />
                  </svg>
                </div>
              </div>
            </div>
          ))}
        </div>

        {filtered.length === 0 && (
          <div className="text-center py-24 animate-fade-in">
            <div className="text-5xl mb-4">📷</div>
            <p className="text-sm" style={{ color: "#5A5A5A" }}>No photos in this category yet.</p>
          </div>
        )}
      </div>

      {/* Lightbox */}
      {lightbox && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 md:p-8 animate-fade-in-fast"
          style={{ background: "rgba(0,0,0,0.96)", backdropFilter: "blur(12px)" }}
          onClick={closeLightbox}
        >
          <div className="relative max-w-5xl w-full" onClick={(e) => e.stopPropagation()}>
            {/* Close */}
            <button
              onClick={closeLightbox}
              className="absolute -top-12 right-0 flex items-center gap-2 text-sm transition-all"
              style={{ color: "#5A5A5A" }}
              onMouseEnter={(e) => (e.currentTarget.style.color = "#D4AF37")}
              onMouseLeave={(e) => (e.currentTarget.style.color = "#5A5A5A")}
            >
              Close <span style={{ fontSize: "18px" }}>×</span>
            </button>

            {/* Image */}
            <div className="relative rounded-2xl overflow-hidden" style={{ background: "#111111", minHeight: "300px" }}>
              {!lightboxLoaded && (
                <div className="absolute inset-0 flex items-center justify-center" style={{ background: "#111111" }}>
                  <div style={{ width: "40px", height: "40px" }}>
                    <svg style={{ animation: "spin 0.9s linear infinite", width: "100%", height: "100%" }} viewBox="0 0 40 40" fill="none">
                      <circle cx="20" cy="20" r="16" stroke="#2A2A2A" strokeWidth="3" />
                      <circle cx="20" cy="20" r="16" stroke="url(#lb-grad)" strokeWidth="3" strokeLinecap="round" strokeDasharray="70 30" />
                      <defs>
                        <linearGradient id="lb-grad" x1="0" y1="0" x2="40" y2="40" gradientUnits="userSpaceOnUse">
                          <stop stopColor="#D4AF37" />
                          <stop offset="1" stopColor="#E8C96B" />
                        </linearGradient>
                      </defs>
                    </svg>
                  </div>
                </div>
              )}
              <img
                src={hiResUrl(lightbox.src)}
                alt={lightbox.alt}
                className="w-full rounded-2xl object-contain transition-opacity duration-300"
                style={{ maxHeight: "78vh", display: "block", opacity: lightboxLoaded ? 1 : 0 }}
                onLoad={() => setLightboxLoaded(true)}
              />
            </div>

            {/* Caption */}
            <div className="flex items-center gap-3 mt-4">
              <span className="text-xs font-mono px-2.5 py-1 rounded-full" style={{ background: "rgba(212,175,55,0.15)", color: "#D4AF37", border: "1px solid rgba(212,175,55,0.25)" }}>
                {lightbox.category}
              </span>
              <p className="text-sm" style={{ color: "#7A7A7A" }}>{lightbox.alt}</p>
              <span className="ml-auto text-xs font-mono" style={{ color: "#3A3A3A" }}>
                {filtered.findIndex((i) => i.id === lightbox.id) + 1} / {filtered.length}
              </span>
            </div>

            {/* Prev / Next */}
            <button
              className="absolute top-1/2 -translate-y-1/2 -left-5 md:-left-14 w-11 h-11 rounded-full flex items-center justify-center transition-all"
              style={{ background: "rgba(212,175,55,0.15)", border: "1px solid rgba(212,175,55,0.25)", color: "#D4AF37" }}
              onClick={(e) => { e.stopPropagation(); navLightbox(-1); }}
              onMouseEnter={(e) => (e.currentTarget.style.background = "rgba(212,175,55,0.28)")}
              onMouseLeave={(e) => (e.currentTarget.style.background = "rgba(212,175,55,0.15)")}
              aria-label="Previous image"
            >
              <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" /></svg>
            </button>
            <button
              className="absolute top-1/2 -translate-y-1/2 -right-5 md:-right-14 w-11 h-11 rounded-full flex items-center justify-center transition-all"
              style={{ background: "rgba(212,175,55,0.15)", border: "1px solid rgba(212,175,55,0.25)", color: "#D4AF37" }}
              onClick={(e) => { e.stopPropagation(); navLightbox(1); }}
              onMouseEnter={(e) => (e.currentTarget.style.background = "rgba(212,175,55,0.28)")}
              onMouseLeave={(e) => (e.currentTarget.style.background = "rgba(212,175,55,0.15)")}
              aria-label="Next image"
            >
              <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" /></svg>
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
