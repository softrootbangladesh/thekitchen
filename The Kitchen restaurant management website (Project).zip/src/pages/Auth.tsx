import { useState } from "react";

interface AuthProps {
  onLogin: () => void;
  onNavigate: (page: string) => void;
}

export default function Auth({ onLogin, onNavigate }: AuthProps) {
  const [mode, setMode] = useState<"login" | "signup">("login");
  const [form, setForm] = useState({ name: "", email: "", phone: "", password: "", confirm: "" });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onLogin();
    onNavigate("dashboard");
  };

  return (
    <div className="min-h-screen flex items-center justify-center px-6 pt-24 pb-24">
      <div className="w-full max-w-md">
        {/* Logo area */}
        <div className="text-center mb-10">
          <h1 className="font-display text-4xl font-bold mb-2" style={{ color: "#F5F5F5" }}>
            {mode === "login" ? "Welcome Back" : "Create Account"}
          </h1>
          <p className="text-sm" style={{ color: "#A0A0A0" }}>
            {mode === "login"
              ? "Sign in to access your Kitchen account"
              : "Join The Kitchen — free, fast, and full of perks"}
          </p>
        </div>

        {/* Toggle */}
        <div className="flex p-1 rounded-xl mb-8" style={{ background: "#1E1E1E" }}>
          {(["login", "signup"] as const).map((m) => (
            <button
              key={m}
              onClick={() => setMode(m)}
              className="flex-1 py-2.5 rounded-lg text-sm font-semibold transition-all capitalize"
              style={{
                background: mode === m ? "#D4AF37" : "transparent",
                color: mode === m ? "#0D0D0D" : "#A0A0A0",
              }}
            >
              {m === "login" ? "Sign In" : "Sign Up"}
            </button>
          ))}
        </div>

        {/* Form */}
        <form
          onSubmit={handleSubmit}
          className="rounded-2xl p-8 space-y-4"
          style={{ background: "#1E1E1E", border: "1px solid #2E2E2E" }}
        >
          {mode === "signup" && (
            <>
              <div>
                <label className="block text-xs font-medium mb-2" style={{ color: "#A0A0A0" }}>Full Name *</label>
                <input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Jane Smith" />
              </div>
              <div>
                <label className="block text-xs font-medium mb-2" style={{ color: "#A0A0A0" }}>Phone</label>
                <input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} placeholder="+1 (555) 000-0000" />
              </div>
            </>
          )}
          <div>
            <label className="block text-xs font-medium mb-2" style={{ color: "#A0A0A0" }}>Email *</label>
            <input required type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} placeholder="jane@example.com" />
          </div>
          <div>
            <label className="block text-xs font-medium mb-2" style={{ color: "#A0A0A0" }}>Password *</label>
            <input required type="password" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} placeholder="••••••••" />
          </div>
          {mode === "signup" && (
            <div>
              <label className="block text-xs font-medium mb-2" style={{ color: "#A0A0A0" }}>Confirm Password *</label>
              <input required type="password" value={form.confirm} onChange={(e) => setForm({ ...form, confirm: e.target.value })} placeholder="••••••••" />
            </div>
          )}

          {mode === "login" && (
            <div className="flex justify-end">
              <button type="button" className="text-xs" style={{ color: "#D4AF37" }}>Forgot password?</button>
            </div>
          )}

          <button type="submit" className="btn-gold w-full py-3 rounded-xl text-sm font-bold uppercase tracking-wide mt-2">
            {mode === "login" ? "Sign In" : "Create Account"}
          </button>

          {mode === "signup" && (
            <p className="text-xs text-center" style={{ color: "#5A5A5A" }}>
              By signing up, you agree to our{" "}
              <span style={{ color: "#D4AF37", cursor: "pointer" }}>Terms of Service</span> and{" "}
              <span style={{ color: "#D4AF37", cursor: "pointer" }}>Privacy Policy</span>.
            </p>
          )}
        </form>

        {/* Divider + social */}
        <div className="flex items-center gap-3 my-6">
          <div className="flex-1 h-px" style={{ background: "#2E2E2E" }} />
          <span className="text-xs" style={{ color: "#5A5A5A" }}>or continue with</span>
          <div className="flex-1 h-px" style={{ background: "#2E2E2E" }} />
        </div>
        <div className="grid grid-cols-2 gap-3">
          {["Google", "Apple"].map((provider) => (
            <button
              key={provider}
              type="button"
              onClick={() => { onLogin(); onNavigate("dashboard"); }}
              className="flex items-center justify-center gap-2 py-3 rounded-xl text-sm font-semibold transition-all"
              style={{ background: "#1E1E1E", border: "1px solid #2E2E2E", color: "#F5F5F5" }}
            >
              <span>{provider === "Google" ? "G" : ""}{provider === "Apple" ? "🍎" : ""}</span>
              {provider}
            </button>
          ))}
        </div>

        {/* Perks (signup mode) */}
        {mode === "signup" && (
          <div className="mt-8 rounded-xl p-5" style={{ background: "rgba(212,175,55,0.06)", border: "1px solid rgba(212,175,55,0.2)" }}>
            <p className="text-xs font-semibold mb-3 uppercase tracking-wider" style={{ color: "#D4AF37" }}>Member Benefits</p>
            <ul className="space-y-2">
              {[
                "500 Kitchen Points on sign-up",
                "Early access to seasonal menus",
                "Priority reservation booking",
                "Exclusive member events",
              ].map((perk) => (
                <li key={perk} className="text-sm flex items-center gap-2" style={{ color: "#D0D0D0" }}>
                  <span style={{ color: "#D4AF37" }}>✓</span> {perk}
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>
    </div>
  );
}
