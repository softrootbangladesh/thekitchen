import { useState } from "react";
import { menuItems } from "../data/menuData";

const orderHistory = [
  { id: "TK-2847", date: "July 31, 2026", items: ["Truffle Deluxe", "Smokehouse BBQ", "Fresh Fries"], total: 29.30, status: "Delivered" },
  { id: "TK-2741", date: "July 15, 2026", items: ["Texas Brisket", "Patata Harrah"], total: 18.00, status: "Delivered" },
  { id: "TK-2688", date: "July 3, 2026", items: ["Smoked Lamb Shank", "Beef Wrap"], total: 22.80, status: "Delivered" },
  { id: "TK-2591", date: "June 18, 2026", items: ["Margherita", "Falafel Wrap", "Side Salad"], total: 18.40, status: "Delivered" },
];

const favorites = menuItems.filter((i) => i.popular).slice(0, 4);

const savedAddresses = [
  { id: 1, label: "Home", address: "15, St. Julian's Road, Sliema, Malta", default: true },
  { id: 2, label: "Work", address: "Valletta Business District, Valletta, Malta", default: false },
];

const LOYALTY_POINTS = 2340;
const LOYALTY_TIERS = [
  { name: "Silver", min: 0, max: 1000, color: "#A0A0A0" },
  { name: "Gold", min: 1000, max: 3000, color: "#D4AF37" },
  { name: "Platinum", min: 3000, max: 6000, color: "#B8D4F5" },
];

const currentTier = LOYALTY_TIERS.find((t) => LOYALTY_POINTS >= t.min && LOYALTY_POINTS < t.max) || LOYALTY_TIERS[1];
const tierProgress = ((LOYALTY_POINTS - currentTier.min) / (currentTier.max - currentTier.min)) * 100;

type Tab = "overview" | "orders" | "favorites" | "addresses" | "loyalty";

export default function CustomerDashboard({ onNavigate }: { onNavigate: (page: string) => void }) {
  const [activeTab, setActiveTab] = useState<Tab>("overview");

  const tabs: { key: Tab; label: string; icon: string }[] = [
    { key: "overview", label: "Overview", icon: "🏠" },
    { key: "orders", label: "Order History", icon: "📋" },
    { key: "favorites", label: "Favorites", icon: "❤️" },
    { key: "addresses", label: "Addresses", icon: "📍" },
    { key: "loyalty", label: "Rewards", icon: "⭐" },
  ];

  return (
    <div className="min-h-screen pt-24 pb-24 px-6">
      <div className="max-w-6xl mx-auto">
        {/* Profile header */}
        <div className="flex items-center gap-5 mb-10">
          <div
            className="w-16 h-16 rounded-full flex items-center justify-center text-2xl font-bold"
            style={{ background: "linear-gradient(135deg, #D4AF37, #E8C96B)", color: "#0D0D0D" }}
          >
            J
          </div>
          <div>
            <h1 className="font-display text-3xl font-bold" style={{ color: "#F5F5F5" }}>Ahmed Al-Farsi</h1>
            <p className="text-sm" style={{ color: "#A0A0A0" }}>ishrat@example.com · Member since March 2025</p>
            <span className="text-xs font-semibold px-2 py-0.5 rounded-full mt-1 inline-block font-mono" style={{ background: "rgba(212,175,55,0.15)", color: currentTier.color, border: `1px solid ${currentTier.color}40` }}>
              {currentTier.name} Member
            </span>
          </div>
        </div>

        <div className="grid lg:grid-cols-4 gap-8">
          {/* Sidebar */}
          <div className="lg:col-span-1">
            <nav className="rounded-2xl p-3 space-y-1 sticky top-24" style={{ background: "#1E1E1E", border: "1px solid #2E2E2E" }}>
              {tabs.map((tab) => (
                <button
                  key={tab.key}
                  onClick={() => setActiveTab(tab.key)}
                  className={`sidebar-link w-full ${activeTab === tab.key ? "active" : ""}`}
                >
                  <span>{tab.icon}</span>
                  {tab.label}
                </button>
              ))}
              <hr style={{ borderColor: "#2E2E2E", margin: "8px 0" }} />
              <button className="sidebar-link w-full" style={{ color: "#B33A3A" }}>
                <span>🚪</span> Sign Out
              </button>
            </nav>
          </div>

          {/* Content */}
          <div className="lg:col-span-3">
            {activeTab === "overview" && (
              <div className="space-y-6">
                {/* Stats */}
                <div className="grid grid-cols-3 gap-4">
                  {[
                    { value: orderHistory.length, label: "Total Orders", icon: "📋" },
                    { value: `€${orderHistory.reduce((s, o) => s + o.total, 0).toFixed(2)}`, label: "Total Spent", icon: "💰" },
                    { value: LOYALTY_POINTS.toLocaleString(), label: "Points Balance", icon: "⭐" },
                  ].map((stat) => (
                    <div key={stat.label} className="rounded-2xl p-5" style={{ background: "#1E1E1E", border: "1px solid #2E2E2E" }}>
                      <div className="text-xl mb-2">{stat.icon}</div>
                      <div className="font-mono font-bold text-2xl" style={{ color: "#D4AF37" }}>{stat.value}</div>
                      <div className="text-xs mt-1" style={{ color: "#A0A0A0" }}>{stat.label}</div>
                    </div>
                  ))}
                </div>

                {/* Recent order */}
                <div className="rounded-2xl p-6" style={{ background: "#1E1E1E", border: "1px solid #2E2E2E" }}>
                  <div className="flex items-center justify-between mb-5">
                    <h3 className="font-display text-lg font-semibold" style={{ color: "#F5F5F5" }}>Latest Order</h3>
                    <button onClick={() => setActiveTab("orders")} className="text-xs" style={{ color: "#D4AF37" }}>View all →</button>
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="font-mono text-sm font-bold" style={{ color: "#D4AF37" }}>#{orderHistory[0].id}</span>
                      <p className="text-xs mt-1" style={{ color: "#A0A0A0" }}>{orderHistory[0].items.join(", ")}</p>
                      <p className="text-xs mt-0.5" style={{ color: "#5A5A5A" }}>{orderHistory[0].date}</p>
                    </div>
                    <div className="text-right">
                      <div className="font-mono font-bold" style={{ color: "#F5F5F5" }}>€{orderHistory[0].total.toFixed(2)}</div>
                      <span className="text-xs status-delivered px-2 py-0.5 rounded-full mt-1 inline-block">Delivered</span>
                    </div>
                  </div>
                  <button onClick={() => onNavigate("tracking")} className="btn-outline-gold w-full mt-4 py-2 rounded-lg text-sm font-semibold">
                    Track Last Order
                  </button>
                </div>

                {/* Loyalty preview */}
                <div className="rounded-2xl p-6" style={{ background: "#1E1E1E", border: "1px solid #2E2E2E" }}>
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="font-display text-lg font-semibold" style={{ color: "#F5F5F5" }}>Kitchen Rewards</h3>
                    <span className="text-xs font-mono font-bold" style={{ color: currentTier.color }}>{currentTier.name} Tier</span>
                  </div>
                  <div className="flex items-end justify-between mb-2">
                    <span className="font-mono font-bold text-3xl" style={{ color: "#D4AF37" }}>{LOYALTY_POINTS.toLocaleString()}</span>
                    <span className="text-xs" style={{ color: "#A0A0A0" }}>{currentTier.max - LOYALTY_POINTS} pts to Platinum</span>
                  </div>
                  <div className="progress-bar mt-2" style={{ height: "8px" }}>
                    <div className="progress-fill" style={{ width: `${tierProgress}%` }} />
                  </div>
                  <div className="flex justify-between mt-1">
                    <span className="text-xs font-mono" style={{ color: "#A0A0A0" }}>{currentTier.min.toLocaleString()}</span>
                    <span className="text-xs font-mono" style={{ color: "#A0A0A0" }}>{currentTier.max.toLocaleString()}</span>
                  </div>
                </div>
              </div>
            )}

            {activeTab === "orders" && (
              <div className="space-y-4">
                <h2 className="font-display text-2xl font-bold" style={{ color: "#F5F5F5" }}>Order History</h2>
                {orderHistory.map((order) => (
                  <div key={order.id} className="rounded-2xl p-5" style={{ background: "#1E1E1E", border: "1px solid #2E2E2E" }}>
                    <div className="flex items-start justify-between">
                      <div>
                        <span className="font-mono text-sm font-bold" style={{ color: "#D4AF37" }}>#{order.id}</span>
                        <p className="text-xs mt-1" style={{ color: "#A0A0A0" }}>{order.date}</p>
                        <p className="text-sm mt-2" style={{ color: "#D0D0D0" }}>{order.items.join(" · ")}</p>
                      </div>
                      <div className="text-right shrink-0">
                        <div className="font-mono font-bold" style={{ color: "#F5F5F5" }}>€{order.total.toFixed(2)}</div>
                        <span className="text-xs status-delivered px-2 py-0.5 rounded-full mt-1 inline-block">
                          {order.status}
                        </span>
                      </div>
                    </div>
                    <div className="flex gap-3 mt-4">
                      <button onClick={() => onNavigate("menu")} className="btn-gold px-4 py-1.5 rounded-lg text-xs font-semibold">
                        Reorder
                      </button>
                      <button onClick={() => onNavigate("tracking")} className="btn-outline-gold px-4 py-1.5 rounded-lg text-xs font-semibold">
                        Track
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {activeTab === "favorites" && (
              <div>
                <h2 className="font-display text-2xl font-bold mb-6" style={{ color: "#F5F5F5" }}>Favorite Dishes</h2>
                <div className="grid grid-cols-2 gap-4">
                  {favorites.map((item) => (
                    <div key={item.id} className="rounded-xl overflow-hidden" style={{ background: "#1E1E1E", border: "1px solid #2E2E2E" }}>
                      <img src={item.image} alt={item.name} className="w-full h-36 object-cover" />
                      <div className="p-4">
                        <h4 className="font-semibold text-sm" style={{ color: "#F5F5F5" }}>{item.name}</h4>
                        <div className="flex items-center justify-between mt-2">
                          <span className="font-mono font-bold" style={{ color: "#D4AF37" }}>€{item.price.toFixed(2)}</span>
                          <button onClick={() => onNavigate("menu")} className="text-xs font-semibold" style={{ color: "#D4AF37" }}>Order Again →</button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeTab === "addresses" && (
              <div>
                <div className="flex items-center justify-between mb-6">
                  <h2 className="font-display text-2xl font-bold" style={{ color: "#F5F5F5" }}>Saved Addresses</h2>
                  <button className="btn-gold px-4 py-2 rounded-lg text-sm font-semibold">+ Add New</button>
                </div>
                <div className="space-y-4">
                  {savedAddresses.map((addr) => (
                    <div key={addr.id} className="rounded-2xl p-5 flex items-start gap-4" style={{ background: "#1E1E1E", border: addr.default ? "1px solid rgba(212,175,55,0.3)" : "1px solid #2E2E2E" }}>
                      <div className="text-2xl">📍</div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <span className="font-semibold text-sm" style={{ color: "#F5F5F5" }}>{addr.label}</span>
                          {addr.default && <span className="text-xs px-2 py-0.5 rounded-full font-mono" style={{ background: "rgba(212,175,55,0.1)", color: "#D4AF37" }}>Default</span>}
                        </div>
                        <p className="text-sm mt-1" style={{ color: "#A0A0A0" }}>{addr.address}</p>
                      </div>
                      <div className="flex gap-2 shrink-0">
                        <button className="text-xs" style={{ color: "#D4AF37" }}>Edit</button>
                        <button className="text-xs" style={{ color: "#B33A3A" }}>Delete</button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeTab === "loyalty" && (
              <div className="space-y-6">
                <h2 className="font-display text-2xl font-bold" style={{ color: "#F5F5F5" }}>Kitchen Rewards</h2>

                {/* Current status */}
                <div className="rounded-2xl p-8 text-center" style={{ background: "linear-gradient(135deg, #1A1400, #1E1E1E)", border: "1px solid rgba(212,175,55,0.3)" }}>
                  <div className="text-5xl mb-2">⭐</div>
                  <div className="font-mono font-black text-5xl mb-1" style={{ color: "#D4AF37" }}>{LOYALTY_POINTS.toLocaleString()}</div>
                  <div className="text-sm mb-4" style={{ color: "#A0A0A0" }}>Kitchen Points</div>
                  <span className="px-4 py-1.5 rounded-full text-sm font-semibold font-mono" style={{ background: "rgba(212,175,55,0.15)", color: currentTier.color, border: `1px solid ${currentTier.color}40` }}>
                    {currentTier.name} Member
                  </span>
                  <div className="mt-6">
                    <div className="progress-bar" style={{ height: "8px" }}>
                      <div className="progress-fill" style={{ width: `${tierProgress}%` }} />
                    </div>
                    <p className="text-xs mt-2" style={{ color: "#A0A0A0" }}>
                      {(currentTier.max - LOYALTY_POINTS).toLocaleString()} more points to reach Platinum
                    </p>
                  </div>
                </div>

                {/* Rewards to redeem */}
                <div>
                  <h3 className="font-display text-lg font-semibold mb-4" style={{ color: "#F5F5F5" }}>Redeem Points</h3>
                  <div className="grid grid-cols-2 gap-4">
                    {[
                      { pts: 500, reward: "Free Starter", icon: "🥗", affordable: LOYALTY_POINTS >= 500 },
                      { pts: 1000, reward: "Free Dessert", icon: "🍮", affordable: LOYALTY_POINTS >= 1000 },
                      { pts: 2000, reward: "Chef's Tasting Menu", icon: "🍽", affordable: LOYALTY_POINTS >= 2000 },
                      { pts: 5000, reward: "Private Dining Experience", icon: "🕯️", affordable: LOYALTY_POINTS >= 5000 },
                    ].map((r) => (
                      <div
                        key={r.reward}
                        className="rounded-xl p-5 text-center transition-all"
                        style={{
                          background: r.affordable ? "rgba(212,175,55,0.06)" : "#1A1A1A",
                          border: r.affordable ? "1px solid rgba(212,175,55,0.3)" : "1px solid #2A2A2A",
                          opacity: r.affordable ? 1 : 0.5,
                        }}
                      >
                        <div className="text-3xl mb-2">{r.icon}</div>
                        <div className="font-semibold text-sm mb-1" style={{ color: "#F5F5F5" }}>{r.reward}</div>
                        <div className="font-mono text-xs mb-3" style={{ color: "#D4AF37" }}>{r.pts.toLocaleString()} pts</div>
                        <button disabled={!r.affordable} className="btn-gold px-4 py-1.5 rounded-lg text-xs font-semibold disabled:opacity-30 disabled:cursor-not-allowed">
                          Redeem
                        </button>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Points history */}
                <div className="rounded-2xl p-6" style={{ background: "#1E1E1E", border: "1px solid #2E2E2E" }}>
                  <h3 className="font-display text-lg font-semibold mb-4" style={{ color: "#F5F5F5" }}>Points History</h3>
                  <div className="space-y-3">
                    {[
                      { date: "Jul 31, 2026", desc: "Order #TK-2847", pts: "+78", type: "earn" },
                      { date: "Jul 15, 2026", desc: "Order #TK-2741", pts: "+104", type: "earn" },
                      { date: "Jul 3, 2026", desc: "Order #TK-2688", pts: "+54", type: "earn" },
                      { date: "Jun 18, 2026", desc: "Redeemed: Free Starter", pts: "-500", type: "redeem" },
                      { date: "Jun 18, 2026", desc: "Order #TK-2591", pts: "+87", type: "earn" },
                    ].map((entry, i) => (
                      <div key={i} className="flex justify-between text-sm">
                        <div>
                          <div style={{ color: "#D0D0D0" }}>{entry.desc}</div>
                          <div className="text-xs" style={{ color: "#5A5A5A" }}>{entry.date}</div>
                        </div>
                        <span className="font-mono font-bold" style={{ color: entry.type === "earn" ? "#4CAF50" : "#B33A3A" }}>
                          {entry.pts} pts
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
