import { useState, useMemo, useEffect, useRef } from "react";
import { menuItems, type Category, type MenuItem } from "../data/menuData";

interface MenuProps {
  onAddToCart: (item: MenuItem) => void;
  cartItems: { id: string; quantity: number }[];
}

const BASE_CATEGORIES: { key: Category | "all"; label: string; icon: string }[] = [
  { key: "all", label: "All", icon: "🍽" },
  { key: "burgers", label: "Burgers", icon: "🍔" },
  { key: "pizzas", label: "Pizzas", icon: "🍕" },
  { key: "wraps", label: "Wraps", icon: "🌯" },
  { key: "sides", label: "Sides", icon: "🍟" },
  { key: "smokehouse", label: "Smokehouse", icon: "🔥" },
];

const categories = BASE_CATEGORIES.map((c) => ({
  ...c,
  count: c.key === "all" ? menuItems.length : menuItems.filter((m) => m.category === c.key).length,
}));

const dietFilters = ["All", "Veg / Vegan", "Non-Veg"];

function StarRating({ rating }: { rating: number }) {
  return (
    <div className="flex items-center gap-0.5">
      {[1, 2, 3, 4, 5].map((s) => (
        <svg key={s} className={`w-3 h-3 ${s <= Math.round(rating) ? "star-filled" : "star-empty"}`} fill="currentColor" viewBox="0 0 20 20">
          <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
        </svg>
      ))}
      <span className="text-xs ml-1 font-mono" style={{ color: "#5A5A5A" }}>{rating}</span>
    </div>
  );
}

function AddButton({ item, qty, onAdd }: { item: MenuItem; qty: number; onAdd: () => void }) {
  const [flash, setFlash] = useState(false);

  const handleClick = () => {
    onAdd();
    setFlash(true);
    setTimeout(() => setFlash(false), 600);
  };

  if (item.soldOut) {
    return (
      <button disabled className="w-full py-2.5 rounded-xl text-xs font-semibold uppercase tracking-wider tag-soldout cursor-not-allowed">
        Sold Out
      </button>
    );
  }

  if (qty > 0) {
    return (
      <div
        className="flex items-center justify-between rounded-xl px-4 py-2"
        style={{ background: "rgba(212,175,55,0.08)", border: "1px solid rgba(212,175,55,0.25)" }}
      >
        <span className="text-xs font-mono" style={{ color: "#A0A0A0" }}>In cart</span>
        <div className="flex items-center gap-2">
          <span className="text-sm font-bold font-mono" style={{ color: "#D4AF37" }}>{qty}</span>
          <button
            onClick={handleClick}
            className="text-xs font-bold px-2 py-0.5 rounded-lg transition-all"
            style={{ background: "rgba(212,175,55,0.15)", color: "#D4AF37" }}
            onMouseEnter={(e) => (e.currentTarget.style.background = "rgba(212,175,55,0.28)")}
            onMouseLeave={(e) => (e.currentTarget.style.background = "rgba(212,175,55,0.15)")}
          >
            + Add
          </button>
        </div>
      </div>
    );
  }

  return (
    <button
      onClick={handleClick}
      className="w-full py-2.5 rounded-xl text-xs font-semibold uppercase tracking-wider transition-all duration-300"
      style={{
        background: flash ? "rgba(94,196,94,0.15)" : "linear-gradient(135deg, #D4AF37, #E8C96B)",
        color: flash ? "#5EC45E" : "#0D0D0D",
        border: flash ? "1px solid rgba(94,196,94,0.3)" : "none",
        boxShadow: flash ? "0 0 14px rgba(94,196,94,0.18)" : "0 3px 12px rgba(212,175,55,0.22)",
      }}
    >
      {flash ? "✓ Added!" : "Add to Cart"}
    </button>
  );
}

function GridCard({ item, qty, onAdd }: { item: MenuItem; qty: number; onAdd: () => void }) {
  return (
    <div className="card-hover rounded-2xl overflow-hidden flex flex-col animate-menu-reveal" style={{ background: "#111111", border: "1px solid rgba(255,255,255,0.05)" }}>
      <div className="relative img-zoom-wrap" style={{ height: "190px", background: "#1A1A1A" }}>
        <img src={item.image} alt={item.name} className="w-full h-full object-cover" loading="lazy" decoding="async" width={400} height={190} />
        <div className="absolute inset-0" style={{ background: "linear-gradient(to top, rgba(8,8,8,0.85), transparent 55%)" }} />
        {item.soldOut && (
          <div className="absolute inset-0 flex items-center justify-center" style={{ background: "rgba(0,0,0,0.7)" }}>
            <span className="font-mono font-bold text-xs tag-soldout px-3 py-1.5 rounded-full">SOLD OUT</span>
          </div>
        )}
        <div className="absolute top-2.5 left-2.5 flex gap-1.5 flex-wrap">
          <span className={`text-xs px-2.5 py-0.5 rounded-full font-mono font-medium ${item.diet !== "non-veg" ? "tag-veg" : "tag-nonveg"}`}>
            {item.diet === "veg" ? "🌱 Veg" : item.diet === "vegan" ? "🌱 Vegan" : "● Halal"}
          </span>
          {item.spicy && <span className="text-xs px-2 py-0.5 rounded-full tag-spicy">🌶</span>}
        </div>
        <div className="absolute bottom-2.5 right-3">
          <span className="font-mono font-bold text-base" style={{ color: "#D4AF37", textShadow: "0 2px 6px rgba(0,0,0,0.9)" }}>€{item.price.toFixed(2)}</span>
        </div>
        {item.popular && !item.soldOut && (
          <div className="absolute top-2.5 right-2.5">
            <span className="text-xs px-2 py-0.5 rounded-full font-mono font-semibold" style={{ background: "rgba(212,175,55,0.2)", color: "#D4AF37", border: "1px solid rgba(212,175,55,0.35)" }}>
              ★ Popular
            </span>
          </div>
        )}
      </div>
      <div className="p-4 flex flex-col flex-1">
        <div className="mb-1">
          <h3 className="font-display font-semibold leading-tight" style={{ color: "#F0F0F0", fontSize: "14px" }}>{item.name}</h3>
          {item.nameAr && <p className="text-xs mt-0.5 font-mono" style={{ color: "#4A4A4A", direction: "rtl" }}>{item.nameAr}</p>}
        </div>
        <StarRating rating={item.rating} />
        {item.tags && item.tags.length > 0 && (
          <div className="flex gap-1 mt-2 flex-wrap">
            {item.tags.map((tag) => (
              <span key={tag} className="text-xs px-2 py-0.5 rounded font-mono" style={{ background: "rgba(212,175,55,0.07)", color: "#9A7A20", border: "1px solid rgba(212,175,55,0.15)" }}>
                {tag}
              </span>
            ))}
          </div>
        )}
        <p className="text-xs mt-2 leading-relaxed flex-1 line-clamp-2" style={{ color: "#6A6A6A" }}>{item.description}</p>
        <div className="mt-3.5">
          <AddButton item={item} qty={qty} onAdd={onAdd} />
        </div>
      </div>
    </div>
  );
}

function ListCard({ item, qty, onAdd }: { item: MenuItem; qty: number; onAdd: () => void }) {
  return (
    <div className="card-hover rounded-2xl overflow-hidden flex items-center gap-4 p-4 animate-menu-reveal" style={{ background: "#111111", border: "1px solid rgba(255,255,255,0.05)" }}>
      <div className="relative w-20 h-20 rounded-xl overflow-hidden shrink-0 img-zoom-wrap" style={{ background: "#1A1A1A" }}>
        <img src={item.image} alt={item.name} className="w-full h-full object-cover" loading="lazy" decoding="async" width={80} height={80} />
        {item.soldOut && (
          <div className="absolute inset-0 flex items-center justify-center" style={{ background: "rgba(0,0,0,0.7)" }}>
            <span className="text-xs font-mono" style={{ color: "#888" }}>SOLD</span>
          </div>
        )}
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 flex-wrap mb-0.5">
          <h3 className="font-display font-semibold text-sm" style={{ color: "#F0F0F0" }}>{item.name}</h3>
          {item.nameAr && <span className="text-xs font-mono" style={{ color: "#4A4A4A", direction: "rtl" }}>{item.nameAr}</span>}
        </div>
        <div className="flex items-center gap-2 mb-1 flex-wrap">
          <span className={`text-xs px-2 py-0.5 rounded-full font-mono ${item.diet !== "non-veg" ? "tag-veg" : "tag-nonveg"}`}>
            {item.diet === "veg" ? "🌱 Veg" : item.diet === "vegan" ? "🌱 Vegan" : "Halal"}
          </span>
          {item.spicy && <span className="text-xs tag-spicy px-2 py-0.5 rounded-full">🌶 Spicy</span>}
          {item.popular && <span className="text-xs font-mono" style={{ color: "#8A6A10" }}>★ Popular</span>}
        </div>
        <StarRating rating={item.rating} />
        <p className="text-xs mt-1 line-clamp-1" style={{ color: "#5A5A5A" }}>{item.description}</p>
      </div>
      <div className="flex flex-col items-end gap-2 shrink-0">
        <span className="font-mono font-bold text-base" style={{ color: "#D4AF37" }}>€{item.price.toFixed(2)}</span>
        <button
          onClick={onAdd}
          disabled={item.soldOut}
          className="btn-gold px-4 py-1.5 rounded-lg text-xs font-semibold uppercase tracking-wider disabled:opacity-40"
          style={{ minWidth: "72px" }}
        >
          {item.soldOut ? "Sold" : qty > 0 ? `+1 (${qty})` : "Add"}
        </button>
      </div>
    </div>
  );
}

export default function Menu({ onAddToCart, cartItems }: MenuProps) {
  const [activeCategory, setActiveCategory] = useState<Category | "all">("all");
  const [dietFilter, setDietFilter] = useState("All");
  const [search, setSearch] = useState("");
  const [maxPrice, setMaxPrice] = useState(16);
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");
  const [showScrollTop, setShowScrollTop] = useState(false);
  const gridRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const onScroll = () => setShowScrollTop(window.scrollY > 400);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const filtered = useMemo(() => menuItems.filter((item) => {
    if (activeCategory !== "all" && item.category !== activeCategory) return false;
    if (dietFilter === "Veg / Vegan" && item.diet === "non-veg") return false;
    if (dietFilter === "Non-Veg" && item.diet !== "non-veg") return false;
    if (item.price > maxPrice) return false;
    if (search && !item.name.toLowerCase().includes(search.toLowerCase()) && !item.description.toLowerCase().includes(search.toLowerCase())) return false;
    return true;
  }), [activeCategory, dietFilter, maxPrice, search]);

  const getCartQty = (id: string) => cartItems.find((c) => c.id === id)?.quantity || 0;

  const hasFilters = activeCategory !== "all" || dietFilter !== "All" || search || maxPrice < 16;

  return (
    <div className="min-h-screen" style={{ background: "#0A0A0A" }}>
      {/* Page header */}
      <div className="pt-28 pb-14 px-6 text-center" style={{ background: "linear-gradient(to bottom, #0D0D0D, #0A0A0A)" }}>
        <p className="text-xs tracking-widest uppercase mb-3 font-mono animate-fade-in" style={{ color: "#D4AF37" }}>
          — Fresh Ingredients · Premium Quality —
        </p>
        <h1 className="font-display font-bold mb-4 animate-fade-in" style={{ color: "#F5F5F5", fontSize: "clamp(2.5rem, 7vw, 5rem)", animationDelay: "0.1s" }}>
          Our Menu
        </h1>
        <p className="text-base max-w-lg mx-auto mb-6 animate-fade-in" style={{ color: "#7A7A7A", animationDelay: "0.15s" }}>
          100% Halal — Burgers, Pizzas, Wraps & Smokehouse, crafted with passion.
        </p>
        <div className="flex items-center justify-center gap-2.5 flex-wrap animate-fade-in" style={{ animationDelay: "0.2s" }}>
          <span className="halal-badge">✓ 100% Halal</span>
          <span className="text-xs px-3 py-1.5 rounded-full font-mono font-semibold" style={{ background: "rgba(212,175,55,0.07)", border: "1px solid rgba(212,175,55,0.18)", color: "#D4AF37" }}>🌱 Veg Options</span>
          <span className="text-xs px-3 py-1.5 rounded-full font-mono font-semibold" style={{ background: "rgba(255,112,67,0.07)", border: "1px solid rgba(255,112,67,0.2)", color: "#FF7043" }}>🌶 Spicy Options</span>
        </div>
      </div>

      {/* Sticky filter bar */}
      <div
        className="sticky z-20 py-3 px-4"
        style={{
          top: "60px",
          background: "rgba(8,8,8,0.97)",
          backdropFilter: "blur(20px)",
          WebkitBackdropFilter: "blur(20px)",
          borderBottom: "1px solid rgba(212,175,55,0.08)",
          boxShadow: "0 4px 24px rgba(0,0,0,0.5)",
        }}
      >
        <div className="max-w-7xl mx-auto">
          {/* Category pills row */}
          <div className="flex gap-2 overflow-x-auto pb-1 mb-3" style={{ scrollbarWidth: "none" }}>
            {categories.map((cat) => (
              <button
                key={cat.key}
                onClick={() => setActiveCategory(cat.key)}
                className={`cat-pill shrink-0 ${activeCategory === cat.key ? "active" : "inactive"}`}
              >
                <span>{cat.icon}</span>
                <span>{cat.label}</span>
                <span
                  className="text-xs font-mono px-1.5 py-0.5 rounded-full"
                  style={{
                    background: activeCategory === cat.key ? "rgba(0,0,0,0.2)" : "rgba(255,255,255,0.05)",
                    color: activeCategory === cat.key ? "rgba(13,13,13,0.7)" : "#4A4A4A",
                    fontSize: "10px",
                  }}
                >
                  {cat.count}
                </span>
              </button>
            ))}
          </div>

          {/* Second row: search + filters */}
          <div className="flex flex-wrap items-center gap-2.5">
            {/* Search */}
            <div className="relative flex-1 min-w-40 max-w-72">
              <svg className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24" style={{ color: "#5A5A5A" }}>
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
              <input
                type="text"
                placeholder="Search dishes..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-9 text-sm"
                style={{ paddingTop: "7px", paddingBottom: "7px", background: "#141414", borderColor: "#2A2A2A" }}
              />
              {search && (
                <button
                  onClick={() => setSearch("")}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-xs"
                  style={{ color: "#5A5A5A" }}
                >
                  ×
                </button>
              )}
            </div>

            {/* Diet filter */}
            <select
              value={dietFilter}
              onChange={(e) => setDietFilter(e.target.value)}
              className="text-sm"
              style={{ width: "auto", paddingTop: "7px", paddingBottom: "7px", background: "#141414", borderColor: "#2A2A2A" }}
            >
              {dietFilters.map((d) => <option key={d}>{d}</option>)}
            </select>

            {/* Price range */}
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl" style={{ background: "#141414", border: "1px solid #2A2A2A" }}>
              <span className="text-xs font-mono whitespace-nowrap" style={{ color: "#5A5A5A" }}>
                Max: <span style={{ color: "#D4AF37" }}>€{maxPrice.toFixed(0)}</span>
              </span>
              <input
                type="range"
                min={2}
                max={16}
                step={1}
                value={maxPrice}
                onChange={(e) => setMaxPrice(Number(e.target.value))}
                className="w-20"
                style={{ padding: 0, border: "none", background: "transparent", accentColor: "#D4AF37" }}
              />
            </div>

            {/* View mode */}
            <div className="flex gap-1 p-1 rounded-xl" style={{ background: "#141414", border: "1px solid #2A2A2A" }}>
              <button
                onClick={() => setViewMode("grid")}
                className="p-2 rounded-lg transition-all"
                style={{ background: viewMode === "grid" ? "#D4AF37" : "transparent", color: viewMode === "grid" ? "#0D0D0D" : "#5A5A5A" }}
              >
                <svg className="w-3.5 h-3.5" fill="currentColor" viewBox="0 0 20 20"><path d="M5 3a2 2 0 00-2 2v2a2 2 0 002 2h2a2 2 0 002-2V5a2 2 0 00-2-2H5zM5 11a2 2 0 00-2 2v2a2 2 0 002 2h2a2 2 0 002-2v-2a2 2 0 00-2-2H5zM11 5a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V5zM11 13a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z" /></svg>
              </button>
              <button
                onClick={() => setViewMode("list")}
                className="p-2 rounded-lg transition-all"
                style={{ background: viewMode === "list" ? "#D4AF37" : "transparent", color: viewMode === "list" ? "#0D0D0D" : "#5A5A5A" }}
              >
                <svg className="w-3.5 h-3.5" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M3 5a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM3 10a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM3 15a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1z" clipRule="evenodd" /></svg>
              </button>
            </div>

            {/* Clear all */}
            {hasFilters && (
              <button
                onClick={() => { setActiveCategory("all"); setDietFilter("All"); setSearch(""); setMaxPrice(16); }}
                className="text-xs px-3 py-1.5 rounded-full font-mono transition-all animate-fade-in-fast"
                style={{ color: "#8A5A10", background: "rgba(212,175,55,0.07)", border: "1px solid rgba(212,175,55,0.15)" }}
                onMouseEnter={(e) => (e.currentTarget.style.background = "rgba(212,175,55,0.14)")}
                onMouseLeave={(e) => (e.currentTarget.style.background = "rgba(212,175,55,0.07)")}
              >
                Clear filters ×
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Results */}
      <div className="max-w-7xl mx-auto px-6 pt-7 pb-24" ref={gridRef}>
        {/* Count + sort */}
        <div className="flex items-center justify-between mb-6">
          <span className="text-sm font-mono" style={{ color: "#5A5A5A" }}>
            <span style={{ color: "#D4AF37", fontWeight: "600" }}>{filtered.length}</span> dish{filtered.length !== 1 ? "es" : ""}
            {activeCategory !== "all" && <span style={{ color: "#4A4A4A" }}> in {categories.find(c => c.key === activeCategory)?.label}</span>}
          </span>
          {search && (
            <span className="text-xs" style={{ color: "#5A5A5A" }}>
              Results for "<span style={{ color: "#D4AF37" }}>{search}</span>"
            </span>
          )}
        </div>

        {/* Grid */}
        {filtered.length > 0 ? (
          viewMode === "grid" ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
              {filtered.map((item) => (
                <GridCard
                  key={item.id}
                  item={item}
                  qty={getCartQty(item.id)}
                  onAdd={() => onAddToCart(item)}
                />
              ))}
            </div>
          ) : (
            <div className="flex flex-col gap-3 max-w-4xl">
              {filtered.map((item) => (
                <ListCard
                  key={item.id}
                  item={item}
                  qty={getCartQty(item.id)}
                  onAdd={() => onAddToCart(item)}
                />
              ))}
            </div>
          )
        ) : (
          /* Empty state */
          <div className="text-center py-28 animate-fade-in">
            <div className="text-6xl mb-5 animate-float inline-block">🍽</div>
            <h3 className="font-display text-2xl font-bold mb-3" style={{ color: "#F5F5F5" }}>No dishes found</h3>
            <p className="text-sm mb-8" style={{ color: "#5A5A5A" }}>Try adjusting your filters or broadening your search.</p>
            <button
              onClick={() => { setActiveCategory("all"); setDietFilter("All"); setSearch(""); setMaxPrice(16); }}
              className="btn-outline-gold px-7 py-3 rounded-full text-sm font-semibold"
            >
              Reset Filters
            </button>
          </div>
        )}
      </div>

      {/* Scroll-to-top FAB */}
      {showScrollTop && (
        <button
          onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
          className="fixed bottom-8 right-6 w-11 h-11 rounded-full flex items-center justify-center transition-all animate-scale-in"
          style={{ background: "linear-gradient(135deg, #D4AF37, #E8C96B)", color: "#0D0D0D", boxShadow: "0 4px 20px rgba(212,175,55,0.4)", zIndex: 40 }}
          onMouseEnter={(e) => (e.currentTarget.style.transform = "translateY(-2px) scale(1.05)")}
          onMouseLeave={(e) => (e.currentTarget.style.transform = "translateY(0) scale(1)")}
          aria-label="Scroll to top"
        >
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M5 15l7-7 7 7" />
          </svg>
        </button>
      )}
    </div>
  );
}
