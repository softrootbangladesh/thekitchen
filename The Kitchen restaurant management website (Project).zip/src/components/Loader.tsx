import { useEffect, useState } from "react";
import logoSrc from "../imports/The_Kitchen-removebg-preview_-_Edited__1_.png";

export default function Loader({ onDone }: { onDone: () => void }) {
  const [fadeOut, setFadeOut] = useState(false);

  useEffect(() => {
    const fade = setTimeout(() => setFadeOut(true), 1800);
    const done = setTimeout(() => onDone(), 2300);
    return () => {
      clearTimeout(fade);
      clearTimeout(done);
    };
  }, [onDone]);

  return (
    <div
      style={{
        position: "fixed",
        inset: 0,
        zIndex: 9999,
        background: "#0D0D0D",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        gap: "28px",
        transition: "opacity 0.5s ease",
        opacity: fadeOut ? 0 : 1,
        pointerEvents: fadeOut ? "none" : "all",
      }}
    >
      {/* Logo */}
      <img
        src={logoSrc}
        alt="The Kitchen"
        style={{
          height: "80px",
          width: "auto",
          objectFit: "contain",
          filter: "brightness(0) invert(1) sepia(1) saturate(3) hue-rotate(5deg) brightness(0.85)",
          animation: "pulse-opacity 1.4s ease-in-out infinite",
        }}
      />

      {/* Gold spinner ring */}
      <div style={{ position: "relative", width: "48px", height: "48px" }}>
        <svg
          style={{
            width: "100%",
            height: "100%",
            animation: "spin 1s linear infinite",
            transformOrigin: "center",
          }}
          viewBox="0 0 48 48"
          fill="none"
        >
          <circle cx="24" cy="24" r="20" stroke="#2A2A2A" strokeWidth="3" />
          <circle
            cx="24"
            cy="24"
            r="20"
            stroke="url(#gold-grad)"
            strokeWidth="3"
            strokeLinecap="round"
            strokeDasharray="90 36"
          />
          <defs>
            <linearGradient id="gold-grad" x1="0" y1="0" x2="48" y2="48" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#D4AF37" />
              <stop offset="100%" stopColor="#E8C96B" />
            </linearGradient>
          </defs>
        </svg>
      </div>

      {/* Tagline */}
      <p
        style={{
          fontFamily: "'JetBrains Mono', monospace",
          fontSize: "11px",
          letterSpacing: "0.25em",
          textTransform: "uppercase",
          color: "#4A4A4A",
        }}
      >
        Malta · Made With Passion
      </p>

      <style>{`
        @keyframes spin { to { transform: rotate(360deg); } }
        @keyframes pulse-opacity {
          0%, 100% { opacity: 0.7; }
          50% { opacity: 1; }
        }
      `}</style>
    </div>
  );
}
